/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import com.itextpdf.text.Chunk;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import dao.DataBase;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Conges;
import model.Courrier;
import model.Courrier_Interne;
import model.NonConsommable;
import model.Permissions;
import model.Personnel;
import model.Session;
import view.Acceuil;
import view.AccordeConge;
import view.AccordeDroit;
import view.AccordePermissions;
import view.AjouterPersonnel;
import view.AttestationPresencePoste;
import view.DemandePermission;
import view.DemanderConge;
import view.EnregistreCourrier;
import view.EnregistrerMateriel;
import view.HistoriqueConges;
import view.HistoriquePermission;
import view.ModifierCompte;
import view.RechercherMateriel;
import view.Rechercher_un_Courrier;
import view.Registre_Courrier_entrant;
import view.Registre_Courrier_interne;
import view.Registre_Courrier_sortant;
import view.RepartionMateriel;
import view.Utilisateur;

/**
 *
 * @author Jordan
 */
public class CtrlAttestation implements ActionListener {
    AttestationPresencePoste fen;
    DataBase bd;

    public CtrlAttestation(AttestationPresencePoste fen) {
        this.fen = fen;
        this.bd=new DataBase();
    }
    
    

    @Override
    public void actionPerformed(ActionEvent e) {
         Object source=e.getSource();
         //Session session=this.bd.rechercherSession("select * from session where login='"+fen.getNom()+"';");
         Utilisateur fenu=new Utilisateur();
         CtrlConnexion conn=new CtrlConnexion(fenu);
         //Session user=conn.getUser();
         System.out.println(conn.user.toString());
         if(source==fen.getEnregistrercourrier()){
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 EnregistreCourrier fenc=new EnregistreCourrier();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
         } 
         else if(source==fen.getRegistreInterne()){ 
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 Registre_Courrier_interne fenc=new Registre_Courrier_interne();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         } 
         else if(source==fen.getRegistreSortant()){
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 Registre_Courrier_sortant fenc=new Registre_Courrier_sortant();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
         } 
         else if(source==fen.getRegistreEntrant()){ 
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 Registre_Courrier_entrant fenc=new Registre_Courrier_entrant();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         }
         else if(source==fen.getAjouterPerso()){ 
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 AjouterPersonnel fenp=new AjouterPersonnel();
                 fenp.setVisible(true);
                 fen.dispose();
             } 
             else{
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
             
         } 
         else if(source==fen.getAddArchive()){ 
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI") || conn.user.getCourrier().equalsIgnoreCase("OUI")){
                 
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
             
         } 
         else if(source==fen.getAccorderDroit()){ 
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")){ 
             DefaultTableModel model=new DefaultTableModel();
            model.addColumn("matricule");
            model.addColumn("email");
            model.addColumn("mot de passe");
            model.addColumn("administrateur");
            model.addColumn("connection");
            model.addColumn("materiel");
            model.addColumn("courrier");
            
            String query2="select *from session;";
            ArrayList<Session> list=this.bd.listerSession(query2);
            for(Session s:list){
                model.addRow(new Object[]{s.getPersonnel().getMatricule(),s.getLogin(),s.getPassword(),s.getAdministrateur(),s.getConnection(),s.getMateriel(),s.getCourrier()});
            } 
           
                 AccordeDroit fena=new AccordeDroit();
                  fena.getTable().setModel(model);
                 fena.setVisible(true);
                 fen.dispose();
                 
             } 
             else{
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         } 
         else if(source==fen.getEnregistrerMateriel()){ 
             if(conn.user.getMateriel().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 EnregistrerMateriel fenmat=new EnregistrerMateriel();
                 fenmat.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         } 
         else if(source==fen.getHistoConge()){ 
                DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("DEBUT");
             model.addColumn("FIN");
             model.addColumn("Etat");
             
             String query2="select * from conges ;";
             ArrayList<Conges> list=this.bd.listeConge(query2);
             for(Conges conge:list){
                 model.addRow(new Object[]{conge.getPersonnel().getMatricule(),conge.getDebut(),conge.getFin(),conge.getEtat()});
                 
             }
             HistoriqueConges fenh=new HistoriqueConges();
             fenh.getTable().setModel(model);
             fenh.setVisible(true);
             fen.dispose();
         } 
         else if(source==fen.getHistoPermission()){
               DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("Objet");
             model.addColumn("Debut");
             model.addColumn("Fin");
             ArrayList<Permissions> list=this.bd.listPermission("select * from permissions;");
             for(Permissions perms:list){
                 model.addRow(new Object[]{perms.getPersonnel().getMatricule(),perms.getObjet(),perms.getDebut(),perms.getFin()});
                 
             } 
             HistoriquePermission fenh=new HistoriquePermission();
             fenh.getTable().setModel(model);
             fenh.setVisible(true);
             fen.dispose();
         }
         else if(source==fen.getDisconnect()){ 
             Utilisateur fenc=new Utilisateur(); 
             fenc.setVisible(true);
             
         } 
         else if(source==fen.getRechercherMateriel()){ 
             if(conn.user.getMateriel().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 RechercherMateriel fenrech=new RechercherMateriel();
                 fenrech.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         } 
         else if(source==fen.getRechercherArchive()){
             
         } 
         else if(source==fen.getReformerMateriel()){
             
         } 
         else if(source==fen.getRepartirMateriel()){ 
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI") || conn.user.getMateriel().equalsIgnoreCase("OUI")){
                 RepartionMateriel fenrep=new RepartionMateriel();
                 fenrep.setVisible(true);
                 DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Reference");
             model.addColumn("Nature");
             model.addColumn("Marque");
             model.addColumn("Caracteristiques");
             model.addColumn("Position");
             model.addColumn("Detenteur");
             String query1="select * from materiel,nonconsommable where materiel.reference=nonconsommable.reference and materiel.reference not in(select reference from repartition);";
             ArrayList<NonConsommable> list=this.bd.listerNonConsommables(query1);
             for(NonConsommable materiel:list){
                 model.addRow(new Object[] {materiel.getReference(),materiel.getNature(),materiel.getMarque(),materiel.getCaracteristique(),materiel.getSituation(),""});
             } 
             fenrep.getTable().setModel(model);
                 fen.dispose();
                 
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         } 
         
         else if(source==fen.getDemanderConge()){
            DemanderConge fenCon=new DemanderConge();
            fenCon.setVisible(true);
            fen.dispose();
        }
        
        else if(source==fen.getDemanderPermission()){
            LocalDateTime current=LocalDateTime.now();
             LocalDate date=current.toLocalDate();
             String query="select * from permissions where matricule='"+conn.user.getPersonnel().getMatricule()+"'and(debut between'"+date.getYear()+"-01-01'and'"+date.getYear()+"-12-31');";
             ArrayList<Permissions> list=this.bd.listPermission(query);
             float nbre=0;
             for(Permissions perms:list){
                 long diff=perms.getFin().getTime()-perms.getDebut().getTime();
                 nbre+=(diff/(1000*60*60*24));
             } 
             if(nbre>=10){
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE, vous avez deja consommé vos 10 jours de congé annuel","ERROR",JOptionPane.ERROR_MESSAGE);
             } 
             else {
                 DemandePermission fenPer=new DemandePermission();
             fenPer.setVisible(true);
             fen.dispose();
             }
        }
        else if(source==fen.getFicheDetenteur()){
            if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")||conn.user.getMateriel().equalsIgnoreCase("OUI")){
                String mat=JOptionPane.showInputDialog(fen,"renseigner le matricule de l'usager");
                CtrlAcceuil con=new CtrlAcceuil(new Acceuil());
                con.editFicheDetenteur(mat);
            }
            else {
                JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
            }
            
            
        }
        else if(source==fen.getAccordeConge()){
            if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                DefaultTableModel model=new DefaultTableModel();
                model.addColumn("Matricule");
                model.addColumn("DEBUT");
                model.addColumn("FIN");
                model.addColumn("DECISION");
                
                String query2="select * from conges where situation='NON-TRAITE';";
                ArrayList<Conges> list=this.bd.listeConge(query2);
                for(Conges conge:list){
                    model.addRow(new Object[]{conge.getPersonnel().getMatricule(),conge.getDebut(),conge.getFin(),conge.getDecision()});
                    
                }
                AccordeConge fenac=new AccordeConge();
                fenac.setVisible(true);
                fenac.getTable().setModel(model);
                fen.dispose();
            }
            else{
                JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
            }
        }
        else if(source==fen.getRechercherCourrier()){
            if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")|| conn.user.getCourrier().equalsIgnoreCase("OUI")){
                Rechercher_un_Courrier fenr=new Rechercher_un_Courrier();
                fenr.setVisible(true);
                fen.dispose();
                
            }
            else{
                JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
                
            }
        }
        else if(source==fen.getAccorderPermission()){
            DefaultTableModel model=new DefaultTableModel();
            model.addColumn("Matricule");
            model.addColumn("Objet");
            model.addColumn("Debut");
            model.addColumn("Fin");
            model.addColumn("Decision");
            ArrayList<Permissions> list=this.bd.listPermission("select * from permissions where etat='NON-TRAITE';");
            for(Permissions perms:list){
                model.addRow(new Object[]{perms.getPersonnel().getMatricule(),perms.getObjet(),perms.getDebut(),perms.getFin(),perms.getEtat()});
                
            }
            AccordePermissions fenp=new AccordePermissions();
            fenp.getTable().setModel(model);
            fenp.setVisible(true);
            fen.dispose();
        }
        else if(e.getSource()==fen.getModifierCompte()) { 
            String matricule=JOptionPane.showInputDialog(fen, "renseigner votre matricule");
            Session session=this.bd.rechercherSession("select * from session where matricule='"+matricule+"';");
            ModifierCompte fenc=new ModifierCompte();
            fenc.setVisible(true);
            fenc.getMatricule().setText(matricule);
            fenc.getOld().setEditable(true);
            fen.dispose();
       }
        
        else if(source==fen.getValider()){
            String matricule=fen.getMatricule().getText();
            java.sql.Date date=new Date(fen.getDate().getDate().getTime());
            String arrete=fen.getArrete().getText();
            Personnel pers=this.bd.rechercherPersonnel("select * from personnel where matricule='"+matricule+"';");
            attestationPresence(pers,arrete,date);
        }
        else {
        }
/*           else if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
         }*/
    
    } 
    public void attestationPresence(Personnel pers,String arrete,java.sql.Date dates){
        LocalDateTime curent=LocalDateTime.now();
        LocalDate today=curent.toLocalDate();
        Date date=Date.valueOf(today);
        String home=System.getProperty("user.home");
        String separateur=System.getProperty("file.separator");
        String repertoire1="AGRHM";
        String repertoire2="GESTION DU PERSONNEL";
        String repertoire3="ATTESTATION DE PRESENCE EFFECTIVE AU SERVICE";
        String folder=home+separateur+repertoire1+separateur+repertoire2+separateur+repertoire3;
        System.out.println(folder);
        File fichier=new File(folder);
        if(!fichier.exists()){
            fichier.mkdirs();
        } 
        String name=pers.getMatricule();
         
        String chemin=folder+separateur+name+"_"+date+".pdf";
        System.out.println(chemin);
           com.itextpdf.text.Document document=new com.itextpdf.text.Document();
        try {
            PdfWriter.getInstance( document,new FileOutputStream(chemin));
            document.open();
            document.addTitle("ATTESTATION DE PRESENCE EFFECTIVE AU SERVICE");
            document.addAuthor("CENTRE INFORMATIQUE DE BAFOUSSAM");
            Image img=Image.getInstance("C:\\Users\\Jordan\\Downloads\\entete2.GIF");
            document.add(img);
            document.add(new Paragraph("  "));
            int numOrdre=this.bd.recherchernumOrdre("select * from courrierinterne;");
            numOrdre++;
            String reference="N°"+numOrdre+"/2020/APES/MINFI/CENADI/CIB";
            
            Courrier_Interne courrier=new Courrier_Interne(reference, numOrdre,"ATTESTATION DE PRESENCE EFFECTIVE AU SERVICE ",pers.getNom(),date);
            String query1="insert into courrier(type,objet,date)values('ATTESTATION DE PRESENCE EFFECTIVE AU SERVICE','"+pers.getNom()+"','"+date+"');";
            this.bd.setDataInBd(query1);
            int id=this.bd.rechercherid();
            String chemin2="C:\\Utilisateurs\\EMME\\AGRHM\\GESTION DU PERSONNEL\\ATTESTATION DE PRESENCE EFFECTIVE AU SERVICE\\"+name;
            String query2="insert into courrierinterne(reference,id)values('"+reference+"',"+id+");";
            this.bd.setDataInBd(query2);
            Chunk chunck=new Chunk(reference,FontFactory.getFont(FontFactory.TIMES_ROMAN, 10f,Font.BOLDITALIC));
            chunck.setUnderline((float) 1, -2);
            Paragraph pref= new Paragraph(chunck);
            pref.setAlignment(Paragraph.ALIGN_LEFT);
            document.add(pref);
            document.add(new Paragraph("    "));
            Chunk title=new Chunk("ATTESTATION DE PRESENCE EFFECTIVE AU SERVICE",FontFactory.getFont(FontFactory.TIMES_ROMAN, 20f,Font.BOLD));
            title.setUnderline((float) 1, -2);
            Paragraph pTitle=new Paragraph(title);
            pTitle.setAlignment(Paragraph.ALIGN_CENTER);
            document.add(pTitle);
            document.add(new Paragraph("   "));
            Chunk soussigne=new Chunk("Le chef du Centre Informatique de Bafoussam soussigné,",FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.NORMAL) );
            Chunk atteste=new Chunk("atteste que Mr/Mme ",FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.NORMAL));
            Chunk nom=new Chunk(""+pers.getNom()+" "+pers.getPrenom(),FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.BOLDITALIC));
            Chunk matricule1=new Chunk(" matricule  ",FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.NORMAL));
            Chunk matricule2=new Chunk(pers.getMatricule(),FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.BOLDITALIC));
            Chunk chunk=new Chunk(" "+pers.getGrade()+" nommé(e)",FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.NORMAL));
            Chunk chunk2=new Chunk(" "+pers.getStatut(),FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.BOLDITALIC));
            Chunk chunk3=new Chunk(" au Centre National de Developpement de l'Informatique",FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.NORMAL));
            Chunk chunk4=new Chunk("(CENADI) de Bafoussam par ",FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.NORMAL));
            Chunk chunk5=new Chunk(arrete,FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.BOLDITALIC));
            Chunk chunk7=new Chunk(" du Ministre des Finances, est en activite normale dans ledit centre depuis le ",FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.NORMAL));
            Chunk chunk8=new Chunk(""+dates,FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.BOLDITALIC));
            Chunk chunk9=new Chunk(" date de sa prise de service.",FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.NORMAL));      
            Chunk chunk10=new Chunk("En foi de quoi la presente attestation est etablie et ",FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.NORMAL));
            Chunk chunk11=new Chunk("delivre à l'interessé sur sa demande pour servir et valoir ce que de droit.",FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.NORMAL));
            Chunk chunk12=new Chunk("AMPLIATIONS",FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.NORMAL));
            Chunk chunk13=new Chunk("Bafoussam le ",FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.NORMAL));
            Chunk chunk14=new Chunk(""+date,FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.NORMAL));
            Chunk chunk15=new Chunk("Le Chef de Centre",FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.NORMAL));
            Chunk chunk16=new Chunk("-INTERESSE",FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.NORMAL));
            Chunk chunk17=new Chunk("-DOSSIERS",FontFactory.getFont(FontFactory.TIMES_ROMAN, 14f,Font.NORMAL));
            Paragraph para1=new Paragraph();
            para1.add(soussigne);
            //document.add(para1);
            //para1=new Paragraph();
            para1.add(atteste);
            para1.add(nom);
            para1.setAlignment(Paragraph.ALIGN_JUSTIFIED);
           // document.add(para1);
            
           // para1=new Paragraph();
            para1.add(matricule1);
            para1.add(matricule2);
            para1.add(chunk);
            //para1.setAlignment(Paragraph.ALIGN_JUSTIFIED);
            //document.add(para1);
            
           // para1=new Paragraph();
            para1.add(chunk2);
            para1.add(chunk3);
            //para1.setAlignment(Paragraph.ALIGN_JUSTIFIED);
            //document.add(para1);
            
            //para1=new Paragraph();
            para1.add(chunk4);
            para1.add(chunk5);
            //para1.setAlignment(Paragraph.ALIGN_JUSTIFIED);
            //document.add(para1);
            
            //para1=new Paragraph();
            para1.add(chunk7);
           // para1.setAlignment(Paragraph.ALIGN_JUSTIFIED);
           // document.add(para1);
            
           // para1=new Paragraph();
            para1.add(chunk8);
            para1.add(chunk9);
            document.add(para1);
            document.add(new Paragraph("     "));
            para1=new Paragraph();
            para1.add(chunk10);
            para1.add(chunk11);
            para1.setAlignment(Paragraph.ALIGN_JUSTIFIED);
            document.add(para1);
           
            para1=new Paragraph();
            para1.add(chunk13);
            para1.add(chunk14);
            para1.setAlignment(Paragraph.ALIGN_RIGHT);
            document.add(para1);
            document.add(new Paragraph("  "));
            para1=new Paragraph(chunk15);
            para1.setAlignment(Paragraph.ALIGN_RIGHT);
            document.add(para1);
            
            para1=new Paragraph(chunk12);
            chunk12.setUnderline((float) 1, -2);
            para1.setAlignment(Paragraph.ALIGN_LEFT);
            document.add(para1);
            
            para1=new Paragraph(chunk16);
            para1.setAlignment(Paragraph.ALIGN_LEFT);
            document.add(para1);
            
            para1=new Paragraph(chunk17);
            para1.setAlignment(Paragraph.ALIGN_LEFT);
            document.add(para1);
            document.close();
            int choix= JOptionPane.showConfirmDialog(fen,"voulez vous archiver le courrier");
           if(choix==0){
               int identifiant=this.bd.rechercherId("select * from courrier;");
               System.out.println(identifiant);
            Courrier doc=new Courrier(identifiant);
            CtrlEnregistreCourrier ctrl = new CtrlEnregistreCourrier(new EnregistreCourrier());
            ctrl.enregistrerCourrier(doc);
           }
          
            Desktop.getDesktop().open(new File(chemin));
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(CtrlAcceuil.class.getName()).log(Level.SEVERE, null, ex);
        } catch (DocumentException ex) {
            Logger.getLogger(CtrlAcceuil.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(CtrlAcceuil.class.getName()).log(Level.SEVERE, null, ex);
        }
           
        
    }
  
}
