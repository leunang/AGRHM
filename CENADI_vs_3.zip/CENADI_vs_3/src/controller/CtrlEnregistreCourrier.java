/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.DataBase;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.DefaultTableModel;
import model.Archive;
import model.Conges;
import model.Courrier;
import model.NonConsommable;
import model.Permissions;
import model.Session;
import view.Acceuil;
import view.AccordeConge;
import view.AccordeDroit;
import view.AccordePermissions;
import view.AjouterPersonnel;
import view.AttestationPresencePoste;
import view.CertificatRepriseService;
import view.DemandePermission;
import view.DemanderConge;
import view.EnregistreCourrier;
import view.EnregistrerMateriel;
import view.HistoriqueConges;
import view.HistoriquePermission;
import view.ModifierCompte;
import view.RechercherMateriel;
import view.Rechercher_un_Courrier;
import view.Registre_Courrier_entrant;
import view.Registre_Courrier_interne;
import view.Registre_Courrier_sortant;
import view.RepartionMateriel;
import view.Utilisateur;

/**
 *
 * @author EMME
 */
public class CtrlEnregistreCourrier implements ActionListener{
  EnregistreCourrier fenn;
   DataBase bd;
   

    public CtrlEnregistreCourrier(EnregistreCourrier fenn) {
        this.fenn = fenn;
        this.bd = new DataBase();
        
    }
  
  

    @Override
    public void actionPerformed(ActionEvent e) {
         
        Object sources = e.getSource();
        Utilisateur fenu=new Utilisateur();
        CtrlConnexion conn=new CtrlConnexion(fenu);
       
        
        if(sources == fenn.getValide()){
           String typeC = fenn.getTypeC().getText();
            String experdicteur = fenn.getExperditeur().getText();
            Date date = fenn.getDate().getDate();
            Date time = new java.sql.Date(date.getTime());
            String objet = fenn.getObjet().getText();
            String nature = fenn.getNature().getSelectedItem().toString();
            String ref = fenn.getRef().getText();
            String ref1 = fenn.getRef1().getSelectedItem().toString();
            String ref2 = fenn.getRef2().getSelectedItem().toString();
            String ref3 = fenn.getRef3().getSelectedItem().toString();
            String ref4 = fenn.getRef4().getSelectedItem().toString();
            String other=fenn.getOther().getText();
            
            
            
            if(nature=="Courrier_entrant"){
                int num = (int)fenn.getNum().getValue();
                String reference="";
                if(other.equals("")){
                    System.out.println("test zero");
                    reference=other;
                    System.out.println(reference);
                } 
                else {
                    reference =typeC+" N°";
                    System.out.println(reference);
                    if(num>0){
                        reference+=num+"/";
                        System.out.println(reference);
                    }
                    if(!ref.equals("AUCUN")){
                        reference+=ref;
                        System.out.println(reference);
                    }
                    if(!typeC.equals("")){
                        reference+="/"+typeC;
                        System.out.println(reference);
                    }
                    if(!ref1.equals("AUCUN")){
                        reference+="/"+ref1;
                        System.out.println(reference);
                    }
                    if(!ref2.equals("AUCUN")){
                        reference+="/"+ref2;
                        System.out.println(reference);
                    }
                    if(!ref3.equals("AUCUN")){
                        reference+="/"+ref3;
                        System.out.println(reference);
                    }
                    if(!ref4.equals("AUCUN")){
                        reference+="/"+ref4;
                        System.out.println(reference);
                    }
                            
                } 
                System.out.println("oici "+reference);
                String Query1= "INSERT INTO courrier(type,objet,date) VALUES ('"+typeC+"','"+objet+"','"+time+"');";
                System.out.println(Query1);
                this.bd.setDataInBd(Query1);
                int id = this.bd.rechercherid();
                
               String Query2 = "INSERT INTO courrierentrant(id,reference,Experdicteur,numOrdre) VALUES ("+id+",'"+reference+"','"+experdicteur+"',"+num+");";
              
                System.out.println(Query2);
                this.bd.setDataInBd(Query2);
            }
            else if( nature=="Courrier_Sortant"){
                int num = this.bd.recherchernumOrdre("SELECT * FROM courriersortant;");
                num++;
                 String reference="";
                if(other.equals("")){
                    System.out.println("test zero");
                    reference=other;
                    System.out.println(reference);
                } 
                else {
                    reference =typeC+" N°";
                    System.out.println(reference);
                    if(num>0){
                        reference+=num+"/";
                        System.out.println(reference);
                    }
                    if(!ref.equals("AUCUN")){
                        reference+=ref;
                        System.out.println(reference);
                    }
                    if(!typeC.equals("")){
                        reference+="/"+typeC;
                        System.out.println(reference);
                    }
                    if(!ref1.equals("AUCUN")){
                        reference+="/"+ref1;
                        System.out.println(reference);
                    }
                    if(!ref2.equals("AUCUN")){
                        reference+="/"+ref2;
                        System.out.println(reference);
                    }
                    if(!ref3.equals("AUCUN")){
                        reference+="/"+ref3;
                        System.out.println(reference);
                    }
                    if(!ref4.equals("AUCUN")){
                        reference+="/"+ref4;
                        System.out.println(reference);
                    }
                            
                } 
                String Query3= "INSERT INTO courrier(type,objet,date) VALUES ('"+typeC+"','"+objet+"','"+time+"');";
                System.out.println(Query3);
                this.bd.setDataInBd(Query3);
                int id = this.bd.rechercherid();
                
                String Query4 = "INSERT INTO courriersortant(id,reference,recepteur) VALUES ("+id+",'"+reference+"','"+experdicteur+"');";
              
                System.out.println(Query4);
                this.bd.setDataInBd(Query4);
            }
            else if(nature =="Courrier_interne"){
             int num = this.bd.recherchernumOrdre("SELECT * FROM courrierinterne;");
                num++;
                 String reference="";
                if(other.equals("")){
                    System.out.println("test zero");
                    reference=other;
                    System.out.println(reference);
                } 
                else {
                    reference =typeC+" N°";
                    System.out.println(reference);
                    if(num>0){
                        reference+=num+"/";
                        System.out.println(reference);
                    }
                    if(!ref.equals("AUCUN")){
                        reference+=ref;
                        System.out.println(reference);
                    }
                    if(!typeC.equals("")){
                        reference+="/"+typeC;
                        System.out.println(reference);
                    }
                    if(!ref1.equals("AUCUN")){
                        reference+="/"+ref1;
                        System.out.println(reference);
                    }
                    if(!ref2.equals("AUCUN")){
                        reference+="/"+ref2;
                        System.out.println(reference);
                    }
                    if(!ref3.equals("AUCUN")){
                        reference+="/"+ref3;
                        System.out.println(reference);
                    }
                    if(!ref4.equals("AUCUN")){
                        reference+="/"+ref4;
                        System.out.println(reference);
                    }
                            
                } 
                //String reference = "n°"+num+"/"+ref+"/"+typeC+"/"+ref1+"/"+ref2+"/"+ref3+"/"+ref4;
                String Query5= "INSERT INTO courrier(type,objet,date) VALUES ('"+typeC+"','"+objet+"','"+time+"');";
                System.out.println(Query5);
                this.bd.setDataInBd(Query5);
                int id = this.bd.rechercherid();
                
                
                String Query6 = "INSERT INTO courrierinterne(id,reference) VALUES ("+id+",'"+reference+"');";
              
                System.out.println(Query6);
                this.bd.setDataInBd(Query6);
        }
           
            JOptionPane.showMessageDialog(fenn,"COURRIER ENREGISTRE AVEC SUCCES", "Notification", JOptionPane.INFORMATION_MESSAGE);
           int choix= JOptionPane.showConfirmDialog(fenn,"voulez vous archiver le courrier");
           if(choix==0){
               int id=this.bd.rechercherId("select * from courrier;");
            Courrier courrier=new Courrier(id);
            this.enregistrerCourrier(courrier);
           }
        }
        else if(sources== fenn.getAnnuler()) {
            
            int i=0;
            //fenn.getNum().setValue(Integer.toString(i));
            fenn.getNum().getModel().setValue(0);
            fenn.getExperditeur().setText("");
            fenn.getObjet().setText("");
            fenn.getTypeC().setText("");
            fenn.getRef().setText("");
            fenn.getNature().getModel().setSelectedItem("");
            fenn.getRef1().getModel().setSelectedItem("");
            fenn.getRef2().getModel().setSelectedItem("");
            fenn.getRef3().getModel().setSelectedItem("");
            fenn.getRef4().getModel().setSelectedItem("");
            
           
            
        }
        
        else if(sources == fenn.getRechercherCourrier()){
            Rechercher_un_Courrier penn= new Rechercher_un_Courrier();
            penn.setVisible(true);
            fenn.dispose();
        }
        else if (sources == fenn.getRegistreCourrierEntrant()){
            Registre_Courrier_entrant jenn = new Registre_Courrier_entrant();
            jenn.setVisible(true);
            fenn.dispose();
            
        }
        else if(sources == fenn.getRegistreCourrierInterne()){
            Registre_Courrier_interne cann = new Registre_Courrier_interne();
            cann.setVisible(true);
            fenn.dispose();
        }
        else if (sources== fenn.getRegistreCourrierSortant()){
            Registre_Courrier_sortant hann = new Registre_Courrier_sortant();
            hann.setVisible(true);
            fenn.dispose();
        }
        else if(sources==fenn.getEnregisterMat()){
            if(conn.user.getMateriel().equalsIgnoreCase("OUI")|| conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                EnregistrerMateriel fenmat=new EnregistrerMateriel();
                fenmat.setVisible(true);
                fenn.dispose();
                
            } 
            else {
                JOptionPane.showMessageDialog(fenn,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
            }
        } 
        else if(sources==fenn.getFdetenteur()){
            if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")||conn.user.getMateriel().equalsIgnoreCase("OUI")){
                String mat=JOptionPane.showInputDialog(fenn,"renseigner le matricule de l'usager");
                CtrlAcceuil con=new CtrlAcceuil(new Acceuil());
                con.editFicheDetenteur(mat); 
             } 
             else {
                 JOptionPane.showMessageDialog(fenn,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
        } 
        else if(sources==fenn.getDisconnect()){
            Utilisateur fenus=new Utilisateur();
            fenus.setVisible(true);
            fenn.dispose();
        }
          else if(sources==fenn.getAccordeConge()){
            if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                DefaultTableModel model=new DefaultTableModel();
                model.addColumn("Matricule");
                model.addColumn("DEBUT");
                model.addColumn("FIN");
                model.addColumn("DECISION");
                
                String query2="select * from conges where situation='NON-TRAITE';";
                ArrayList<Conges> list=this.bd.listeConge(query2);
                for(Conges conge:list){
                    model.addRow(new Object[]{conge.getPersonnel().getMatricule(),conge.getDebut(),conge.getFin(),conge.getDecision()});
                    
                }
                AccordeConge fenac=new AccordeConge();
                fenac.setVisible(true);
                fenac.getTable().setModel(model);
                fenn.dispose();
            }
            else{
                JOptionPane.showMessageDialog(fenn,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
            }
        }
        
         else if(sources==fenn.getAccordePermission()){
            DefaultTableModel model=new DefaultTableModel();
            model.addColumn("Matricule");
            model.addColumn("Objet");
            model.addColumn("Debut");
            model.addColumn("Fin");
            model.addColumn("Decision");
            ArrayList<Permissions> list=this.bd.listPermission("select * from permissions where etat='NON-TRAITE';");
            for(Permissions perms:list){
                model.addRow(new Object[]{perms.getPersonnel().getMatricule(),perms.getObjet(),perms.getDebut(),perms.getFin(),perms.getEtat()});
                
            }
            AccordePermissions fenp=new AccordePermissions();
            fenp.getTable().setModel(model);
            fenp.setVisible(true);
            fenn.dispose();
        }
        else if(e.getSource()==fenn.getModifieCompte()) { 
            String matricule=JOptionPane.showInputDialog(fenn, "renseigner votre matricule");
            Session session=this.bd.rechercherSession("select * from session where matricule='"+matricule+"';");
            ModifierCompte fenc=new ModifierCompte();
            fenc.setVisible(true);
            fenc.getMatricule().setText(matricule);
            fenc.getOld().setEditable(true);
            fenn.dispose();
       }
        else if(sources==fenn.getAjouterPerso()){ 
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 AjouterPersonnel fenp=new AjouterPersonnel();
                 fenp.setVisible(true);
                 fenn.dispose();
             } 
             else{
                 JOptionPane.showMessageDialog(fenn,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
             
         }  
         else if(sources==fenn.getAccorderDroit()){ 
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")){ 
             DefaultTableModel model=new DefaultTableModel();
            model.addColumn("matricule");
            model.addColumn("email");
            model.addColumn("mot de passe");
            model.addColumn("administrateur");
            model.addColumn("connection");
            model.addColumn("materiel");
            model.addColumn("courrier");
            
            String query2="select *from session;";
            ArrayList<Session> list=this.bd.listerSession(query2);
            for(Session s:list){
                model.addRow(new Object[]{s.getPersonnel().getMatricule(),s.getLogin(),s.getPassword(),s.getAdministrateur(),s.getConnection(),s.getMateriel(),s.getCourrier()});
            } 
           
                 AccordeDroit fena=new AccordeDroit();
                  fena.getTable().setModel(model);
                 fena.setVisible(true);
                 fenn.dispose();
                 
             } 
             else{
                 JOptionPane.showMessageDialog(fenn,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         } 
         else if(sources==fenn.getEnregisterMat()){ 
             if(conn.user.getMateriel().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 EnregistrerMateriel fenmat=new EnregistrerMateriel();
                 fenmat.setVisible(true);
                 fenn.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fenn,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         } 
         else if(sources==fenn.getHistoConge()){ 
                DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("DEBUT");
             model.addColumn("FIN");
             model.addColumn("Etat");
             
             String query2="select * from conges ;";
             ArrayList<Conges> list=this.bd.listeConge(query2);
             for(Conges conge:list){
                 model.addRow(new Object[]{conge.getPersonnel().getMatricule(),conge.getDebut(),conge.getFin(),conge.getEtat()});
                 
             }
             HistoriqueConges fenh=new HistoriqueConges();
             fenh.getTable().setModel(model);
             fenh.setVisible(true);
             fenn.dispose();
         } 
         else if(sources==fenn.getHistoPermission()){
               DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("Objet");
             model.addColumn("Debut");
             model.addColumn("Fin");
             ArrayList<Permissions> list=this.bd.listPermission("select * from permissions;");
             for(Permissions perms:list){
                 model.addRow(new Object[]{perms.getPersonnel().getMatricule(),perms.getObjet(),perms.getDebut(),perms.getFin()});
                 
             } 
             HistoriquePermission fenh=new HistoriquePermission();
             fenh.getTable().setModel(model);
             fenh.setVisible(true);
             fenn.dispose();
         }
        else if(sources==fenn.getRechercherMat()){ 
             if(conn.user.getMateriel().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 RechercherMateriel fenrech=new RechercherMateriel();
                 fenrech.setVisible(true);
                 fenn.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fenn,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         } 
        else if(sources==fenn.getRepartitionMat()){ 
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI") || conn.user.getMateriel().equalsIgnoreCase("OUI")){
                 RepartionMateriel fenrep=new RepartionMateriel();
                 fenrep.setVisible(true);
                 DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Reference");
             model.addColumn("Nature");
             model.addColumn("Marque");
             model.addColumn("Caracteristiques");
             model.addColumn("Position");
             model.addColumn("Detenteur");
             String query1="select * from materiel,nonconsommable where materiel.reference=nonconsommable.reference and materiel.reference not in(select reference from repartition);";
             ArrayList<NonConsommable> list=this.bd.listerNonConsommables(query1);
             for(NonConsommable materiel:list){
                 model.addRow(new Object[] {materiel.getReference(),materiel.getNature(),materiel.getMarque(),materiel.getCaracteristique(),materiel.getSituation(),""});
             } 
             fenrep.getTable().setModel(model);
                 fenn.dispose();
                 
             } 
             else {
                 JOptionPane.showMessageDialog(fenn,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         } 
         
         else if(sources==fenn.getDemanderConge()){
            DemanderConge fenCon=new DemanderConge();
            fenCon.setVisible(true);
            fenn.dispose();
        }
      else if(sources==fenn.getCertificat()){
             CertificatRepriseService fenc=new CertificatRepriseService();
             fenc.setVisible(true);
             fenn.dispose();
         }
         else if(sources==fenn.getAttestation()){
             AttestationPresencePoste fenp=new AttestationPresencePoste();
             fenp.setVisible(true);
             fenn.dispose();
         }
         else if(sources==fenn.getDemanderPermission()){
            LocalDateTime current=LocalDateTime.now();
             LocalDate date=current.toLocalDate();
             String query="select * from permissions where matricule='"+conn.user.getPersonnel().getMatricule()+"'and(debut between'"+date.getYear()+"-01-01'and'"+date.getYear()+"-12-31');";
             ArrayList<Permissions> list=this.bd.listPermission(query);
             float nbre=0;
             for(Permissions perms:list){
                 long diff=perms.getFin().getTime()-perms.getDebut().getTime();
                 nbre+=(diff/(1000*60*60*24));
             } 
             if(nbre>=10){
                 JOptionPane.showMessageDialog(fenn,"ACCESS REFUSE, vous avez deja consommé vos 10 jours de congé annuel","ERROR",JOptionPane.ERROR_MESSAGE);
             } 
             else {
                 DemandePermission fenPer=new DemandePermission();
             fenPer.setVisible(true);
             fenn.dispose();
             }
        }
        
        
    }
  public void enregistrerCourrier(Courrier courrier){ 
         
        JFileChooser fileChooser=new JFileChooser();
              FileFilter fileFilter = null;
              FileFilter datFilter = null;
              String[] filters = new String[]{"docx","txt","pdf"};
              fileFilter = new ExtentionFileFilter("documents",filters);
              fileChooser.addChoosableFileFilter(fileFilter);

             // datFilter = new ExtensionFileFilter("propriété bdd","dat");
             int status = fileChooser.showDialog(null,"Sélection du fichier à sauver");

          if(status == JFileChooser.APPROVE_OPTION){
            File file = fileChooser.getSelectedFile();
            String name;
            String message = "Quel nom donner à ce fichier en base ?";
            name = JOptionPane.showInputDialog(message);
            Archive archive=new Archive(courrier, name, file);
            if(name != null)
            {
              try
              {
                this.bd.enregistrerArchive(archive);
                 
              }
              catch(Exception ex)
              {
                JOptionPane.showMessageDialog(null,"Une erreur s'est produite dans l'enregistrement de l'image.");
                ex.printStackTrace();
              }
            }
          }
        
    }  
}
