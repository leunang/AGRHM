/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import com.itextpdf.text.Chunk;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfWriter;
import dao.DataBase;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.Permission;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import jdk.nashorn.internal.objects.NativeDate;
import model.Conges;
import model.Courrier;
import model.Courrier_Interne;
import model.Permissions;
import model.Personnel;
import model.Session;
import view.Acceuil;
import view.AccordeConge;
import view.AccordeDroit;
import view.AccordePermissions;
import view.AjouterPersonnel;
import view.AttestationPresencePoste;
import view.CertificatRepriseService;
import view.DemandePermission;
import view.DemanderConge;
import view.EnregistreCourrier;
import view.EnregistrerMateriel;
import view.HistoriqueConges;
import view.HistoriquePermission;
import view.ModifierCompte;
import view.RechercherMateriel;
import view.Rechercher_un_Courrier;
import view.Registre_Courrier_entrant;
import view.Registre_Courrier_interne;
import view.Registre_Courrier_sortant;
import view.RepartionMateriel;
import view.Utilisateur;

/**
 *
 * @author Jordan
 */
public class CtrlAccordePermission implements ActionListener {
private  AccordePermissions fen;
private DataBase bd;

    public CtrlAccordePermission(AccordePermissions fen) {
        this.fen = fen;
        this.bd=new DataBase();
    }

     


    @Override
    public void actionPerformed(ActionEvent e) {
       Utilisateur fennu=new Utilisateur();
        CtrlConnexion conn=new CtrlConnexion(fennu);
        Permissions perms1=new Permissions();
         Object source=e.getSource();
         int id=0;
         if(source==fen.getValider()){ 
             String matricule=fen.getMatricule().getText();
             
             String decision=fen.getDecision().getSelectedItem().toString();
             id=this.bd.getId("select id from permissions where matricule='"+matricule+"'and etat='NON-TRAITE';");
             System.out.println("id: "+id);
             String query="update permissions set etat='"+decision+"' where matricule='"+matricule+"';";
             perms1=this.bd.rechercherPermission("select * from permissions where id="+id+";");
             System.out.println(perms1.toString());
             Personnel pers=this.bd.rechercherPersonnel("select * from personnel where matricule='"+matricule+"';");
             
             lettreDePermission(matricule,new java.sql.Date(perms1.getDebut().getTime()),new java.sql.Date(perms1.getFin().getTime()),perms1.getObjet());
             
             this.bd.setDataInBd(query);
             DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("Objet");
             model.addColumn("Debut");
             model.addColumn("Fin");
             model.addColumn("Decision");
             
             String query2="select * from permissions where etat='NON-TRAITE';";
             ArrayList<Permissions> list=this.bd.listPermission(query2);
             for(Permissions perms:list){
                 model.addRow(new Object[]{perms.getPersonnel().getMatricule(),perms.getObjet(),perms.getDebut(),perms.getFin(),perms.getEtat()});
                 
             } 
             fen.getTable().setModel(model);
             
         } 
          else if(source==fen.getAccorderDroit()){
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 DefaultTableModel model=new DefaultTableModel();
            model.addColumn("matricule");
            model.addColumn("email");
            model.addColumn("mot de passe");
            model.addColumn("administrateur");
            model.addColumn("connection");
            model.addColumn("materiel");
            model.addColumn("courrier");
            
            String query2="select *from session;";
            ArrayList<Session> list=this.bd.listerSession(query2);
            for(Session s:list){
                model.addRow(new Object[]{s.getPersonnel().getMatricule(),s.getLogin(),s.getPassword(),s.getAdministrateur(),s.getConnection(),s.getMateriel(),s.getCourrier()});
            } 
           
                 AccordeDroit fena=new AccordeDroit();
                  fena.getTable().setModel(model);
                 fena.setVisible(true);
                 fen.dispose();
                 
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
         } 
         else if(source==fen.getAjouterPerso()){  
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 AjouterPersonnel fenp=new AjouterPersonnel();
                 fenp.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
             
         } 
         else if(source==fen.getPermission()){ 
             LocalDateTime current=LocalDateTime.now();
             LocalDate date=current.toLocalDate();
             String query="select * from permissions where matricule='"+conn.user.getPersonnel().getMatricule()+"' and(debut between'"+date.getYear()+"-01-01'and'"+date.getYear()+"-12-31');";
             ArrayList<Permissions> list=this.bd.listPermission(query);
             float nbre=0;
             for(Permissions perms:list){
                 long diff=perms.getFin().getTime()-perms.getDebut().getTime();
                 nbre+=(diff/(1000*60*60*24));
             } 
             if(nbre>=10){
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE, vous avez deja consommé vos 10 jours de congé annuel","ERROR",JOptionPane.ERROR_MESSAGE);
             } 
             else {
                 DemandePermission fenPer=new DemandePermission();
             fenPer.setVisible(true);
             fen.dispose();
             }
         } 
         else if(source==fen.getConge()){
             DemanderConge fenc=new DemanderConge();
             fenc.setVisible(true);
             fen.dispose();
         } 
         else if(source==fen.getDisconnect()){
             Utilisateur fencon=new Utilisateur();
             fencon.setVisible(true);
             fen.dispose();
             
             
         } 
         else if(source==fen.getFdetenteur()){ 
             CtrlAcceuil con=new CtrlAcceuil(new Acceuil());
             String mat=JOptionPane.showInputDialog(fen,"renseigner le matricule de l'usager");
             con.editFicheDetenteur(mat);
         } 
         else if(source==fen.getRechercherMat()){ 
             RechercherMateriel fenrech=new RechercherMateriel();
             fenrech.setVisible(true);
             fen.dispose();
             
         } 
         else if(source==fen.getListerMat()){
             
         } 
         else if(source==fen.getHistoConge()){
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Exercice");
             model.addColumn("Matricule");
             model.addColumn("Debut");
             model.addColumn("Fin");
             model.addColumn("Etat");
             
             ArrayList<Conges> list=new ArrayList<Conges>();
             list=this.bd.listeConge("select * from conges;");
             for(Conges conge:list){
                 model.addRow(new Object[] {conge.getExercice(),conge.getPersonnel().getMatricule(),conge.getDebut(),conge.getFin(),conge.getEtat()});
             } 
             HistoriqueConges fenHist=new HistoriqueConges();
             fenHist.setVisible(true);
             fenHist.getTable().setModel(model);
             } 
             else{
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
         } 
         else if(source==fen.getHistoPermissions()){
                  DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("Objet");
             model.addColumn("Debut");
             model.addColumn("Fin");
             ArrayList<Permissions> list=this.bd.listPermission("select * from permissions;");
             for(Permissions perms:list){
                 model.addRow(new Object[]{perms.getPersonnel().getMatricule(),perms.getObjet(),perms.getDebut(),perms.getFin()});
                 
             } 
             fen.getTable().setModel(model);
         } 
         else if(source==fen.getaPermission()){ 
             AccordePermissions fenp=new AccordePermissions();
             fenp.setVisible(true);
             fen.dispose();
             
             
             
         } 
         else if(source==fen.getEditer()){
             String matricule=fen.getMatricule().getText();
             Personnel pers=this.bd.rechercherPersonnel("select * from personnel where matricule='"+matricule+"';");
             //Permissions perms=this.bd.rechercherPermission("select * from permissions where id="+id+";");
             System.out.println(pers.toString());
             System.out.println(perms1.toString());
             lettreDePermission(matricule,new java.sql.Date(perms1.getDebut().getTime()),new java.sql.Date(perms1.getFin().getTime()),perms1.getObjet());
             
             
         } 
         else if(source==fen.getHistoConge()){
               DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("DEBUT");
             model.addColumn("FIN");
             model.addColumn("Etat");
             
             String query2="select * from conges ;";
             ArrayList<Conges> list=this.bd.listeConge(query2);
             for(Conges conge:list){
                 model.addRow(new Object[]{conge.getPersonnel().getMatricule(),conge.getDebut(),conge.getFin(),conge.getEtat()});
                 
             }
             HistoriqueConges fenh=new HistoriqueConges();
             fenh.getTable().setModel(model);
             fenh.setVisible(true);
             fen.dispose();
         } 
         else if(source==fen.getHistoConge()){
              DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("Objet");
             model.addColumn("Debut");
             model.addColumn("Fin");
             ArrayList<Permissions> list=this.bd.listPermission("select * from permissions;");
             for(Permissions perms:list){
                 model.addRow(new Object[]{perms.getPersonnel().getMatricule(),perms.getObjet(),perms.getDebut(),perms.getFin()});
                 
             } 
             HistoriquePermission fenh=new HistoriquePermission();
             fenh.getTable().setModel(model);
             fenh.setVisible(true);
             fen.dispose();
         } 
       else if(source==fen.getEnregistrerCourrier()){
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 EnregistreCourrier fenc=new EnregistreCourrier();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
         } 
         else if(source==fen.getRegistreInterne()){ 
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 Registre_Courrier_interne fenc=new Registre_Courrier_interne();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         } 
         else if(source==fen.getRegistreSortant()){
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 Registre_Courrier_sortant fenc=new Registre_Courrier_sortant();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
         } 
         else if(source==fen.getRegistreEntrant()){ 
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 Registre_Courrier_entrant fenc=new Registre_Courrier_entrant();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         }
         else if(source==fen.getRechercherCourrier()){
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")|| conn.user.getCourrier().equalsIgnoreCase("OUI")){
                 Rechercher_un_Courrier fenr=new Rechercher_un_Courrier();
                 fenr.setVisible(true);
                 fen.dispose();
                 
             } 
             else{
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
                 
             }
         }
         else if(source==fen.getCertificat()){
             CertificatRepriseService fenc=new CertificatRepriseService();
             fenc.setVisible(true);
             fen.dispose();
         }
         else if(e.getSource()==fen.getModifierCompte()) { 
            String matricule=JOptionPane.showInputDialog(fen, "renseigner votre matricule");
            Session session=this.bd.rechercherSession("select * from session where matricule='"+matricule+"';");
            ModifierCompte fenc=new ModifierCompte();
            fenc.setVisible(true);
            fenc.getMatricule().setText(matricule);
            fenc.getOld().setEditable(true);
            fen.dispose();
            
        }
         else if(fen.getRepartitionMat()==source){
           RepartionMateriel fenrep=new RepartionMateriel();
           fenrep.setVisible(true);
           fen.dispose();
       }
         else if(source==fen.getEnregistrerMat()){
           EnregistrerMateriel fenmat=new EnregistrerMateriel();
           fenmat.setVisible(true);
           fen.dispose();
       } 
       else if(source==fen.getDisconnect()){
              Utilisateur fenu=new Utilisateur();
              fenu.setVisible(true);
              fen.dispose();
       } 
         else if(source==fen.getAttestation()){
             AttestationPresencePoste fenp=new AttestationPresencePoste();
             fenp.setVisible(true);
             fen.dispose();
         }
         else if (source == fen.getAconge()){
             AccordeConge fenac=new AccordeConge();
             fenac.setVisible(true);
             fen.dispose();
         }
         
    } 
     public void lettreDePermission(String matricule,Date debut,Date fin,String objet){
       // ArrayList<Permission> list=this.bd.listPermission("select * from")
         long diff=fin.getTime()-debut.getTime();
         float nbre=(diff / (1000*60*60*24));
             
        String home=System.getProperty("user.home");
        String separateur=System.getProperty("file.separator");
        String repertoire1="AGRHM";
        String repertoire2="GESTION DU PERSONNEL";
        String repertoire3="DEMANDE DE PERMISSION";
        String folder=home+separateur+repertoire1+separateur+repertoire2+separateur+repertoire3;
        File fichier=new File(folder);
        if(!fichier.exists()){
            fichier.mkdirs();
        } 
        String name=matricule;
        LocalDateTime current=LocalDateTime.now();
            LocalDate today=current.toLocalDate();
            Date date=Date.valueOf(today);
        String chemin=folder+separateur+name+"_"+date+".pdf";
           com.itextpdf.text.Document document=new com.itextpdf.text.Document();
        try {
            PdfWriter.getInstance( document,new FileOutputStream(chemin));
            document.open();
            document.addTitle("DEMANDE DE PERMISSIONS");
            document.addAuthor("CENTRE INFORMATIQUE DE BAFOUSSAM");
            Image img=Image.getInstance("C:\\Users\\Jordan\\Downloads\\entete2.GIF");
            document.add(img);
            int numOrdre=this.bd.recherchernumOrdre("select * from courrierinterne;");
            numOrdre++;
            String reference="N°"+numOrdre+"/2020/DP/MINFI/CENADI/CIB";
            
            Courrier_Interne courrier=new Courrier_Interne(reference, numOrdre,"demande de permission", objet,date);
            String query1="insert into courrier(type,objet,date)values('demande de permission','"+objet+"','"+date+"');";
            this.bd.setDataInBd(query1);
            int id=this.bd.rechercherid();
             String chemin2="C:\\Utilisateurs\\EMME\\AGRHM\\GESTION DU PERSONNEL\\DEMANDE DE PERMISSION\\"+name;
            String query2="insert into courrierinterne(reference,id)values('"+reference+"',"+id+");";
            this.bd.setDataInBd(query2);
            Chunk chunck=new Chunk(reference,FontFactory.getFont(FontFactory.TIMES_ROMAN, 10f,Font.BOLDITALIC));
            chunck.setUnderline((float) 1, -2);
            Paragraph pref= new Paragraph(chunck);
            pref.setAlignment(Paragraph.ALIGN_LEFT);
            document.add(pref);
            document.add(new Paragraph("    "));
            Chunk title=new Chunk("DEMANDE DE PERMISSION",FontFactory.getFont(FontFactory.TIMES_ROMAN, 30f,Font.BOLD));
            title.setUnderline((float) 1, -2);
            Paragraph pTitle=new Paragraph(title);
            pTitle.setAlignment(Paragraph.ALIGN_CENTER);
            document.add(pTitle);
            document.add(new Paragraph("  "));
            String query="select * from personnel where matricule='"+matricule+"';";
            Personnel pers=this.bd.rechercherPersonnel(query);
            Chunk chunck1=new Chunk("JE SOUSSIGNE Mr/Mme/Mlle  ",FontFactory.getFont(FontFactory.TIMES_ROMAN, 13f,Font.NORMAL) );
            Chunk chunck2=new Chunk(pers.getNom()+" "+pers.getPrenom(),FontFactory.getFont(FontFactory.TIMES_ROMAN, 13f,Font.BOLD));
            Chunk chunck3=new Chunk(", numero matricule  ",FontFactory.getFont(FontFactory.TIMES_ROMAN, 13f,Font.NORMAL));
            Chunk chunck4=new Chunk(" "+pers.getMatricule(),FontFactory.getFont(FontFactory.TIMES_ROMAN, 13f,Font.BOLD));
            Paragraph para=new Paragraph();
            para.add(chunck1);
            para.add(chunck2);
            para.add(chunck3);
            para.add(chunck4);
            Chunk chunk1=new Chunk(". Emploi tenu:  "+pers.getStatut(),FontFactory.getFont(FontFactory.TIMES_ROMAN, 13f,Font.NORMAL) );
            para.add(chunk1);
            //document.add(para2);
            //document.add(new Paragraph(" "));
            Chunk chunk2=new Chunk(", solicite de monsieur le chef du  CENTRE INFORMATIQUE DE",FontFactory.getFont(FontFactory.TIMES_ROMAN, 13f,Font.NORMAL));
            para.add(chunk2);
            Chunk chunk21=new Chunk(" BAFOUSSAM une autorisation de "+nbre+" jour(s) ouvrable(s) ",FontFactory.getFont(FontFactory.TIMES_ROMAN, 13f,Font.NORMAL));
            para.add(chunk21);
            Chunk chunk22=new Chunk("allant de ",FontFactory.getFont(FontFactory.TIMES_ROMAN, 13f,Font.NORMAL));
            Chunk chunk3=new Chunk(""+debut,FontFactory.getFont(FontFactory.TIMES_ROMAN, 13f,Font.BOLD));
            Chunk chunk4=new Chunk(" au ",FontFactory.getFont(FontFactory.TIMES_ROMAN, 13f,Font.NORMAL));
            Chunk chunk5=new Chunk(""+fin,FontFactory.getFont(FontFactory.TIMES_ROMAN, 13f,Font.BOLD));
            Chunk chunk6=new Chunk(". Cette autorisation d'absence est sollicite pour "+objet,FontFactory.getFont(FontFactory.TIMES_ROMAN, 13f,Font.NORMAL));
            //Paragraph para3=new Paragraph();
            para.add(chunk22);
            para.add(chunk3);
            para.add(chunk4);
            para.add(chunk5);
            para.add(chunk6);
            para.setAlignment(Paragraph.ALIGN_JUSTIFIED);
            document.add(para);
            document.add(new Paragraph(" "));
            document.add(new Paragraph(" "));
            Chunk chunk7=new Chunk("Bafoussam le "+today,FontFactory.getFont(FontFactory.TIMES_ROMAN, 15f,Font.NORMAL));
            Paragraph para5=new Paragraph(chunk7);
            document.add(new Paragraph("  "));
            para5.setAlignment(Paragraph.ALIGN_RIGHT);
            document.add(para5);
            document.add(new Paragraph("  "));
            Image img3=Image.getInstance("C:\\Users\\Jordan\\Downloads\\signature3.GIF");
            document.add(img3);
            document.close();
            int choix= JOptionPane.showConfirmDialog(fen,"voulez vous archiver le courrier");
           if(choix==0){
               int identifiant=this.bd.rechercherId("select * from courrier;");
            Courrier doc=new Courrier(identifiant);
            CtrlEnregistreCourrier ctrl = new CtrlEnregistreCourrier(new EnregistreCourrier());
            ctrl.enregistrerCourrier(doc);
           }
            Desktop.getDesktop().open(new File(chemin));
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(CtrlAcceuil.class.getName()).log(Level.SEVERE, null, ex);
        } catch (DocumentException ex) {
            Logger.getLogger(CtrlAcceuil.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(CtrlAcceuil.class.getName()).log(Level.SEVERE, null, ex);
        }
           
        
    }
     
     
    
}
