/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.DataBase;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Conges;
import model.NonConsommable;
import model.Permissions;
import model.Session;
import view.Acceuil;
import view.AccordeConge;
import view.AccordeDroit;
import view.AccordePermissions;
import view.AjouterPersonnel;
import view.AttestationPresencePoste;
import view.CertificatRepriseService;
import view.DemandePermission;
import view.DemanderConge;
import view.EnregistreCourrier;
import view.EnregistrerMateriel;
import view.HistoriqueConges;
import view.HistoriquePermission;
import view.ModifierCompte;
import view.RechercherMateriel;
import view.Rechercher_un_Courrier;
import view.Registre_Courrier_entrant;
import view.Registre_Courrier_interne;
import view.Registre_Courrier_sortant;
import view.RepartionMateriel;
import view.Utilisateur;

/**
 *
 * @author Jordan
 */
public class CtrlAccordeConge  implements ActionListener{ 
    AccordeConge fen;
    DataBase bd;

    public CtrlAccordeConge(AccordeConge fen) {
        this.fen = fen;
        this.bd=new DataBase();
    }

     
    

    @Override
    public void actionPerformed(ActionEvent e) { 
        Utilisateur fennu=new Utilisateur();
        CtrlConnexion conn=new CtrlConnexion(fennu);
         Object source=e.getSource();
         if(source==fen.getValider()){ 
             String matricule=fen.getMatricule().getText();
             String decision=fen.getDecision().getSelectedItem().toString();
             String query="update conges set situation='"+decision+"' where matricule='"+matricule+"';";
             this.bd.setDataInBd(query);
             DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("DEBUT");
             model.addColumn("FIN");
             model.addColumn("DECISION");
             
             String query2="select * from conges where situation='NON-TRAITE';";
             ArrayList<Conges> list=this.bd.listeConge(query2);
             for(Conges conge:list){
                 model.addRow(new Object[]{conge.getPersonnel().getMatricule(),conge.getDebut(),conge.getFin(),conge.getDecision()});
                 
             } 
             fen.getTable().setModel(model);
             
         } 
          else if(source==fen.getAccorderDroit()){
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 AccordeDroit fenD=new AccordeDroit();
                 fenD.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
         } 
         else if(source==fen.getAjouterPerso()){  
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 AjouterPersonnel fenp=new AjouterPersonnel();
                 fenp.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
             
         } 
         else if(source==fen.getPermission()){
             LocalDateTime current=LocalDateTime.now();
             LocalDate date=current.toLocalDate();
             String query="select * from permissions where matricule='"+conn.user.getPersonnel().getMatricule()+"'and(debut between'"+date.getYear()+"-01-01'and'"+date.getYear()+"-12-31');";
             ArrayList<Permissions> list=this.bd.listPermission(query);
             float nbre=0;
             for(Permissions perms:list){
                 long diff=perms.getFin().getTime()-perms.getDebut().getTime();
                 nbre+=(diff/(1000*60*60*24));
             } 
             if(nbre>=10){
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE, vous avez deja consommé vos 10 jours de congé annuel","ERROR",JOptionPane.ERROR_MESSAGE);
             } 
             else {
                 DemandePermission fenPer=new DemandePermission();
             fenPer.setVisible(true);
             fen.dispose();
             }
         } 
         else if(source==fen.getConge()){
             DemanderConge fenc=new DemanderConge();
             fenc.setVisible(true);
             fen.dispose();
         } 
         else if(source==fen.getDisconnect()){
             Utilisateur fencon=new Utilisateur();
             fencon.setVisible(true);
             fen.dispose();
             
             
         } 
         else if(source==fen.getFdetenteur()){ 
             CtrlAcceuil con=new CtrlAcceuil(new Acceuil());
             String mat=JOptionPane.showInputDialog(fen,"renseigner le matricule de l'usager");
             con.editFicheDetenteur(mat);
         } 
         else if(source==fen.getRechercherMat()){ 
             RechercherMateriel fenrech=new RechercherMateriel();
             fenrech.setVisible(true);
             fen.dispose();
             
         } 
         else if(source==fen.getListerMat()){
             
         } 
         else if(source==fen.getHistoConge()){
               DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("DEBUT");
             model.addColumn("FIN");
             model.addColumn("Etat");
             
             String query2="select * from conges ;";
             ArrayList<Conges> list=this.bd.listeConge(query2);
             for(Conges conge:list){
                 model.addRow(new Object[]{conge.getPersonnel().getMatricule(),conge.getDebut(),conge.getFin(),conge.getEtat()});
                 
             }
             HistoriqueConges fenh=new HistoriqueConges();
             fenh.getTable().setModel(model);
             fenh.setVisible(true);
             fen.dispose();
         } 
         else if(source==fen.getHistoPermissions()){
              DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("Objet");
             model.addColumn("Debut");
             model.addColumn("Fin");
             ArrayList<Permissions> list=this.bd.listPermission("select * from permissions;");
             for(Permissions perms:list){
                 model.addRow(new Object[]{perms.getPersonnel().getMatricule(),perms.getObjet(),perms.getDebut(),perms.getFin()});
                 
             } 
             HistoriquePermission fenh=new HistoriquePermission();
             fenh.getTable().setModel(model);
             fenh.setVisible(true);
             fen.dispose();
         } 
         else if(source==fen.getaPermission()){
              DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("Objet");
             model.addColumn("Debut");
             model.addColumn("Fin");
             model.addColumn("Decision");
             ArrayList<Permissions> list=this.bd.listPermission("select * from permissions where etat='NON-TRAITE';");
             for(Permissions perms:list){
                 model.addRow(new Object[]{perms.getPersonnel().getMatricule(),perms.getObjet(),perms.getDebut(),perms.getFin(),perms.getEtat()});
                 
             } 
             AccordePermissions fenp=new AccordePermissions();
             fenp.getTable().setModel(model);
             fenp.setVisible(true);
               fen.dispose();
         } 
         
         else if(source==fen.getEnregistrerCourrier()){
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 EnregistreCourrier fenc=new EnregistreCourrier();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
         } 
         else if(source==fen.getRegistreInterne()){ 
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 Registre_Courrier_interne fenc=new Registre_Courrier_interne();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         } 
         else if(source==fen.getRegistreSortant()){
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 Registre_Courrier_sortant fenc=new Registre_Courrier_sortant();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
         } 
         else if(source==fen.getRegistreEntrant()){ 
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 Registre_Courrier_entrant fenc=new Registre_Courrier_entrant();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         }
         else if(source==fen.getRechercherCourrier()){
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")|| conn.user.getCourrier().equalsIgnoreCase("OUI")){
                 Rechercher_un_Courrier fenr=new Rechercher_un_Courrier();
                 fenr.setVisible(true);
                 fen.dispose();
                 
             } 
             else{
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
                 
             }
         }
         else if(source==fen.getEnregistrerMat()){ 
             if(conn.user.getMateriel().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 EnregistrerMateriel fenmat=new EnregistrerMateriel();
                 fenmat.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         }
          else if(source==fen.getAttestation()){
             AttestationPresencePoste fenp=new AttestationPresencePoste();
             fenp.setVisible(true);
             fen.dispose();
         }
          else if(source==fen.getRepartitionMat()){ 
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI") || conn.user.getMateriel().equalsIgnoreCase("OUI")){
                 RepartionMateriel fenrep=new RepartionMateriel();
                 fenrep.setVisible(true);
                 DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Reference");
             model.addColumn("Nature");
             model.addColumn("Marque");
             model.addColumn("Caracteristiques");
             model.addColumn("Position");
             model.addColumn("Detenteur");
             String query1="select * from materiel,nonconsommable where materiel.reference=nonconsommable.reference and materiel.reference not in(select reference from repartition);";
             ArrayList<NonConsommable> list=this.bd.listerNonConsommables(query1);
             for(NonConsommable materiel:list){
                 model.addRow(new Object[] {materiel.getReference(),materiel.getNature(),materiel.getMarque(),materiel.getCaracteristique(),materiel.getSituation(),""});
             } 
             fenrep.getTable().setModel(model);
             fenrep.setVisible(true);
             fen.dispose();
                 
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         }
         else if(source==fen.getCertificate()){
             CertificatRepriseService fenc=new CertificatRepriseService();
             fenc.setVisible(true);
             fen.dispose();
         }
         else if(e.getSource()==fen.getModifieCompte()) { 
            String matricule=JOptionPane.showInputDialog(fen, "renseigner votre matricule");
            Session session=this.bd.rechercherSession("select * from session where matricule='"+matricule+"';");
            ModifierCompte fenc=new ModifierCompte();
            fenc.setVisible(true);
            fenc.getMatricule().setText(matricule);
            fenc.getOld().setEditable(true);
            fen.dispose();
            
        }
         
    }
    
}
