/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import static controller.CtrlConnexion.user;
import dao.DataBase;
import static dao.DataBase.conn;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Time;
import java.text.DateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.xml.transform.Source;
import model.Conges;
import model.Permissions;
import model.Personnel;
import model.Session;
import view.Acceuil;
import view.AccordeConge;
import view.AccordeDroit;
import view.AccordePermissions;
import view.AjouterPersonnel;
import view.AttestationPresencePoste;
import view.CertificatRepriseService;
import view.DemandePermission;
import view.DemanderConge;
import view.EnregistreCourrier;
import view.EnregistrerMateriel;
import view.HistoriqueConges;
import view.HistoriquePermission;
import view.ModifierCompte;
import view.RechercherMateriel;
import view.Rechercher_un_Courrier;
import view.Registre_Courrier_entrant;
import view.Registre_Courrier_interne;
import view.Registre_Courrier_sortant;
import view.RepartionMateriel;
import view.Utilisateur;

/**
 *
 * @author Jordan
 */
public class CtrlAjouterPersonnel implements ActionListener {
    private AjouterPersonnel fen;
    DataBase bd;
    Session user;

    public CtrlAjouterPersonnel(AjouterPersonnel fen) {
        this.fen = fen;
         this.bd=new DataBase();
         this.user = user;
    }

    @Override
    public void actionPerformed(ActionEvent e) throws IllegalArgumentException {
         Object source=e.getSource();
         /*Utilisateur fennu=new Utilisateur();
         CtrlConnexion conn=new CtrlConnexion(fennu);*/
          Utilisateur fennu=new Utilisateur();
        CtrlConnexion conn=new CtrlConnexion(fennu);
         
          if(source==fen.getValider()){
              Personnel personnel=new Personnel();
              personnel.setMatricule(fen.getMatricule().getText().trim());
              personnel.setNom(fen.getNom().getText().trim());
              //personnel.setDateNaissance(fen.getDate().getValue().toEpochDay());
              //Date now=new Date( fen.getDate().getEditor().getText());
              Date date=fen.getDate().getDate();
              System.out.println(date);
              java.sql.Date today=new java.sql.Date(date.getTime());
              System.out.println("en sql");
              System.out.println(today);
              personnel.setDateNaissance(today);
              personnel.setTelephone(Integer.parseInt(fen.getTelephone().getText().trim()));
              personnel.setStatut(fen.getStatut().getSelectedItem().toString());
              personnel.setAdresse(fen.getAdresse().getText().trim());
              personnel.setPrenom(fen.getPrenom().getText().trim());
              Session session=new Session(personnel);
              String query1="select * from personnel where matricule='"+personnel.getMatricule()+"';";
              
              Personnel pers=this.bd.rechercherPersonnel(query1);
               /*String query="insert into personnel(matricule,nom,prenom,dateNaissance,statut,adresse,Telephone)"+
                      "values('"+personnel.getMatricule()+"','"+personnel.getNom()+"','"+personnel.getPrenom()+"','"+personnel.getDateNaissance()+
                      "','"+personnel.getStatut()+"','"+personnel.getAdresse()+"',"+personnel.getTelephone()+");";
              bd.setDataInBd(query);
              JOptionPane.showMessageDialog(fen, "personnel"+personnel.toString()+"\t"+"ajouter avec success ","CONFIRM", JOptionPane.INFORMATION_MESSAGE);*/
              if(pers ==null){ 
                   
              String query="insert into personnel(matricule,nom,prenom,grade,dateNaissance,statut,adresse,Telephone)"+
                      "values('"+personnel.getMatricule()+"','"+personnel.getNom()+"','"+personnel.getPrenom()+"','"+personnel.getGrade()+"','"+personnel.getDateNaissance()+
                      "','"+personnel.getStatut()+"','"+personnel.getAdresse()+"',"+personnel.getTelephone()+");";
              bd.setDataInBd(query);
              String query2="insert into session(matricule,login,password,administrateur,connection,materiel,courrier)values('"+
                      session.getPersonnel().getMatricule()+"','"+session.getLogin()+"','"+session.getPassword()+"','"+session.getAdministrateur()+
                      "','"+session.getConnection()+"','"+session.getMateriel()+"','"+session.getCourrier()+"');";
              bd.setDataInBd(query2);
              JOptionPane.showMessageDialog(fen, "personnel"+personnel.toString()+"\t"+"ajouter avec success ","CONFIRM", JOptionPane.INFORMATION_MESSAGE);
              
                  
              }
              else {
                  JOptionPane.showMessageDialog(fen,pers.toString()+"\t"+"existe deja","existe deja",JOptionPane.ERROR_MESSAGE);
              }
              
          }
          else if(source==fen.getAnnuler()){ 
              fen.getMatricule().setText("");
              fen.getNom().setText("");
              fen.getPrenom().setText("");
              fen.getTelephone().setText("");
              fen.getAdresse().setText("");
              
              
          }
          else if(source==fen.getConge()){ 
              DemanderConge fencon=new DemanderConge();
              fencon.setVisible(true);
              fen.dispose();
              
          } 
          else if(source==fen.getaConge()){ 
               DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("DEBUT");
             model.addColumn("FIN");
             model.addColumn("DECISION");
             
             String query2="select * from conges where situation='NON-TRAITE';";
             ArrayList<Conges> list=this.bd.listeConge(query2);
             for(Conges conge:list){
                 model.addRow(new Object[]{conge.getPersonnel().getMatricule(),conge.getDebut(),conge.getFin(),conge.getDecision()});
                 
             }
             AccordeConge fenac=new AccordeConge();
             fenac.setVisible(true);
             fenac.getTable().setModel(model);
             fen.dispose();
              
          } 
          else if(source==fen.getPermission()){ 
              LocalDateTime current=LocalDateTime.now();
             LocalDate date=current.toLocalDate();
             String query="select * from permissions where matricule='"+conn.user.getPersonnel().getMatricule()+"'and(debut between'"+date.getYear()+"-01-01'and'"+date.getYear()+"-12-31');";
             ArrayList<Permissions> list=this.bd.listPermission(query);
             float nbre=0;
             for(Permissions perms:list){
                 long diff=perms.getFin().getTime()-perms.getDebut().getTime();
                 nbre+=(diff/(1000*60*60*24));
             } 
             if(nbre>=10){
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE, vous avez deja consommé vos 10 jours de congé annuel","ERROR",JOptionPane.ERROR_MESSAGE);
             } 
             else {
                 DemandePermission fenPer=new DemandePermission();
             fenPer.setVisible(true);
             fen.dispose();
             }
              
              
          } 
          else if (source==fen.getRechercherMat()){
           RechercherMateriel fenR=new RechercherMateriel();
           fenR.setVisible(true);
           fen.dispose();
       } 
        
       else if(fen.getRepartitionMat()==source){
           RepartionMateriel fenrep=new RepartionMateriel();
           fenrep.setVisible(true);
           fen.dispose();
       } 
       else if(source==fen.getFdetenteur()){
           CtrlAcceuil conn1=new CtrlAcceuil(new Acceuil());
           String mat=JOptionPane.showInputDialog(fen,"renseigner le matricule de l'usager");
             conn1.editFicheDetenteur(mat);
       } 
       else if(source==fen.getEnregistrerMat()){
           EnregistrerMateriel fenmat=new EnregistrerMateriel();
           fenmat.setVisible(true);
           fen.dispose();
       } 
       else if(source==fen.getDisconnect()){
              Utilisateur fenu=new Utilisateur();
              fenu.setVisible(true);
              fen.dispose();
       } 
       else if(source==fen.getaPermission()){
            DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("Objet");
             model.addColumn("Debut");
             model.addColumn("Fin");
             model.addColumn("Decision");
             ArrayList<Permissions> list=this.bd.listPermission("select * from permissions where etat='NON-TRAITE';");
             for(Permissions perms:list){
                 model.addRow(new Object[]{perms.getPersonnel().getMatricule(),perms.getObjet(),perms.getDebut(),perms.getFin(),perms.getEtat()});
                 
             } 
             AccordePermissions fenp=new AccordePermissions();
             fenp.getTable().setModel(model);
             fenp.setVisible(true);
               fen.dispose();
       }
        else if (source==fen.getModifierCompte()) { 
            String matricule=JOptionPane.showInputDialog(fen, "renseigner votre matricule");
            Session session=this.bd.rechercherSession("select * from session where matricule='"+matricule+"';");
           ModifierCompte fenc=new ModifierCompte();
            fenc.setVisible(true);
            fenc.getMatricule().setText(matricule);
            fenc.getOld().setEditable(true);
            fen.dispose();
            
        }
         else if(source==fen.getCertificat()){
             CertificatRepriseService fenc=new CertificatRepriseService();
             fenc.setVisible(true);
             fen.dispose();
         }
         else if(source==fen.getAttestation()){
             AttestationPresencePoste fenp=new AttestationPresencePoste();
             fenp.setVisible(true);
             fen.dispose();
         }
         else if(source==fen.getHistoConge()){
              DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("Objet");
             model.addColumn("Debut");
             model.addColumn("Fin");
             ArrayList<Permissions> list=this.bd.listPermission("select * from permissions;");
             for(Permissions perms:list){
                 model.addRow(new Object[]{perms.getPersonnel().getMatricule(),perms.getObjet(),perms.getDebut(),perms.getFin()});
                 
             } 
             HistoriquePermission fenh=new HistoriquePermission();
             fenh.getTable().setModel(model);
             fenh.setVisible(true);
             fen.dispose();
         } 
         else if(source == fen.getHistoConge()){
             HistoriqueConges fenh=new HistoriqueConges();
             fenh.setVisible(true);
             fen.dispose();
         }
         
       else if (source == fen.getAccorderDroit()){
           AccordeDroit fena=new AccordeDroit();
                 fena.setVisible(true);
                 fen.dispose();
       }
     else{
        JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
     }
         
   }   
}
