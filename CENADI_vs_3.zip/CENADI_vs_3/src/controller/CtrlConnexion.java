/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.DataBase;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Session;
import view.Acceuil;
import view.ModifierCompte;
import view.Utilisateur;

/**
 *
 * @author Jordan
 */
public class CtrlConnexion implements ActionListener { 
   private Utilisateur fen;
   private DataBase bd;
   static Session user=new Session();

    public CtrlConnexion(Utilisateur fen) {
        this.fen = fen;
        this.bd=new DataBase();
        //this.user=new Session();
    } 

   /* public Session getUser() {
        return user;
    }

    public void setUser(Session user) {
        this.user = user;
    }*/
    
    
    

    @Override
    public void actionPerformed(ActionEvent e) { 
        if(e.getSource()==fen.getValider()){ 
            String login=fen.getNom().getText().trim();
            String pwd=fen.getPassword().getText().trim();
            Session user2=new Session(login, pwd);
       
            String query="select * from session;";
            boolean correct=false;
            boolean access=false;
            ArrayList<Session> list=this.bd.listerSession(query);
            
            for(Session session:list){
                if(user2.equals(session)){
                    correct=true;
                    
                    if(session.getConnection().equalsIgnoreCase("OUI")){
                        access=true;
                        //user=session;
                        user=session;
                       /* System.out.println(session.toString());
                        System.out.println(this.user.toString());*/
                    }
                }
            } 
           // System.out.println(user.toString());
            if(correct==true){ 
                if(access==true){ 
                    if(pwd.equals("123456789")){ 
                         String matricule=JOptionPane.showInputDialog(fen,"vois devez changer votre mot de passe par defaut, entrer votre matricule");
                        ModifierCompte fenc=new ModifierCompte();
                        fenc.getMatricule().setText(matricule);
                        fenc.getOld().setText("123456789");
                        fenc.setVisible(true);
                        fen.dispose();
                        
                    } else {
                    Acceuil fenAcceuil=new Acceuil();
                    fenAcceuil.setVisible(true);
                    fen.dispose();
                    }
                    
                } 
                else {
                    JOptionPane.showMessageDialog(fen,"ACCES REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
                }
                
            } 
            else { 
                JOptionPane.showMessageDialog(fen,"login et ou mot de passe incorrect","ERROR",JOptionPane.ERROR_MESSAGE);
            }
        
            
        } 
        else if(e.getSource()==fen.getAnnuler()){ 
            fen.getNom().setText("");
            fen.getPassword().setText("");
            
        } 
        else if(e.getSource()==fen.getRenitialiser()) { 
            String matricule=JOptionPane.showInputDialog(fen, "renseigner votre matricule");
            Session session=this.bd.rechercherSession("select * from session where matricule='"+matricule+"';");
            ModifierCompte fenc=new ModifierCompte();
            fenc.setVisible(true);
            fenc.getMatricule().setText(matricule);
            fenc.getOld().setEditable(true);
            fen.dispose();
            
        }
        
        
    }
    
}
