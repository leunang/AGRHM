/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Header;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPHeaderCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.sun.prism.paint.Color;
import dao.DataBase;
import java.awt.Desktop;
//import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.event.DocumentListener;
import javax.swing.event.UndoableEditListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.Element;
import javax.swing.text.Position;
import javax.swing.text.Segment;
import model.Archive;
import model.Conges;
import model.FicheDetenteur;
import model.NonConsommable;
import model.Permissions;
import model.Personnel;
import model.Session;
import view.Acceuil;
import view.AccordeConge;
import view.AccordeDroit;
import view.AccordePermissions;
import view.AjouterPersonnel;
import view.AttestationPresencePoste;
import view.CertificatRepriseService;
import view.DemandePermission;
import view.DemanderConge;
import view.EnregistreCourrier;
import view.EnregistrerMateriel;
import view.HistoriqueConges;
import view.HistoriquePermission;
import view.ModifierCompte;
import view.RechercherMateriel;
import view.Rechercher_un_Courrier;
import view.Registre_Courrier_entrant;
import view.Registre_Courrier_interne;
import view.Registre_Courrier_sortant;
import view.RepartionMateriel;
import view.Utilisateur;

 

/**
 *
 * @author Jordan
 */
public class CtrlAcceuil implements ActionListener {  
    Acceuil fen;
    DataBase bd;

    public CtrlAcceuil(Acceuil fen) {
        this.fen = fen;
        this.bd=new DataBase();
    }
    
    
    

    @Override
    public void actionPerformed(ActionEvent e) {
         Object source=e.getSource();
         //Session session=this.bd.rechercherSession("select * from session where login='"+fen.getNom()+"';");
         Utilisateur fenu=new Utilisateur();
         CtrlConnexion conn=new CtrlConnexion(fenu);
         //Session user=conn.getUser();
         System.out.println(conn.user.toString());
          
          if(source==fen.getEnregistrercourrier()){
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 EnregistreCourrier fenc=new EnregistreCourrier();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
         } 
         else if(source==fen.getRegistreInterne()){ 
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 Registre_Courrier_interne fenc=new Registre_Courrier_interne();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         } 
         else if(source==fen.getRegistreSortant()){
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 Registre_Courrier_sortant fenc=new Registre_Courrier_sortant();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
         } 
         else if(source==fen.getRegistreEntrant()){ 
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 Registre_Courrier_entrant fenc=new Registre_Courrier_entrant();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         }
         else if(source==fen.getAjouterPerso()){ 
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 AjouterPersonnel fenp=new AjouterPersonnel();
                 fenp.setVisible(true);
                 fen.dispose();
             } 
             else{
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
             
         } 
         else if(source==fen.getAddArchive()){ 
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI") || conn.user.getCourrier().equalsIgnoreCase("OUI")){
             }
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
             
         } 
         else if(source==fen.getAccorderDroit()){ 
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")){ 
             DefaultTableModel model=new DefaultTableModel();
            model.addColumn("matricule");
            model.addColumn("email");
            model.addColumn("mot de passe");
            model.addColumn("administrateur");
            model.addColumn("connection");
            model.addColumn("materiel");
            model.addColumn("courrier");
            
            String query2="select *from session;";
            ArrayList<Session> list=this.bd.listerSession(query2);
            for(Session s:list){
                model.addRow(new Object[]{s.getPersonnel().getMatricule(),s.getLogin(),s.getPassword(),s.getAdministrateur(),s.getConnection(),s.getMateriel(),s.getCourrier()});
            } 
           
                 AccordeDroit fena=new AccordeDroit();
                  fena.getTable().setModel(model);
                 fena.setVisible(true);
                 fen.dispose();
                 
             } 
             else{
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         } 
         else if(source==fen.getEnregistrerMateriel()){ 
             if(conn.user.getMateriel().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 EnregistrerMateriel fenmat=new EnregistrerMateriel();
                 fenmat.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         } 
         else if(source==fen.getHistoConge()){ 
            
             DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("DEBUT");
             model.addColumn("FIN");
             model.addColumn("Etat");
             
             String query2="select * from conges ;";
             ArrayList<Conges> list=this.bd.listeConge(query2);
             for(Conges conge:list){
                 model.addRow(new Object[]{conge.getPersonnel().getMatricule(),conge.getDebut(),conge.getFin(),conge.getEtat()});
                 
             }
             HistoriqueConges fenh=new HistoriqueConges();
             fenh.getTable().setModel(model);
             fenh.setVisible(true);
             fen.dispose();
         } 
         else if(source==fen.getHistoPermission()){
              JOptionPane.showMessageDialog(fen,"diagnostique par les ing");
               DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("Objet");
             model.addColumn("Debut");
             model.addColumn("Fin");
             ArrayList<Permissions> list=this.bd.listPermission("select * from permissions;");
             System.out.println("essaie de resolution");
             System.out.println("taillle: "+list.size());
             for(Permissions perms:list){
                 model.addRow(new Object[]{perms.getPersonnel().getMatricule(),perms.getObjet(),perms.getDebut(),perms.getFin()});
                 
             } 
             HistoriquePermission fenh=new HistoriquePermission();
             fenh.getTable().setModel(model);
             fenh.setVisible(true);
             fen.dispose();
         }
         else if(source==fen.getDisconnect()){ 
             Utilisateur fenc=new Utilisateur(); 
             fenc.setVisible(true);
             
         } 
         else if(source==fen.getRechercherMateriel()){ 
             if(conn.user.getMateriel().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 RechercherMateriel fenrech=new RechercherMateriel();
                 fenrech.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         } 
         else if(source==fen.getRechercherArchive()){
             
         } 
         else if(source==fen.getReformerMateriel()){
             
         } 
         else if(source==fen.getRepartirMateriel()){ 
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI") || conn.user.getMateriel().equalsIgnoreCase("OUI")){
                 RepartionMateriel fenrep=new RepartionMateriel();
                 fenrep.setVisible(true);
                 DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Reference");
             model.addColumn("Nature");
             model.addColumn("Marque");
             model.addColumn("Caracteristiques");
             model.addColumn("Position");
             model.addColumn("Detenteur");
             String query1="select * from materiel,nonconsommable where materiel.reference=nonconsommable.reference and materiel.reference not in(select reference from repartition);";
             ArrayList<NonConsommable> list=this.bd.listerNonConsommables(query1);
             for(NonConsommable materiel:list){
                 model.addRow(new Object[] {materiel.getReference(),materiel.getNature(),materiel.getMarque(),materiel.getCaracteristique(),materiel.getSituation(),""});
             } 
             fenrep.getTable().setModel(model);
                 fen.dispose();
                 
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         } 
        
            
         else if(source==fen.getListePresence()){
             
         } 
        
         else if(source==fen.getListerMateriel()){ 
             
             
         } 
         
         
         else if(source==fen.getDemanderConge()){
             DemanderConge fenCon=new DemanderConge();
             fenCon.setVisible(true);
             fen.dispose();
         } 
         else if(source==fen.getDemanderPermission()){ 
             LocalDateTime current=LocalDateTime.now();
             LocalDate date=current.toLocalDate();
             String query="select * from permissions where matricule='"+conn.user.getPersonnel().getMatricule()+"'and(debut between'"+date.getYear()+"-01-01'and'"+date.getYear()+"-12-31');";
             ArrayList<Permissions> list=this.bd.listPermission(query);
             float nbre=0;
             for(Permissions perms:list){
                 long diff=perms.getFin().getTime()-perms.getDebut().getTime();
                 nbre+=(diff/(1000*60*60*24));
             } 
             if(nbre>=10){
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE, vous avez deja consommé vos 10 jours de permissions annuel","ERROR",JOptionPane.ERROR_MESSAGE);
             } 
             else {
                 DemandePermission fenPer=new DemandePermission();
             fenPer.setVisible(true);
             fen.dispose();
             }
             
         } 
         else if(source==fen.getFicheDetenteur()){ 
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")||conn.user.getMateriel().equalsIgnoreCase("OUI")){
                String mat=JOptionPane.showInputDialog(fen,"renseigner le matricule de l'usager");
                editFicheDetenteur(mat); 
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
          
         } 
         else if(source==fen.getAtestation()){
             AttestationPresencePoste fenp=new AttestationPresencePoste();
             fenp.setVisible(true);
             fen.dispose();
         }
         else if(source==fen.getAccordeConge()){ 
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                  DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("DEBUT");
             model.addColumn("FIN");
             model.addColumn("DECISION");
             
             String query2="select * from conges where situation='NON-TRAITE';";
             ArrayList<Conges> list=this.bd.listeConge(query2);
             for(Conges conge:list){
                 model.addRow(new Object[]{conge.getPersonnel().getMatricule(),conge.getDebut(),conge.getFin(),conge.getDecision()});
                 
             }
             AccordeConge fenac=new AccordeConge();
             fenac.setVisible(true);
             fenac.getTable().setModel(model);
             fen.dispose();
             }
             else{
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             } 
         } 
         else if(source==fen.getRechercherCourrier()){
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")|| conn.user.getCourrier().equalsIgnoreCase("OUI")){
                 Rechercher_un_Courrier fenr=new Rechercher_un_Courrier();
                 fenr.setVisible(true);
                 fen.dispose();
                 
             } 
             else{
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
                 
             }
         } 
         else if(source==fen.getAccorderPermission()){
              DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("Objet");
             model.addColumn("Debut");
             model.addColumn("Fin");
             model.addColumn("Decision");
             ArrayList<Permissions> list=this.bd.listPermission("select * from permissions where etat='NON-TRAITE';");
             for(Permissions perms:list){
                 model.addRow(new Object[]{perms.getPersonnel().getMatricule(),perms.getObjet(),perms.getDebut(),perms.getFin(),perms.getEtat()});
                 
             } 
             AccordePermissions fenp=new AccordePermissions();
             fenp.getTable().setModel(model);
             fenp.setVisible(true);
               fen.dispose();
         } 
         else if(e.getSource()==fen.getModifierCompte()) { 
            String matricule=JOptionPane.showInputDialog(fen, "renseigner votre matricule");
            Session session=this.bd.rechercherSession("select * from session where matricule='"+matricule+"';");
            ModifierCompte fenc=new ModifierCompte();
            fenc.setVisible(true);
            fenc.getMatricule().setText(matricule);
            fenc.getOld().setEditable(true);
            fen.dispose();
            
        }
         else if(source==fen.getCertificat()){
             CertificatRepriseService fenc=new CertificatRepriseService();
             fenc.setVisible(true);
             fen.dispose();
         }
    } 
    public   void editFicheDetenteur(String matricule){
           /*definition des repertoires*/
             
        String home=System.getProperty("user.home");
        String separateur=System.getProperty("file.separator");
        String repertoire1="AGRHM";
        String repertoire2="GESTION DU MATERIEL";
        String repertoire3="FICHES DETENTEURS";
        String folder=home+separateur+repertoire1+separateur+repertoire2+separateur+repertoire3;
        File fichier=new File(folder);
       
        if(!fichier.exists()){
            fichier.mkdirs();
        } 
        String name=matricule;
        String chemin=folder+separateur+name+".pdf";
           com.itextpdf.text.Document document=new com.itextpdf.text.Document();
             try { 
                 
                 /* creation du fichier pdf*/
                 
                 PdfWriter.getInstance( document,new FileOutputStream(chemin));
                 document.open();
                 Image img=Image.getInstance("C:\\Users\\EMME\\Documents\\NetBeansProjects\\CENADI\\src\\image\\entete2.GIF");
                 document.add(img);
                 
                 
                // document.add(new Paragraph("------------------------------------------------------------------------------------------------------------------------------------")
                // );
                 
                 String query1="select * from materiel,nonconsommable,repartition where (materiel.reference=nonconsommable.reference) and (nonconsommable.reference=repartition.reference) and (repartition.matricule='"+matricule+"');";
                 int numOrdre=this.bd.rechercherId("select * from ficheDetenteur;");
                 numOrdre++;
                 LocalDateTime currentTime=LocalDateTime.now();
                 LocalDate time=currentTime.toLocalDate();
                 Personnel pers=this.bd.rechercherPersonnel("select * from personnel where matricule='"+matricule+"';");
                 FicheDetenteur fdtenteur=new FicheDetenteur(numOrdre, pers,chemin);
                 String query2="insert into fichedetenteur(matricule,date,reference,storage) values('"+pers.getMatricule()+"','"+time+"','"+fdtenteur.getReference()+"','"+fdtenteur.getStorage()+"');";
                 this.bd.setDataInBd(query2);
                 
                 document.addAuthor("CENTRE INFORMATIQUE DE BAFOUSSAM");
                 document.addTitle("FICHE DETENTEUR DE MATERIEL");
                 
                 Chunk ck = new Chunk(fdtenteur.getReference(), FontFactory.getFont(FontFactory.TIMES_ROMAN, 20f,Font.BOLD));
                 ck.setUnderline((float) 1, -2);
                 Paragraph paragraphe1=new Paragraph(ck);
                 paragraphe1.setAlignment(Paragraph.ALIGN_CENTER);
                 document.add(paragraphe1);
                 
                 Chunk nom=new Chunk("Nom: "+pers.getNom(),FontFactory.getFont(FontFactory.TIMES_ROMAN, 10f,Font.NORMAL));
                 Paragraph paraNom=new Paragraph(nom);
                 paraNom.setAlignment(Paragraph.ALIGN_LEFT);
                 document.add(paraNom);
                 
                 Chunk prenom=new Chunk("Prenom: "+pers.getPrenom(),FontFactory.getFont(FontFactory.TIMES_ROMAN, 10f,Font.NORMAL));
                 Paragraph paraPrenom=new Paragraph(prenom);
                 paraPrenom.setAlignment(Paragraph.ALIGN_LEFT);
                 document.add(paraPrenom);
                 
                 Chunk cmatricule=new Chunk("Matricule: "+pers.getMatricule(),FontFactory.getFont(FontFactory.TIMES_ROMAN, 10f,Font.NORMAL));
                 Paragraph paraMat=new Paragraph(cmatricule);
                 paraMat.setAlignment(Paragraph.ALIGN_LEFT);
                 document.add(paraMat);
                 
                 Chunk statut=new Chunk("Statut: "+pers.getStatut(),FontFactory.getFont(FontFactory.TIMES_ROMAN, 10f,Font.NORMAL));
                 Paragraph paraStatut=new Paragraph(statut);
                 paraStatut.setAlignment(Paragraph.ALIGN_LEFT);
                 document.add(paraStatut);
                 //Chunk space=new Chunk("");
                 Paragraph space =new Paragraph("     ");
                 document.add(space);
                 int ligne=0;
                 PdfPTable table=new PdfPTable(7);
                 int [] widths = {12,12,12,32,12,10,10}; 
                 
                 table.setWidths(widths);
                 
                  //PdfPCell cellule = new PdfPCell(new Phrase("REFERENCE"));
                  PdfPCell cell1=new PdfPHeaderCell();
                  cell1.setPhrase(new Phrase("REFERENCES"));
                  table.addCell(cell1);
                  PdfPCell cell2=new PdfPHeaderCell();
       
                  cell2.setPhrase(new Phrase("NATURES"));
                  table.addCell(cell2); 
                  
                  PdfPCell cell3=new PdfPHeaderCell();
                  cell3.setPhrase(new Phrase("MARQUES"));
                  table.addCell(cell3);
                  
                  PdfPCell cell4=new PdfPHeaderCell();
                  cell4.setPhrase(new Phrase("CARACTERISTIQUES"));
                  table.addCell(cell4);
                  
                  PdfPCell cell5=new PdfPHeaderCell();
                  cell5.setPhrase(new Phrase("N°SERIES"));
                  table.addCell(cell5);
                  
                  PdfPCell cell6=new PdfPHeaderCell();
                  cell6.setPhrase(new Phrase("DATE D'AQUISITION"));
                  table.addCell(cell6);
                  
                  PdfPCell cell7=new PdfPHeaderCell();
                  cell7.setPhrase(new Phrase("ETAT"));
                  table.addCell(cell7);
                  
                 
                 ArrayList<NonConsommable> list=this.bd.listerNonConsommables(query1);
                 Chunk cktable;
                  Phrase phrase;
                
                 for(NonConsommable nc:list){
                     cktable=new Chunk(nc.getReference());
                     phrase= new Phrase(cktable);
                     table.addCell(phrase);
                     
                     cktable=new Chunk(nc.getNature());
                     phrase= new Phrase(cktable);
                     table.addCell(phrase);
                     
                     cktable=new Chunk(nc.getMarque());
                     phrase= new Phrase(cktable);
                     table.addCell(phrase);
                     
                     cktable=new Chunk(nc.getCaracteristique());
                     phrase= new Phrase(cktable);
                     table.addCell(phrase);
                     
                     cktable=new Chunk(nc.getNumSerie());
                     phrase= new Phrase(cktable);
                     table.addCell(phrase);
                     
                     cktable=new Chunk(""+nc.getDateaquisition());
                     phrase= new Phrase(cktable);
                     table.addCell(phrase);
                     
                     cktable=new Chunk(nc.getEtat());
                     phrase= new Phrase(cktable);
                     table.addCell(phrase);
                     
                      
                 } 
                 document.add(table);
                 Chunk fait=new Chunk("FAIT A BAFOUSSAM LE "+time,FontFactory.getFont(FontFactory.TIMES_ROMAN, 10f,Font.NORMAL));
                 Paragraph pFait=new Paragraph(fait);
                 pFait.setAlignment(Paragraph.ALIGN_RIGHT);
                 document.add(pFait);
                 Image img2=Image.getInstance("C:\\Users\\EMME\\Documents\\NetBeansProjects\\CENADI\\src\\image\\signature2.GIF");
                 Chunk cbaf=new Chunk("");
                 Paragraph pcbaf=new Paragraph(new Phrase(""));
                 //pcbaf.setAlignment(Paragraph.ALIGN_RIGHT);
                 document.add(pcbaf);
                 document.add(img2);
                 document.close();
                 Desktop.getDesktop().open(new File(chemin));
             } catch (FileNotFoundException ex) {
                 Logger.getLogger(CtrlAcceuil.class.getName()).log(Level.SEVERE, null, ex);
             } catch (DocumentException ex) {
                 Logger.getLogger(CtrlAcceuil.class.getName()).log(Level.SEVERE, null, ex);
             } catch (IOException ex) {
                 Logger.getLogger(CtrlAcceuil.class.getName()).log(Level.SEVERE, null, ex);
             } 
            
    } 
    
}
