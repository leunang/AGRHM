/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;


import dao.DataBase;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Conges;
import model.FicheDetenteur;
import model.Permissions;
import model.Personnel;
import model.Session;
import view.Acceuil;
import view.AccordeConge;
import view.AccordeDroit;
import view.AjouterPersonnel;
import view.CertificatRepriseService;
import view.DemandePermission;
import view.DemanderConge;
import view.EnregistreCourrier;
import view.EnregistrerMateriel;
import view.HistoriqueConges;
import view.HistoriquePermission;
import view.ModifierCompte;
import view.RechercherMateriel;
import view.Rechercher_un_Courrier;
import view.Registre_Courrier_entrant;
import view.Registre_Courrier_interne;
import view.Registre_Courrier_sortant;
import view.RepartionMateriel;
import view.Utilisateur;

/**
 *
 * @author Jordan
 */
public class CtrlAccordeDroit implements ActionListener { 
    
    AccordeDroit fen;
    DataBase bd;

    public CtrlAccordeDroit(AccordeDroit fen) {
        this.fen = fen;
        this.bd=new DataBase();
        
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        Utilisateur fennu=new Utilisateur();
        CtrlConnexion conn=new CtrlConnexion(fennu);
       Object source=e.getSource();
       if(source==fen.getValider()){
           String matricule=fen.getMatricule().getText();
           String admin=fen.getAdmin().getSelectedItem().toString();
           String connection=fen.getConnection().getSelectedItem().toString();
           String materiel=fen.getMateriel().getSelectedItem().toString();
           String courrier=fen.getCourrier().getSelectedItem().toString();
           String query="update session set administrateur='"+admin+"',connection='"+connection+"',materiel='"+materiel+"',courrier='"+courrier+"' where matricule='"+matricule+"';";
           this.bd.setDataInBd(query);
           DefaultTableModel model=new DefaultTableModel();
            model.addColumn("matricule");
            model.addColumn("email");
            model.addColumn("mot de passe");
            model.addColumn("administrateur");
            model.addColumn("connection");
            model.addColumn("materiel");
            model.addColumn("courrier");
            
            String query2="select *from session;";
            ArrayList<Session> list=this.bd.listerSession(query);
            for(Session s:list){
                model.addRow(new Object[]{s.getPersonnel().getMatricule(),s.getLogin(),s.getPassword(),s.getAdministrateur(),s.getConnection(),s.getMateriel(),s.getCourrier()});
            } 
            fen.getTable().setModel(model);
            
            String query3="select * from personnel where matricule='"+matricule+"';";
            Personnel pers=this.bd.rechercherPersonnel(query3);
            
            JOptionPane.showMessageDialog(fen,"succeffull completed for "+pers.getNom()+" "+pers.getPrenom(),"NOTIFICATION",JOptionPane.INFORMATION_MESSAGE);
       } 
      else if(source== fen.getAjouterPerso()){
           AjouterPersonnel fenp=new AjouterPersonnel();
           fenp.setVisible(true);
           fen.dispose();
       } 
      else if (source==fen.getRechercherMat()){
           RechercherMateriel fenR=new RechercherMateriel();
           fenR.setVisible(true);
           fen.dispose();
       } 
       else  if(source==fen.getDemanderPermission()){
             LocalDateTime current=LocalDateTime.now();
             LocalDate date=current.toLocalDate();
             String query="select * from permissions where matricule='"+conn.user.getPersonnel().getMatricule()+"'and(debut between'"+date.getYear()+"-01-01'and'"+date.getYear()+"-12-31');";
             ArrayList<Permissions> list=this.bd.listPermission(query);
             float nbre=0;
             for(Permissions perms:list){
                 long diff=perms.getFin().getTime()-perms.getDebut().getTime();
                 nbre+=(diff/(1000*60*60*24));
             } 
             if(nbre>=10){
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE, vous avez deja consommé vos 10 jours de congé annuel","ERROR",JOptionPane.ERROR_MESSAGE);
             } 
             else {
                 DemandePermission fenPer=new DemandePermission();
             fenPer.setVisible(true);
             fen.dispose();
             }
       } 
       else if(source==fen.getDemanderConger()){
           DemanderConge fendc=new DemanderConge();
           fendc.setVisible(true);
           fen.dispose();
       } 
       else if(fen.getRepartitionMat()==source){
           RepartionMateriel fenrep=new RepartionMateriel();
           fenrep.setVisible(true);
           fen.dispose();
       } 
       else if(source==fen.getFdetenteur()){
           CtrlAcceuil con=new CtrlAcceuil(new Acceuil());
           String mat=JOptionPane.showInputDialog(fen,"renseigner le matricule de l'usager");
             con.editFicheDetenteur(mat);
       } 
       else if(source==fen.getEnregistrerMat()){
           EnregistrerMateriel fenmat=new EnregistrerMateriel();
           fenmat.setVisible(true);
           fen.dispose();
       } 
       else if(source==fen.getDisconnect()){
              Utilisateur fenu=new Utilisateur();
              fenu.setVisible(true);
              fen.dispose();
       } 
       else if(source==fen.getAconge()){
            DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("DEBUT");
             model.addColumn("FIN");
             model.addColumn("DECISION");
             
             String query2="select * from conges where situation=NON-TRAITE;";
             ArrayList<Conges> list=this.bd.listeConge(query2);
             for(Conges conge:list){
                 model.addRow(new Object[]{conge.getPersonnel().getMatricule(),conge.getDebut(),conge.getFin(),conge.getDecision()});
                 
             }
             AccordeConge fenac=new AccordeConge();
             fenac.setVisible(true);
             fenac.getTable().setModel(model);
             fen.dispose();
       } 
        else if(source==fen.getHistoConge()){
               DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("DEBUT");
             model.addColumn("FIN");
             model.addColumn("Etat");
             
             String query2="select * from conges ;";
             ArrayList<Conges> list=this.bd.listeConge(query2);
             for(Conges conge:list){
                 model.addRow(new Object[]{conge.getPersonnel().getMatricule(),conge.getDebut(),conge.getFin(),conge.getEtat()});
                 
             }
             HistoriqueConges fenh=new HistoriqueConges();
             fenh.getTable().setModel(model);
             fenh.setVisible(true);
             fen.dispose();
         } 
         else if(source==fen.getHistoPermission()){
              DefaultTableModel model=new DefaultTableModel();
             model.addColumn("Matricule");
             model.addColumn("Objet");
             model.addColumn("Debut");
             model.addColumn("Fin");
             ArrayList<Permissions> list=this.bd.listPermission("select * from permissions;");
             for(Permissions perms:list){
                 model.addRow(new Object[]{perms.getPersonnel().getMatricule(),perms.getObjet(),perms.getDebut(),perms.getFin()});
                 
             } 
             HistoriquePermission fenh=new HistoriquePermission();
             fenh.getTable().setModel(model);
             fenh.setVisible(true);
             fen.dispose();
         } 
       else if(source==fen.getEnregistrerCourrier()){
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 EnregistreCourrier fenc=new EnregistreCourrier();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
         } 
         else if(source==fen.getRegistreInterne()){ 
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 Registre_Courrier_interne fenc=new Registre_Courrier_interne();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         } 
         else if(source==fen.getRegistreSortant()){
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 Registre_Courrier_sortant fenc=new Registre_Courrier_sortant();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
         } 
         else if(source==fen.getRegistreEntrant()){ 
             if(conn.user.getCourrier().equalsIgnoreCase("OUI") || conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 Registre_Courrier_entrant fenc=new Registre_Courrier_entrant();
                 fenc.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
         }
         else if(source==fen.getRechercherCourrier()){
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")|| conn.user.getCourrier().equalsIgnoreCase("OUI")){
                 Rechercher_un_Courrier fenr=new Rechercher_un_Courrier();
                 fenr.setVisible(true);
                 fen.dispose();
                 
             } 
             else{
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
                 
             }
         }
       else if(source==fen.getCertificat()){
             CertificatRepriseService fenc=new CertificatRepriseService();
             fenc.setVisible(true);
             fen.dispose();
         }
         else if(e.getSource()==fen.getModifierCompte()) { 
            String matricule=JOptionPane.showInputDialog(fen, "renseigner votre matricule");
            Session session=this.bd.rechercherSession("select * from session where matricule='"+matricule+"';");
            ModifierCompte fenc=new ModifierCompte();
            fenc.setVisible(true);
            fenc.getMatricule().setText(matricule);
            fenc.getOld().setEditable(true);
            fen.dispose();
            
        }
    }
    
}
