/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.DataBase;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.LocalDateTime;
//import java.sql.Date;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.NonConsommable;
import model.Permissions;
import view.Acceuil;
import view.AccordeDroit;
import view.AccordePermissions;
import view.AjouterPersonnel;
import view.AttestationPresencePoste;
import view.DemandePermission;
import view.DemanderConge;
import view.HistoriqueConges;
import view.HistoriquePermission;
import view.ModifierCompte;
import view.RechercherMateriel;
import view.RepartionMateriel;
import view.Utilisateur;

/**
 *
 * @author Jordan
 */
public class CtrlRepartionMateriel implements ActionListener{ 
    private RepartionMateriel fen;
    private DataBase bd;

    public CtrlRepartionMateriel(RepartionMateriel fen) {
        this.fen = fen;
        this.bd=new DataBase();
    }
    

    @Override
    public void actionPerformed(ActionEvent e)throws ArrayIndexOutOfBoundsException{
        Utilisateur fennu=new Utilisateur();
        CtrlConnexion conn=new CtrlConnexion(fennu);
         Object source=e.getSource();
         if(source==fen.getValider()){
             int row=fen.getTable().getRowCount();
             System.out.println(row);
             LocalDateTime currentTime=LocalDateTime.now();
             LocalDate time=currentTime.toLocalDate();
             String query="insert into repartition(matricule,reference,date)values";
             int tab[]=fen.getTable().getSelectedRows();
             System.out.println(tab);
             if(row==1){ 
                query+="('"+fen.getTable().getValueAt(1,5)+"','"+fen.getTable().getValueAt(1,0)+"','"+time+"');";
                 System.out.println(query);
             
                 }
             else {
                  for(int i=1;i<row+1;i++){ 
                 if(fen.getTable().getValueAt(i,5).equals("")){
                    //query+="('"+fen.getTable().getValueAt(i,5)+"','"+fen.getTable().getValueAt(i,0)+"','"+time+"'),";
                }
                else{ 
                    query+="('"+fen.getTable().getValueAt(i,5)+"','"+fen.getTable().getValueAt(i,0)+"','"+time+"'),";
                }   
                 
             } 
                  query=new StringBuilder(query).deleteCharAt(query.length()-1).toString();
                  query+=";";
                  System.out.println(query);
             }
            
              
         
             //query.substring(0, query.length()-1);
             
             System.out.println(query);
             int choix= JOptionPane.showConfirmDialog(fen,"confirmation requise");
              if(choix==0 ){
                  this.bd.setDataInBd(query);
                  JOptionPane.showMessageDialog(fen,"repartition effectue","AGRMH-NOTIFICATIONS",JOptionPane.INFORMATION_MESSAGE);
               } 
              else if(choix==2){ 
                  for(int i=1;i<row;i++){
                      fen.getTable().setValueAt("",i,5);
                  }
                }
              } 
         else if(source==fen.getAnnuler()){
             int row=fen.getTable().getRowCount();
             for(int i=1;i<row;i++){
                      fen.getTable().setValueAt("",i,5);
                  }
         } 
          else if(source==fen.getAccorderDroit()){
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 AccordeDroit fenD=new AccordeDroit();
                 fenD.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
         } 
         else if(source==fen.getAjouterPerso()){  
             if(conn.user.getAdministrateur().equalsIgnoreCase("OUI")){
                 AjouterPersonnel fenp=new AjouterPersonnel();
                 fenp.setVisible(true);
                 fen.dispose();
             } 
             else {
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
             }
             
             
         } 
         else if(source==fen.getPermission()){
              LocalDateTime current=LocalDateTime.now();
             LocalDate date=current.toLocalDate();
             String query="select * from permissions where matricule='"+conn.user.getPersonnel().getMatricule()+"'and(debut between'"+date.getYear()+"-01-01'and'"+date.getYear()+"-12-31');";
             ArrayList<Permissions> list=this.bd.listPermission(query);
             float nbre=0;
             for(Permissions perms:list){
                 long diff=perms.getFin().getTime()-perms.getDebut().getTime();
                 nbre+=(diff/(1000*60*60*24));
             } 
             if(nbre>=10){
                 JOptionPane.showMessageDialog(fen,"ACCESS REFUSE, vous avez deja consommé vos 10 jours de congé annuel","ERROR",JOptionPane.ERROR_MESSAGE);
             } 
             else {
                 DemandePermission fenPer=new DemandePermission();
             fenPer.setVisible(true);
             fen.dispose();
             }
         } 
         else if(source==fen.getConge()){
             DemanderConge fenc=new DemanderConge();
             fenc.setVisible(true);
             fen.dispose();
         } 
         else if(source==fen.getDisconnect()){
             Utilisateur fencon=new Utilisateur();
             fencon.setVisible(true);
             fen.dispose();
             
             
         } 
         else if(source==fen.getFdetenteur()){ 
             CtrlAcceuil con=new CtrlAcceuil(new Acceuil());
             String mat=JOptionPane.showInputDialog(fen,"renseigner le matricule de l'usager");
             con.editFicheDetenteur(mat);
         } 
         else if(source==fen.getRechercherMat()){ 
             RechercherMateriel fenrech=new RechercherMateriel();
             fenrech.setVisible(true);
             fen.dispose();
             
         } 
         else if (source == fen.getAccorderDroit()){
              if(conn.user.getAdministrateur().equalsIgnoreCase("OUI"))
              {
                  AccordeDroit fenD = new AccordeDroit();
                  fenD.setVisible(true);
                  fen.dispose();
              }
              else{
                  JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR", JOptionPane.ERROR_MESSAGE);
              }
          }
          else if (source == fen.getApermission()){
              if(conn.user.getAdministrateur().equalsIgnoreCase("OUI"))
              {
                  AccordePermissions fenP = new AccordePermissions();
                  fenP.setVisible(true);
                  fen.dispose();
              }
              else{
                  JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
              }
          }
          else if (source == fen.getAttestation()){
              if(conn.user.getAdministrateur().equalsIgnoreCase("OUI"))
              {
                  AttestationPresencePoste fenAT = new AttestationPresencePoste();
                  fenAT.setVisible(true);
                  fen.dispose();
              }
              else {
                  JOptionPane.showMessageDialog(fen,"ACCESS REFUSE","ERROR",JOptionPane.ERROR_MESSAGE);
              }
           }
          else if(source == fen.getHistoConge()){
              HistoriqueConges fenHC = new HistoriqueConges();
              fenHC.setVisible(true);
              fen.dispose();
          }
          else if(source == fen.getHistoPermission()){
              HistoriquePermission fenHP = new HistoriquePermission();
              fenHP.setVisible(true);
              fen.dispose();
          }
          else if (source == fen.getModifieCompte()){
              ModifierCompte fenMC = new ModifierCompte();
              fenMC.setVisible(true);
              fen.dispose();
          }
    }
    
}
