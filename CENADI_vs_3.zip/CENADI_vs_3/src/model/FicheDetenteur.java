/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Jordan
 */
public class FicheDetenteur { 
   private int numOrdre;
   private Personnel pers;
   Date date;
   ArrayList<NonConsommable> list;
   String reference;
   private String storage;

    public FicheDetenteur(int numOrdre, Personnel pers, Date date,String storage) {
        this.numOrdre = numOrdre;
        this.pers = pers;
        this.date = date;
        this.reference="FICHE DETENTEUR N°"+this.numOrdre+" DU "+this.date+"/MINFI/SG/CENADI/CIB";
        this.storage=storage;
    } 

    public FicheDetenteur(int numOrdre, Personnel pers,String storage) {
        this.numOrdre = numOrdre;
        this.pers = pers;
        LocalDateTime current=LocalDateTime.now();
        LocalDate date=current.toLocalDate();
        this.reference = "FICHE DETENTEUR N°"+this.numOrdre+" DU "+date+"/MINFI/SG/CENADI/CIB";
        this.list=new ArrayList<NonConsommable>();
        this.storage=storage;
    }

    public FicheDetenteur(int numOrdre, Personnel pers, Date date, String reference,String storage) {
        this.numOrdre = numOrdre;
        this.pers = pers;
        this.date = date;
        this.reference = reference;
        this.storage=storage;
    }
    

    public int getNumOrdre() {
        return numOrdre;
    }

    public void setNumOrdre(int numOrdre) {
        this.numOrdre = numOrdre;
    }

    public Personnel getPers() {
        return pers;
    }

    public void setPers(Personnel pers) {
        this.pers = pers;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public ArrayList<NonConsommable> getList() {
        return list;
    }

    public void setList(ArrayList<NonConsommable> list) {
        this.list = list;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    @Override
    public String toString() {
        return "FicheDetenteur{" + "numOrdre=" + numOrdre + ", pers=" + pers + ", date=" + date + ", list=" + list + ", reference=" + reference + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 17 * hash + this.numOrdre;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final FicheDetenteur other = (FicheDetenteur) obj;
        if (this.numOrdre != other.numOrdre) {
            return false;
        }
        return true;
    }
   public String getDateToday(){
       LocalDateTime currentTime=LocalDateTime.now();
        LocalDate time=currentTime.toLocalDate();
            String date=time.getYear()+"-";
            if(time.getMonthValue()>9){
                date+=time.getMonthValue()+"-";
            } 
            else {
                date+="0"+time.getMonthValue()+"-";
            } 
            if(time.getDayOfMonth()>9){
                date+=time.getDayOfMonth();
            } 
            else {
                date+="0"+time.getDayOfMonth();
            }
            return date;
   }

    public String getStorage() {
        return storage;
    }

    public void setStorage(String storage) {
        this.storage = storage;
    }
    
}
