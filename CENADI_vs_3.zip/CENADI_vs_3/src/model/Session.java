/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;
import static jdk.nashorn.internal.objects.NativeString.toLowerCase;

/**
 *
 * @author Jordan
 */
public class Session { 
    private Personnel personnel;
    private String login;
    private String password;
    private String administrateur;
    private String connection;
    private String materiel;
    private String courrier;

    public Session(Personnel personnel) {
        this.personnel = personnel;
        LocalDateTime currentTime=LocalDateTime.now();
        LocalDate date=currentTime.toLocalDate();
        String annee=""+date.getYear();
        String indice=new StringBuilder(annee).deleteCharAt(annee.length()-4).toString();
        indice=new StringBuilder(indice).deleteCharAt(indice.length()-3).toString();
        this.login=toLowerCase(personnel.getNom())+"."+toLowerCase(personnel.getPrenom())+indice+"@cenadi.cm";
        this.password="123456789";
        this.administrateur="NON";
        this.connection="NON";
        this.materiel="NON";
        this.courrier="NON";
        
    } 

    public Session(Personnel personnel, String login, String password, String administrateur, String connection, String materiel, String courrier) {
        this.personnel = personnel;
        this.login = login;
        this.password = password;
        this.administrateur = administrateur;
        this.connection = connection;
        this.materiel = materiel;
        this.courrier = courrier;
    }  

    public Session(String login, String password) {
        this.login = login;
        this.password = password;
        this.administrateur="NON";
        this.connection="NON";
        this.materiel="NON";
        this.courrier="NON";
    }

    public Session() { 
        this.personnel=new Personnel();
        this.administrateur="";
        this.connection="";
        this.courrier="";
        this.login="";
        this.password="";
        this.materiel="";
    }
    

    public Personnel getPersonnel() {
        return personnel;
    }

    public void setPersonnel(Personnel personnel) {
        this.personnel = personnel;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAdministrateur() {
        return administrateur;
    }

    public void setAdministrateur(String administrateur) {
        this.administrateur = administrateur;
    }

    public String getConnection() {
        return connection;
    }

    public void setConnection(String connection) {
        this.connection = connection;
    }

    public String getMateriel() {
        return materiel;
    }

    public void setMateriel(String materiel) {
        this.materiel = materiel;
    }

    public String getCourrier() {
        return courrier;
    }

    public void setCourrier(String courrier) {
        this.courrier = courrier;
    } 

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 37 * hash + Objects.hashCode(this.login);
        hash = 37 * hash + Objects.hashCode(this.password);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Session other = (Session) obj;
        if (!Objects.equals(this.login, other.login)) {
            return false;
        }
        if (!Objects.equals(this.password, other.password)) {
            return false;
        }
        return true;
    } 

    @Override
    public String toString() {
        return "Session{" + "personnel=" + personnel + ", login=" + login + ", password=" + password + ", administrateur=" + administrateur + ", connection=" + connection + ", materiel=" + materiel + ", courrier=" + courrier + '}';
    }
    
    
    
    
    
    
    
}
