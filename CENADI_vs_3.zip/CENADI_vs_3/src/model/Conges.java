/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.sql.Date;
//import java.util.Date;
import java.util.Objects;

/**
 *
 * @author Jordan
 */
public class Conges { 
    private String exercice;
    private Date debut;
    private Date fin ;
    private Personnel personnel;
    private String decision;
    private String etat;

    public Conges(String exercice, Date debut, Date fin, Personnel personnel) {
        this.exercice = exercice;
        this.debut = debut;
        this.fin = fin;
        this.personnel = personnel;
        this.etat="NON-TRAITE";
        this.decision="NON-TRAITE";
    } 

    public Conges(String exercice, Date debut, Date fin, Personnel personnel, String decision, String etat) {
        this.exercice = exercice;
        this.debut = debut;
        this.fin = fin;
        this.personnel = personnel;
        this.decision = decision;
        this.etat = etat;
    }
    

    public String getDecision() {
        return decision;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }

    public String getEtat() {
        return etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }
    

    public Conges() {
    }

    public String getExercice() {
        return exercice;
    }

    public void setExercice(String exercice) {
        this.exercice = exercice;
    }

    public Date getDebut() {
        return debut;
    }

    public void setDebut(Date debut) {
        this.debut = debut;
    }

    public Date getFin() {
        return fin;
    }

    public void setFin(Date fin) {
        this.fin = fin;
    }

    public Personnel getPersonnel() {
        return personnel;
    }

    public void setPersonnel(Personnel personnel) {
        this.personnel = personnel;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + Objects.hashCode(this.debut);
        hash = 29 * hash + Objects.hashCode(this.fin);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Conges other = (Conges) obj;
        if (!Objects.equals(this.debut, other.debut)) {
            return false;
        }
        if (!Objects.equals(this.fin, other.fin)) {
            return false;
        }
        return true;
    }

    

    @Override
    public String toString() {
        return "Conges{" + "exercice=" + exercice + ", debut=" + debut + ", fin=" + fin + ", personnel=" + personnel + '}';
    }
    
    
    
}
