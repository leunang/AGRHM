/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;

/**
 *
 * @author EMME
 */
public class Courrier {
    private String type;
    private String objet;
    private Date date;
     private int id;

    public Courrier(String type, String objet, Date date) {
        this.type = type;
        this.objet = objet;
        this.date = date;
    } 

    public Courrier(int id) {
        this.id = id;
    }

    public Courrier( String type, String objet, Date date,int id) {
        this.type = type;
        this.objet = objet;
        this.date = date;
        this.id=id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Courrier() {
    }
    

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getObjet() {
        return objet;
    }

    public void setObjet(String objet) {
        this.objet = objet;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "Courrier{" + "type=" + type + ", objet=" + objet + ", date=" + date + '}';
    }
    
    
}
