/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;
import java.util.Objects;
import java.util.logging.Logger;

/**
 *
 * @author Jordan
 */
public class Personnel { 
    private String matricule;
    private String nom;
    private String prenom;
    private String statut;
    private Date dateNaissance;
    private String adresse;
    private int telephone;
    private String grade;

    public Personnel(String matricule, String nom, String prenom,String grade ,String statut, Date dateNaissance, String adresse, int telephone) {
        this.matricule = matricule;
        this.nom = nom;
        this.prenom = prenom;
        this.statut = statut;
        this.dateNaissance = dateNaissance;
        this.adresse = adresse;
        this.telephone = telephone;
        this.grade=grade;
    } 

    public Personnel(String matricule) {
        this.matricule = matricule;
        this.nom ="";
        this.prenom ="";
        this.statut ="";
        this.dateNaissance =null;
        this.adresse ="";
        this.telephone =0000;
        this.grade="INGENIEUR INFORMATICIEN";
    }
    

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }
    

    public Personnel() {
    }

    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public Date getDateNaissance() {
        return dateNaissance;
    }

    public void setDateNaissance(Date dateNaissance) {
        this.dateNaissance = dateNaissance;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public int getTelephone() {
        return telephone;
    }

    public void setTelephone(int telephone) {
        this.telephone = telephone;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 37 * hash + Objects.hashCode(this.matricule);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Personnel other = (Personnel) obj;
        if (!Objects.equals(this.matricule, other.matricule)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "matricule :" + matricule + ", nom: " + nom + ", prenom: " + prenom + ", statut: " + statut + ", adresse: " + adresse + ", telephone: " + telephone;
    }
    private static final Logger LOG = Logger.getLogger(Personnel.class.getName());
    
    
    
    
    
}
