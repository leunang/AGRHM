/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;

/**
 *
 * @author EMME
 */
public class Courrier_Interne extends Courrier{
    private String reference;
    private int numOrdre;

    public Courrier_Interne(String reference, int numOrdre,String type, String objet, Date date, int id) {
        super(type, objet, date, id);
        this.reference = reference;
        this.numOrdre = numOrdre;
    }

    public Courrier_Interne() {
    }
    

    public Courrier_Interne(String type, String objet, Date date) {
        super(type, objet, date);
    }

    public Courrier_Interne(String reference, int numOrdre, String type, String objet, Date date) {
        super(type, objet, date);
        this.reference = reference;
        this.numOrdre = numOrdre;
    } 

    public Courrier_Interne(String reference, int numOrdre,int id) {
        super(id);
        this.reference = reference;
        this.numOrdre = numOrdre;

    }
    

    public Courrier_Interne(String reference, int numOrdre, String storage, String type, String objet, Date date) {
        super(type, objet, date);
        this.reference = reference;
        this.numOrdre = numOrdre;
    }

    
    

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public int getNumOrdre() {
        return numOrdre;
    }

    public void setNumOrdre(int numOrdre) {
        this.numOrdre = numOrdre;
    }

    @Override
    public String toString() {
        return "Courrier_Interne{" + "reference=" + reference + ", numOrdre=" + numOrdre + '}';
    }

     

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 83 * hash + this.numOrdre;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Courrier_Interne other = (Courrier_Interne) obj;
        if (this.numOrdre != other.numOrdre) {
            return false;
        }
        return true;
    }
    
}
