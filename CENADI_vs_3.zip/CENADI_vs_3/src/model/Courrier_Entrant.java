/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;

/**
 *
 * @author EMME
 */
public class Courrier_Entrant extends Courrier{
    
    private String reference;
    private String experdicteur;
    private int numOrdre;
    private int ordre;
    
    public Courrier_Entrant(String type, String objet, Date date) {
        super(type, objet, date);
    }

    public Courrier_Entrant(String reference, String experdicteur, int numOrdre, String type, String objet, Date date) {
        super(type, objet, date);
        this.reference = reference;
        this.experdicteur = experdicteur;
        this.numOrdre = numOrdre;
        
    }

    public Courrier_Entrant(String reference, String experdicteur, int numOrdre, int ordre, String type, String objet, Date date, int id) {
        super(type, objet, date, id);
        this.reference = reference;
        this.experdicteur = experdicteur;
        this.numOrdre = numOrdre;
        this.ordre = ordre;
    }
    

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getExperdicteur() {
        return experdicteur;
    }

    public void setExperdicteur(String experdicteur) {
        this.experdicteur = experdicteur;
    }

    public int getNumOrdre() {
        return numOrdre;
    }

    public void setNumOrdre(int numOrdre) {
        this.numOrdre = numOrdre;
    }

    @Override
    public String toString() {
        return "Courrier_Entrant{" + "reference=" + reference + ", experdicteur=" + experdicteur + ", numOrdre=" + numOrdre + ", ordre=" + ordre + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 11 * hash + this.ordre;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Courrier_Entrant other = (Courrier_Entrant) obj;
        if (this.ordre != other.ordre) {
            return false;
        }
        return true;
    }

  
    

    
    
    
}
