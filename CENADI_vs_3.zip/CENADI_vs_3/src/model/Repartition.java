/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;

/**
 *
 * @author Jordan
 */
public class Repartition { 
    Materiel materiel;
    Personnel pers;
    Date date ;

    public Repartition(Materiel materiel, Personnel pers, Date date) {
        this.materiel = materiel;
        this.pers = pers;
        this.date = date;
    }

    public Materiel getMateriel() {
        return materiel;
    }

    public void setMateriel(Materiel materiel) {
        this.materiel = materiel;
    }

    public Personnel getPers() {
        return pers;
    }

    public void setPers(Personnel pers) {
        this.pers = pers;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "Repartition{" + "materiel=" + materiel + ", pers=" + pers + ", date=" + date + '}';
    }
    
    
}
