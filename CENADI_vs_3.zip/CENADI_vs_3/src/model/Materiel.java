/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Objects;

/**
 *
 * @author Jordan
 */
public class Materiel { 
    private String reference;
    private String type;
    private String fond;
    private Date dateaquisition;
    private String etat;
    private int prix;
    private int qte;
    private String situation;
    

    public Materiel(int id,String type,String fond ,Date dateaquisition, String etat, int prix, int qte,String situation) {
        LocalDateTime currentTime=LocalDateTime.now();
        LocalDate date=currentTime.toLocalDate();
        if(id>1000){
            this.reference="CIB"+fond+currentTime.getYear()+id;
        } 
        else if(id<1000 && id>=100){
            this.reference="CIB"+fond+currentTime.getYear()+"0"+id;
        } 
        else if(id>=10 && id<100){
            this.reference="CIB"+fond+currentTime.getYear()+"00"+id;
        } 
        else {
            this.reference="CIB"+fond+currentTime.getYear()+"000"+id;
        }
        
        this.type = type;
        this.dateaquisition = dateaquisition;
        this.etat = etat;
        this.prix = prix;
        this.qte = qte; 
    } 

    public Materiel(String reference, String type, String fond, Date dateaquisition, String etat, int prix, int qte, String situation) {
        this.reference = reference;
        this.type = type;
        this.fond = fond;
        this.dateaquisition = dateaquisition;
        this.etat = etat;
        this.prix = prix;
        this.qte = qte;
        this.situation = situation;
    }

    public Materiel() {
    }

    public Materiel(String reference) {
        this.reference = reference;
    }
    

    public String getFond() {
        return fond;
    }

    public void setFond(String fond) {
        this.fond = fond;
    }

    public String getSituation() {
        return situation;
    }

    public void setSituation(String situation) {
        this.situation = situation;
    }
    

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getDateaquisition() {
        return dateaquisition;
    }

    public void setDateaquisition(Date dateaquisition) {
        this.dateaquisition = dateaquisition;
    }

    public String getEtat() {
        return etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }

    public int getPrix() {
        return prix;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }

    public int getQte() {
        return qte;
    }

    public void setQte(int qte) {
        this.qte = qte;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 67 * hash + Objects.hashCode(this.reference);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Materiel other = (Materiel) obj;
        if (!Objects.equals(this.reference, other.reference)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Materiel{" + "reference=" + reference + ", type=" + type + ", dateaquisition=" + dateaquisition + ", etat=" + etat + ", prix=" + prix + ", qte=" + qte + '}';
    }
    
    
    
}
