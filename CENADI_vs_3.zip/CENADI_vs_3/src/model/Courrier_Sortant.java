/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;

/**
 *
 * @author EMME
 */
public class Courrier_Sortant extends Courrier {
    private String reference;
    private String recepteur;
    private int numOrdre;

    public Courrier_Sortant(String type, String objet, Date date) {
        super(type, objet, date);
    }

    public Courrier_Sortant(String reference, String recepteur, int numOrdre, String type, String objet, Date date) {
        super(type, objet, date);
        this.reference = reference;
        this.recepteur = recepteur;
        this.numOrdre = numOrdre;
    }

    public Courrier_Sortant(String reference, String recepteur, int numOrdre, String type, String objet, Date date, int id) {
        super(type, objet, date, id);
        this.reference = reference;
        this.recepteur = recepteur;
        this.numOrdre = numOrdre;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getRecepteur() {
        return recepteur;
    }

    public void setRecepteur(String recepteur) {
        this.recepteur = recepteur;
    }

    public int getNumOrdre() {
        return numOrdre;
    }

    public void setNumOrdre(int numOrdre) {
        this.numOrdre = numOrdre;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 89 * hash + this.numOrdre;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Courrier_Sortant other = (Courrier_Sortant) obj;
        if (this.numOrdre != other.numOrdre) {
            return false;
        }
        return true;
    }
 
    @Override
    public String toString() {
        return "Courrier_Sortant{" + "reference=" + reference + ", recepteur=" + recepteur + ", numOrdre=" + numOrdre + '}';
    }
    
}
