/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;

/**
 *
 * @author Jordan
 */
public class Consommable extends Materiel {  
    private String numSerie;
    private String nature;
    private String marque;

    public Consommable(String numSerie, String nature, String marque, int id, String type, String fond, Date dateaquisition, String etat, int prix, int qte, String situation) {
        super(id, type, fond, dateaquisition, etat, prix, qte, situation);
        this.numSerie = numSerie;
        this.nature = nature;
        this.marque = marque;
    }

     

    public String getNumSerie() {
        return numSerie;
    }

    public void setNumSerie(String numSerie) {
        this.numSerie = numSerie;
    }

    public String getNature() {
        return nature;
    }

    public void setNature(String nature) {
        this.nature = nature;
    }

    public String getMarque() {
        return marque;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }

   
    
    
    
}
