/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.time.LocalDate;
import java.util.Date;
import java.util.Objects;
import javafx.util.converter.LocalDateStringConverter;

/**
 *
 * @author Jordan
 */
public class Permissions { 
    private String objet;
    private Date debut;
    private Date fin;
    private Personnel personnel;
    private String etat;

    public Permissions(String objet, Date debut, Date fin, Personnel personnel) {
        this.objet = objet;
        this.debut = debut;
        this.fin = fin;
        this.personnel = personnel;
    } 

    public Permissions(String objet, Date debut, Date fin, Personnel personnel, String etat) {
        this.objet = objet;
        this.debut = debut;
        this.fin = fin;
        this.personnel = personnel;
        this.etat = etat;
    }
    

    public Personnel getPersonnel() {
        return personnel;
    }

    public void setPersonnel(Personnel personnel) {
        this.personnel = personnel;
    }

    public String getEtat() {
        return etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }
    

    public Permissions() {
    }

    
 
    public String getObjet() {
        return objet;
    }

    public void setObjet(String objet) {
        this.objet = objet;
    }

    public Date getDebut() {
        return debut;
    }

    public void setDebut(Date debut) {
        this.debut = debut;
    }

    public Date getFin() {
        return fin;
    }

    public void setFin(Date fin) {
        this.fin = fin;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.objet);
        hash = 97 * hash + Objects.hashCode(this.debut);
        hash = 97 * hash + Objects.hashCode(this.fin);
        hash = 97 * hash + Objects.hashCode(this.personnel);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Permissions other = (Permissions) obj;
        if (!Objects.equals(this.objet, other.objet)) {
            return false;
        }
        if (!Objects.equals(this.debut, other.debut)) {
            return false;
        }
        if (!Objects.equals(this.fin, other.fin)) {
            return false;
        }
        if (!Objects.equals(this.personnel, other.personnel)) {
            return false;
        }
        return true;
    }

     
    @Override
    public String toString() {
        return "Permissions{" + "objet=" + objet + ", debut=" + debut + ", fin=" + fin + '}';
    }
    
    
    
    
    
}
