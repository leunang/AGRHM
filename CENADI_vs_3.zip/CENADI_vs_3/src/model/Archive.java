/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.File;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 *
 * @author EMME
 */
public class Archive {
    
    private String nom;
    private File file;
    private Date date;
    
   private Courrier cou;

    public Archive(Courrier courrier, String nom, File file) {
        this.cou = courrier;
        this.nom = nom;
        this.file = file;
        LocalDateTime local = LocalDateTime.now();
        LocalDate ld = local.toLocalDate();
        this.date=Date.valueOf(ld);
         
    }

    public Archive(Courrier courrier, String nom, File file, Date date) {
        this.cou = courrier;
        this.nom = nom;
        this.file = file;
        this.date = date;
        this.cou = cou;
    }

    
    
 public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Courrier getCou() {
        return cou;
    }

    public void setCou(Courrier cou) {
        this.cou = cou;
    }
   
}
