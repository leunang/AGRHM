/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

 
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Archive;
import model.Conges;
import model.Courrier;
import model.Courrier_Entrant;
import model.Courrier_Interne;
import model.Courrier_Sortant;
import model.Materiel;
import model.NonConsommable;
import model.Permissions;
import model.Personnel;
import model.Repartition;
import model.Session;

/**
 *
 * @author Jordan
 */
public class DataBase { 
    public static String nomDuDriver = "com.mysql.jdbc.Driver";
    public static String urlBd = "jdbc:mysql://150.120.10.102:3306/cenadi2";
    public static String userBd = "root"; 
    public static String pwdBd = "";
    
    public static Connection conn;
    public static Statement stmt;
    public static ResultSet rs; 
    public static ResultSetMetaData rsmd;
    
    
    public void connectionBd() { 
        String host="150.120.10.102";
        int port=3306;
         
        TimeServer ts = new TimeServer(host, port);
        ts.open();
        System.out.println("Serveur initialisé.");
        Thread t = null;
        try {
            t = new Thread((Runnable) new ClientConnexion(host, port));
        } catch (IOException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
         t.start();
        ClientProcessor cp=new ClientProcessor(null);
        //this.urlBd=cp.getParametre();
        try {
            Class.forName(nomDuDriver);
        } catch (ClassNotFoundException ex) { 
            System.err.println(ex.getMessage());
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
        try { 
            System.out.println("url: "+ClientProcessor.url);
            System.out.println("url: "+urlBd);
            
            conn=DriverManager.getConnection(urlBd,userBd,pwdBd);
        } catch (SQLException ex) { 
            System.err.println(ex.getMessage());     
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
    } 
     public void setDataInBd(String query){
         connectionBd();
         
         try { 
            stmt =conn.createStatement();            
            try {
            stmt.executeUpdate(query); 
            }
            catch (SQLException  exc) {
                System.err.println(exc.getMessage());
            }
        } 
        catch (SQLException exc) {
            System.err.println( exc.getMessage());
        }  
         if(conn!=null){
            try {
                conn.close();
               // System.out.println("deconnection etablit");
            } catch (SQLException ex) {
                Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
                System.err.println("deconnection non etablit");
            }
        }
     } 
     public ArrayList<Personnel> listerPersonnel(String query){ 
         ArrayList<Personnel> list=new ArrayList<Personnel>();
         connectionBd();
        try {
            stmt=conn.createStatement();
            rs=stmt.executeQuery(query);
            while(rs.next()){
                Personnel pers=new Personnel(rs.getString("matricule"),rs.getString("nom"),rs.getString("prenom"),rs.getString("grade"),rs.getString("statut"),rs.getDate("dateNaissance"),rs.getString("adresse"),rs.getInt("telephone"));
                list.add(pers);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
         return list;
     } 
     public Personnel rechercherPersonnel(String query){ 
          connectionBd();
          Personnel pers = null;
        try {
             stmt=conn.createStatement(); 
           try{ 
                System.out.println("etape 2");
                rs=stmt.executeQuery(query);
            while(rs.next()){ 
                System.out.println("etape 3");
                 pers=new Personnel(rs.getString("matricule"),rs.getString("nom"),rs.getString("prenom"),rs.getString("grade"),rs.getString("statut"),rs.getDate("dateNaissance"),rs.getString("adresse"),rs.getInt("telephone"));
                System.out.println("bravo");
            }
            } 
            catch (SQLException ex){ 
                System.err.println(ex.getMessage());
                
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println(ex.getMessage());
        } 
        return pers;
     } 
     public ArrayList<Session> listerSession(String query){
        Session session = null;
        ArrayList<Session> list =new ArrayList<Session>();
        connectionBd();
        try {
            //System.out.println("cherchons erreur");
            stmt=conn.createStatement(); 
            //System.out.println("etape 1");
            
            try{ 
                //System.out.println("etape 2");
                rs=stmt.executeQuery(query);
            while(rs.next()){ 
                //System.out.println("etape 3");
                 Personnel pers=new Personnel(rs.getString("matricule"));
                 session=new Session(pers, rs.getString("login"),rs.getString("password"),rs.getString("administrateur"),rs.getString("connection"),rs.getString("materiel"),rs.getString("courrier"));
                //System.out.println("bravo");
                 list.add(session);
            }
            } 
            catch (SQLException ex){ 
                System.err.println(ex.getMessage());
                
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println(ex.getMessage());
        } 
        return list;
     }
  public int rechercherId(String query){
      int id=0;
      connectionBd();
        try {
            //System.out.println("cherchons erreur");
            stmt=conn.createStatement(); 
            //System.out.println("etape 1");
            
            try{ 
                //System.out.println("etape 2");
                rs=stmt.executeQuery(query);
            while(rs.next()){ 
                //System.out.println("etape 3");
                // pers=new Personnel(rs.getString("matricule"),rs.getString("nom"),rs.getString("prenom"),rs.getString("statut"),rs.getDate("dateNaissance"),rs.getString("adresse"),rs.getInt("telephone"));
                //System.out.println("bravo");
                id++;
            }
            } 
            catch (SQLException ex){ 
                System.err.println(ex.getMessage());
                
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println(ex.getMessage());
        } 
      
      return id;
  } 
  public ArrayList<NonConsommable> listerNonConsommables(String query){
         ArrayList<NonConsommable> list=new ArrayList<NonConsommable>();
         
          connectionBd();
        try {
            //System.out.println("cherchons erreur");
            stmt=conn.createStatement(); 
            //System.out.println("etape 1");
            
            try{ 
                //System.out.println("etape 2");
                rs=stmt.executeQuery(query);
            while(rs.next()){ 
                 NonConsommable materiel=new NonConsommable(rs.getString("numSerie"),rs.getString("nature"),rs.getString("marque"),rs.getString("caracteristique"),rs.getString("reference"),rs.getString("type"),rs.getString("fond"),rs.getDate("dateAquisition"),rs.getString("etat"),rs.getInt("prix"),1,rs.getString("situation"));
                 list.add(materiel);
            }
            } 
            catch (SQLException ex){ 
                System.err.println(ex.getMessage());
                
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println(ex.getMessage());
        } 
         
      
      return list;
  } 
  public NonConsommable rechercherMateriel(String query){ 
      
       NonConsommable materiel = null;
       connectionBd();
        try {
            //System.out.println("cherchons erreur");
            stmt=conn.createStatement(); 
            //System.out.println("etape 1");
            
            try{ 
                //System.out.println("etape 2");
                rs=stmt.executeQuery(query);
            while(rs.next()){ 
                 materiel=new NonConsommable(rs.getString("numSerie"),rs.getString("nature"),rs.getString("marque"),rs.getString("caracteristique"),rs.getString("reference"),"NON-CONSOMMABLE",rs.getString("fond"),rs.getDate("dateAquisition"),rs.getString("etat"),rs.getInt("prix"),1,rs.getString("situation"));
                 
            }
            } 
            catch (SQLException ex){ 
                System.err.println(ex.getMessage());
                
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println(ex.getMessage());
        } 
         
      return materiel;
  } 
  public Repartition getRepartition(String query){
    Repartition repartition=null;
      connectionBd();
        try {
            //System.out.println("cherchons erreur");
            stmt=conn.createStatement(); 
            //System.out.println("etape 1");
            
            try{ 
                //System.out.println("etape 2");
                rs=stmt.executeQuery(query);
            while(rs.next()){ 
                 //NonConsommable materiel=new NonConsommable(rs.getString("numSerie"),rs.getString("nature"),rs.getString("marque"),rs.getString("caracteristique"),rs.getString("reference"),rs.getString("type"),rs.getString("fond"),rs.getDate("dateAquisition"),rs.getString("etat"),rs.getInt("prix"),1,rs.getString("situation"));
                 //list.add(materiel);
                repartition=new Repartition(new Materiel(rs.getString("reference")),new Personnel(rs.getString("matricule")),rs.getDate("date"));
            }
            } 
            catch (SQLException ex){ 
                System.err.println(ex.getMessage());
                
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println(ex.getMessage());
        } 
         
      
      return repartition;
  } 
  
  public Session rechercherSession(String query){
      Session session = null;
      connectionBd();
        try {
            stmt=conn.createStatement();  
            try{ 
                rs=stmt.executeQuery(query);
            while(rs.next()){ 
                 Personnel pers=new Personnel(rs.getString("matricule"));
                 session=new Session(pers, rs.getString("login"),rs.getString("password"),rs.getString("administrateur"),rs.getString("connection"),rs.getString("materiel"),rs.getString("courrier"));
               
            }
            } 
            catch (SQLException ex){ 
                System.err.println(ex.getMessage());
                
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println(ex.getMessage());
        } 
      
      
      return session;
  }
  public ArrayList<Conges> listeConge(String query) { 
      ArrayList<Conges> list=new ArrayList<Conges>();
      connectionBd();
        try {
            stmt=conn.createStatement();
            rs=stmt.executeQuery(query);
            while(rs.next()){
                Conges conge=new Conges(rs.getString("exercice"),rs.getDate("debut"),rs.getDate("fin"),new Personnel(rs.getString("matricule")),rs.getString("situation"),rs.getString("etat"));
                list.add(conge);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
      return list;
      
  } 
  public Conges rechercherConges(String query){
      Conges conge=new Conges();
      connectionBd();
        try {
            stmt=conn.createStatement();
            rs=stmt.executeQuery(query);
            while(rs.next()){
                conge=new Conges(rs.getString("exercice"),rs.getDate("debut"),rs.getDate("fin"),new Personnel(rs.getString("matricule")),rs.getString("situation"),rs.getString("etat"));
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
      return conge;
  }
  public ArrayList<Permissions> listPermission(String query){
      ArrayList<Permissions> list=new ArrayList<Permissions>();
      connectionBd();
        try {
            stmt=conn.createStatement();
            rs=stmt.executeQuery(query);
            while(rs.next()){
                Permissions perms=new Permissions(rs.getString("objet"),rs.getDate("debut"),rs.getDate("fin"),new Personnel(rs.getString("matricule")),rs.getString("etat"));
                System.out.println(perms.toString());
                list.add(perms);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
      
      return list;
      
  } 
  public int recherchernumOrdre(String Query){
         int numOrdre = 0;
         connectionBd();
         try {
             stmt = conn.createStatement();
             rs = stmt.executeQuery(Query);
             while(rs.next()){
                 numOrdre++;
             }
         } catch (SQLException ex) {
             Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
         }
         return numOrdre;
     } 
     public ArrayList <Courrier_Entrant> listCourriersE(String query){
         ArrayList <Courrier_Entrant> list = new ArrayList<Courrier_Entrant>();
         connectionBd();
         try {
             stmt = conn.createStatement();
             rs = stmt.executeQuery(query);
             while(rs.next()){ 
                 Courrier_Entrant courrier=new Courrier_Entrant(rs.getString("reference"),rs.getString("experdicteur"),rs.getInt("numOrdre"),rs.getString("type"),rs.getString("objet"),rs.getDate("date"));
                 list.add(courrier);
             }
         } catch (SQLException ex) {
             Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
             System.out.println(ex.getMessage());
         }
         return list;
     }
     
     public ArrayList<Courrier_Sortant> listCourriersS(String query1){
     ArrayList<Courrier_Sortant> list = new ArrayList<Courrier_Sortant>();
     connectionBd();
        try{
                stmt = conn.createStatement();
                rs= stmt.executeQuery(query1);
    
     while(rs.next()){
         Courrier_Sortant courrier = new Courrier_Sortant (rs.getString("reference"),rs.getString("recepteur"),rs.getInt("numOrdre"),rs.getString("type"),rs.getString("objet"),rs.getDate("date"));
         list.add(courrier);
     }
     } catch ( SQLException ex){
         Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
         System.out.println(ex.getMessage());
       
         
     }
         return list;
     }

    public ArrayList<Courrier_Interne> listCourriersI(String query2) {
    ArrayList<Courrier_Interne> list = new ArrayList<Courrier_Interne>();
    connectionBd();
    
        try{
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query2);
            
         while(rs.next()){
            Courrier_Interne courrier = new Courrier_Interne(rs.getString("reference"),rs.getInt("numOrdre"),rs.getString("type"),rs.getString("objet"),rs.getDate("date"));
            list.add(courrier);
        }
        } catch(SQLException ex){
             Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
         System.out.println(ex.getMessage());
        }
        return list;
    } 
    public int rechercherid(){
         int id = 0;
         connectionBd();
         try {
             stmt = conn.createStatement();
             rs = stmt.executeQuery("SELECT * FROM Courrier;");
             while(rs.next()){
                 id++;
             }
         } catch (SQLException ex) {
             Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
         }
         return id;
     } 
    public int getId(String query){
        int id=0;
        connectionBd();
        try {
            stmt=conn.createStatement();
            rs=stmt.executeQuery(query);
            while(rs.next()){
                id=rs.getInt("id");
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return id;
    }
    public void chargerFichier(String name, String location, Date date){ 
        connectionBd();
        
    }
public Permissions rechercherPermission(String query){
    Permissions perms=new Permissions();
    connectionBd();
        try {
            stmt=conn.createStatement();
            rs=stmt.executeQuery(query);
            while(rs.next()){
                perms=new Permissions(rs.getString("objet"),rs.getDate("debut"),rs.getDate("fin"),new Personnel(rs.getString("matricule")),rs.getString("etat"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    return perms;
} 
public Courrier_Interne rechercherCourrierI(String query){
   Courrier_Interne courrier=new Courrier_Interne();
   connectionBd();
    
        try{
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            
         while(rs.next()){
           courrier = new Courrier_Interne(rs.getString("reference"),rs.getInt("numOrdre"),rs.getString("type"),rs.getString("objet"),rs.getDate("date"),rs.getInt("id"));
           System.out.println("oullla");
           
        }
        } catch(SQLException ex){
             Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
         System.out.println(ex.getMessage());
        }
   return courrier;
}
public void enregistrerArchive(Archive archive) {
        connectionBd();
        
        try { 
            File fichier=new File(archive.getFile().getAbsolutePath());
            FileInputStream monFichier=new FileInputStream(archive.getFile());
            PreparedStatement ps=conn.prepareStatement("insert into archives(name,idc,file)values(?,?,?)");
            ps.setString(1,archive.getNom());
            System.out.println("idcourrier "+ archive.getCou().getId());
            ps.setInt(2,archive.getCou().getId());
            ps.setBinaryStream(3, monFichier,fichier.length());
            ps.executeUpdate();
            ps.close();
            monFichier.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
        
    } 
    public void chargerAchive(int id,String location){
        File monImage = new File(location);
  FileOutputStream ostreamImage = null;
        try {
            ostreamImage = new FileOutputStream(monImage);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
            
  try{
    PreparedStatement ps = conn.prepareStatement("select file from archives where idc=?");

    try {
      ps.setInt(1,id);
      ResultSet rs = ps.executeQuery();
      
      try{
        if(rs.next()){
      	  InputStream istreamImage = rs.getBinaryStream("file");
      
      	  byte[] buffer = new byte[1024];
      	  int length = 0;
	
      	  while((length = istreamImage.read(buffer)) != -1){
      	    ostreamImage.write(buffer, 0, length);
	  }
  	}
      }
        catch (IOException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
        }      finally {
        rs.close();
      }
    }
    finally{
      ps.close();
        
    }
  }
        catch (SQLException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
        }  finally{
            try {
                ostreamImage.close();
            } catch (IOException ex) {
                Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
            }
  } 
  
    }

}
