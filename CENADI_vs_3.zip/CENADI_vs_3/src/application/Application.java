/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package application;

import com.mysql.jdbc.Buffer;
import dao.DataBase;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import model.Conges;
import view.AjouterPersonnel;
import view.HistoriquePermission;
import view.Utilisateur;



/**
 *
 * @author Jordan
 */
public class Application { 
    public static void main(String [] args){
        //AjouterPersonnel fen=new AjouterPersonnel();
        Utilisateur fen1=new Utilisateur();
        //HistoriquePermission fenp=new HistoriquePermission();
        fen1.setVisible(true);
        DataBase bd=new DataBase();
        LocalDateTime current=LocalDateTime.now();
        LocalDate today=current.toLocalDate();
        Date date=Date.valueOf(today);
        //Date debut=null;
        //Date fin=null;

        ArrayList<Conges> list1=bd.listeConge("select * from conges where situation='ACCORDE';");
        for(Conges conges:list1){ 
           Date debut=conges.getDebut();
           Date fin=conges.getFin();
            int test1=debut.compareTo(date);
            int test2=fin.compareTo(date);

            if(test1<=0){ 
                if(test2>=0){
                    String query="update conges set etat='EN COURS' where matricule='"+conges.getPersonnel().getMatricule()+"' and debut='"+debut+"';";
                bd.setDataInBd(query);
                } 
                else{
                    String query="update conges set etat='TERMINE' where matricule='"+conges.getPersonnel().getMatricule()+"' and debut='"+debut+"';";
                    bd.setDataInBd(query);
                }
                
            }
        }
    }
    
}
