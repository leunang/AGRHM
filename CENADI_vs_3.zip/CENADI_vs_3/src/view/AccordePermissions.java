/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.CtrlAccordePermission;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JTable;
import javax.swing.JTextField;

/**
 *
 * @author Jordan
 */
public class AccordePermissions extends javax.swing.JFrame {

    /**
     * Creates new form AccordePermissions
     */
    public AccordePermissions() {
        initComponents();
        this.setLocationRelativeTo(this);
        CtrlAccordePermission conn=new CtrlAccordePermission(this);
        this.valider.addActionListener(conn);
        this.annuler.addActionListener(conn);
        this.editer.addActionListener(conn);
        this.ajouterPerso.addActionListener(conn);
        this.conge.addActionListener(conn);
        this.enregistrerMat.addActionListener(conn);
        this.rechercherMat.addActionListener(conn);
        this.repartitionMat.addActionListener(conn);
        this.fdetenteur.addActionListener(conn);
        this.disconnect.addActionListener(conn);
        this.rechercherCourrier.addActionListener(conn);
        this.enregistrerCourrier.addActionListener(conn);
        this.registreEntrant.addActionListener(conn);
        this.registreInterne.addActionListener(conn);
        this.registreSortant.addActionListener(conn);
        this.histoConge.addActionListener(conn);
        this.histoPermissions.addActionListener(conn);
        this.attestation.addActionListener(conn);
        this.Certificat.addActionListener(conn);
        this.ModifierCompte.addActionListener(conn);
        this.aPermission.addActionListener(conn);
        this.aconge.addActionListener(conn);
        this.permission.addActionListener(conn);
    } 

    public JMenuItem getCertificat() {
        return Certificat;
    }

    public void setCertificat(JMenuItem Certificat) {
        this.Certificat = Certificat;
    }

    public JMenu getModifierCompte() {
        return ModifierCompte;
    }

    public void setModifierCompte(JMenu ModifierCompte) {
        this.ModifierCompte = ModifierCompte;
    }

    public JMenuItem getAttestation() {
        return attestation;
    }

    public void setAttestation(JMenuItem attestation) {
        this.attestation = attestation;
    }

    public JMenuItem getEnregistrerCourrier() {
        return enregistrerCourrier;
    }

    public void setEnregistrerCourrier(JMenuItem enregistrerCourrier) {
        this.enregistrerCourrier = enregistrerCourrier;
    }

    public JMenuItem getRechercherCourrier() {
        return rechercherCourrier;
    }

    public void setRechercherCourrier(JMenuItem rechercherCourrier) {
        this.rechercherCourrier = rechercherCourrier;
    }

    public JMenuItem getRegistreEntrant() {
        return registreEntrant;
    }

    public void setRegistreEntrant(JMenuItem registreEntrant) {
        this.registreEntrant = registreEntrant;
    }

    public JMenuItem getRegistreInterne() {
        return registreInterne;
    }

    public void setRegistreInterne(JMenuItem registreInterne) {
        this.registreInterne = registreInterne;
    }

    public JMenuItem getRegistreSortant() {
        return registreSortant;
    }

    public void setRegistreSortant(JMenuItem registreSortant) {
        this.registreSortant = registreSortant;
    }
    

    public JMenuItem getaPermission() {
        return aPermission;
    }

    public void setaPermission(JMenuItem aPermission) {
        this.aPermission = aPermission;
    }

    public JMenuItem getAccorderDroit() {
        return accorderDroit;
    }

    public void setAccorderDroit(JMenuItem accorderDroit) {
        this.accorderDroit = accorderDroit;
    }

    public JMenuItem getAconge() {
        return aconge;
    }

    public void setAconge(JMenuItem aconge) {
        this.aconge = aconge;
    }

    public JMenuItem getAjouterPerso() {
        return ajouterPerso;
    }

    public void setAjouterPerso(JMenuItem ajouterPerso) {
        this.ajouterPerso = ajouterPerso;
    }

    public JButton getAnnuler() {
        return annuler;
    }

    public void setAnnuler(JButton annuler) {
        this.annuler = annuler;
    }

    public JMenuItem getConge() {
        return conge;
    }

    public void setConge(JMenuItem conge) {
        this.conge = conge;
    }

    public JComboBox getDecision() {
        return decision;
    }

    public void setDecision(JComboBox decision) {
        this.decision = decision;
    }

    public JMenuItem getDisconnect() {
        return disconnect;
    }

    public void setDisconnect(JMenuItem disconnect) {
        this.disconnect = disconnect;
    }

    public JButton getEditer() {
        return editer;
    }

    public void setEditer(JButton editer) {
        this.editer = editer;
    }

    public JMenuItem getEnregistrerMat() {
        return enregistrerMat;
    }

    public void setEnregistrerMat(JMenuItem enregistrerMat) {
        this.enregistrerMat = enregistrerMat;
    }

    public JMenuItem getFdetenteur() {
        return fdetenteur;
    }

    public void setFdetenteur(JMenuItem fdetenteur) {
        this.fdetenteur = fdetenteur;
    }

    public JMenuItem getHistoConge() {
        return histoConge;
    }

    public void setHistoConge(JMenuItem histoConge) {
        this.histoConge = histoConge;
    }

    public JMenuItem getHistoPermissions() {
        return histoPermissions;
    }

    public void setHistoPermissions(JMenuItem histoPermissions) {
        this.histoPermissions = histoPermissions;
    }

    public JMenuItem getListerMat() {
        return listerMat;
    }

    public void setListerMat(JMenuItem listerMat) {
        this.listerMat = listerMat;
    }

    public JTextField getMatricule() {
        return matricule;
    }

    public void setMatricule(JTextField matricule) {
        this.matricule = matricule;
    }

    public JMenuItem getPermission() {
        return permission;
    }

    public void setPermission(JMenuItem permission) {
        this.permission = permission;
    }

    public JMenuItem getRechercherMat() {
        return rechercherMat;
    }

    public void setRechercherMat(JMenuItem rechercherMat) {
        this.rechercherMat = rechercherMat;
    }

    public JMenuItem getReformerMat() {
        return reformerMat;
    }

    public void setReformerMat(JMenuItem reformerMat) {
        this.reformerMat = reformerMat;
    }

    public JMenuItem getRepartitionMat() {
        return repartitionMat;
    }

    public void setRepartitionMat(JMenuItem repartitionMat) {
        this.repartitionMat = repartitionMat;
    }

    public JTable getTable() {
        return table;
    }

    public void setTable(JTable table) {
        this.table = table;
    }

    public JButton getValider() {
        return valider;
    }

    public void setValider(JButton valider) {
        this.valider = valider;
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        footer1 = new view.Footer();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        matricule = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        decision = new javax.swing.JComboBox();
        valider = new javax.swing.JButton();
        editer = new javax.swing.JButton();
        annuler = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        ajouterPerso = new javax.swing.JMenuItem();
        accorderDroit = new javax.swing.JMenuItem();
        jMenuItem11 = new javax.swing.JMenuItem();
        attestation = new javax.swing.JMenuItem();
        Certificat = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        permission = new javax.swing.JMenuItem();
        conge = new javax.swing.JMenuItem();
        aPermission = new javax.swing.JMenuItem();
        aconge = new javax.swing.JMenuItem();
        histoConge = new javax.swing.JMenuItem();
        histoPermissions = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        enregistrerCourrier = new javax.swing.JMenuItem();
        registreEntrant = new javax.swing.JMenuItem();
        registreSortant = new javax.swing.JMenuItem();
        registreInterne = new javax.swing.JMenuItem();
        rechercherCourrier = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();
        enregistrerMat = new javax.swing.JMenuItem();
        repartitionMat = new javax.swing.JMenuItem();
        rechercherMat = new javax.swing.JMenuItem();
        reformerMat = new javax.swing.JMenuItem();
        listerMat = new javax.swing.JMenuItem();
        fdetenteur = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        ModifierCompte = new javax.swing.JMenu();
        disconnect = new javax.swing.JMenuItem();
        jMenuItem22 = new javax.swing.JMenuItem();
        jMenuItem23 = new javax.swing.JMenuItem();
        jMenuItem24 = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("AGRHM");

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Matricule", "Objet", "Debut", "Fin", "Decision"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(table);

        jLabel1.setText("Matricule");

        jLabel2.setText("Decision");

        decision.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "ACCORDE", "REFUSE" }));

        valider.setText("Valider");

        editer.setText("Editer Note");

        annuler.setText("Annuler");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(footer1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(42, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(matricule, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(valider)
                        .addGap(8, 8, 8)))
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(decision, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(editer)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(annuler))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(decision, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(matricule, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(annuler)
                    .addComponent(editer)
                    .addComponent(valider))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 59, Short.MAX_VALUE)
                .addComponent(footer1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jMenuBar1.setForeground(new java.awt.Color(102, 255, 51));

        jMenu1.setText("Personnel");

        ajouterPerso.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        ajouterPerso.setText("Ajouter un personnel");
        jMenu1.add(ajouterPerso);

        accorderDroit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Properties24.gif"))); // NOI18N
        accorderDroit.setText("Accorder des droits");
        jMenu1.add(accorderDroit);

        jMenuItem11.setText("Liste de presence");
        jMenu1.add(jMenuItem11);

        attestation.setText("Attestation de Presence");
        jMenu1.add(attestation);

        Certificat.setText("Certificate de Reprise de Service");
        jMenu1.add(Certificat);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Permissions et conges");

        permission.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        permission.setText("demander une permission");
        permission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                permissionActionPerformed(evt);
            }
        });
        jMenu2.add(permission);

        conge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        conge.setText("demander un conge");
        jMenu2.add(conge);

        aPermission.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        aPermission.setText("accorde une permission");
        aPermission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aPermissionActionPerformed(evt);
            }
        });
        jMenu2.add(aPermission);

        aconge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        aconge.setText("accorde un conge");
        aconge.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acongeActionPerformed(evt);
            }
        });
        jMenu2.add(aconge);

        histoConge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        histoConge.setText("historique des congés");
        jMenu2.add(histoConge);

        histoPermissions.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        histoPermissions.setText("historique des permissions");
        jMenu2.add(histoPermissions);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("Courrier");

        enregistrerCourrier.setText("enregistrer un courrier");
        jMenu3.add(enregistrerCourrier);

        registreEntrant.setText("registre courrier entrant");
        jMenu3.add(registreEntrant);

        registreSortant.setText("registre courrier sortant");
        jMenu3.add(registreSortant);

        registreInterne.setText("registre courrier interne");
        jMenu3.add(registreInterne);

        rechercherCourrier.setText("rechercher un courrier");
        jMenu3.add(rechercherCourrier);

        jMenuBar1.add(jMenu3);

        jMenu4.setText("Archives");
        jMenuBar1.add(jMenu4);

        jMenu6.setText("Materiel");

        enregistrerMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        enregistrerMat.setText("enregistrer un materiel");
        jMenu6.add(enregistrerMat);

        repartitionMat.setText("repartition du materiel");
        jMenu6.add(repartitionMat);

        rechercherMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Search24.gif"))); // NOI18N
        rechercherMat.setText("rechercher materiel");
        jMenu6.add(rechercherMat);

        reformerMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/TipOfTheDay24.gif"))); // NOI18N
        reformerMat.setText("reformer un materiel");
        jMenu6.add(reformerMat);

        listerMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        listerMat.setText("lister le materiel");
        jMenu6.add(listerMat);

        fdetenteur.setText("Fiche Detenteur");
        jMenu6.add(fdetenteur);

        jMenuBar1.add(jMenu6);

        jMenu7.setText("Planification");
        jMenuBar1.add(jMenu7);

        ModifierCompte.setText("Mon compte");

        disconnect.setText("deconnection");
        ModifierCompte.add(disconnect);

        jMenuItem22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/ComposeMail24.gif"))); // NOI18N
        jMenuItem22.setText("envoyer un mail");
        ModifierCompte.add(jMenuItem22);

        jMenuItem23.setText("boite de reception");
        ModifierCompte.add(jMenuItem23);

        jMenuItem24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/PageSetup24.gif"))); // NOI18N
        jMenuItem24.setText("parametre");
        ModifierCompte.add(jMenuItem24);

        jMenuItem1.setText("Modifier mon Compte");
        ModifierCompte.add(jMenuItem1);

        jMenuBar1.add(ModifierCompte);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void permissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_permissionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_permissionActionPerformed

    private void aPermissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aPermissionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_aPermissionActionPerformed

    private void acongeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acongeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_acongeActionPerformed

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem Certificat;
    private javax.swing.JMenu ModifierCompte;
    private javax.swing.JMenuItem aPermission;
    private javax.swing.JMenuItem accorderDroit;
    private javax.swing.JMenuItem aconge;
    private javax.swing.JMenuItem ajouterPerso;
    private javax.swing.JButton annuler;
    private javax.swing.JMenuItem attestation;
    private javax.swing.JMenuItem conge;
    private javax.swing.JComboBox decision;
    private javax.swing.JMenuItem disconnect;
    private javax.swing.JButton editer;
    private javax.swing.JMenuItem enregistrerCourrier;
    private javax.swing.JMenuItem enregistrerMat;
    private javax.swing.JMenuItem fdetenteur;
    private view.Footer footer1;
    private javax.swing.JMenuItem histoConge;
    private javax.swing.JMenuItem histoPermissions;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem22;
    private javax.swing.JMenuItem jMenuItem23;
    private javax.swing.JMenuItem jMenuItem24;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenuItem listerMat;
    private javax.swing.JTextField matricule;
    private javax.swing.JMenuItem permission;
    private javax.swing.JMenuItem rechercherCourrier;
    private javax.swing.JMenuItem rechercherMat;
    private javax.swing.JMenuItem reformerMat;
    private javax.swing.JMenuItem registreEntrant;
    private javax.swing.JMenuItem registreInterne;
    private javax.swing.JMenuItem registreSortant;
    private javax.swing.JMenuItem repartitionMat;
    private javax.swing.JTable table;
    private javax.swing.JButton valider;
    // End of variables declaration//GEN-END:variables
}
