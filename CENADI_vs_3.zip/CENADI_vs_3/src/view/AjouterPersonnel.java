/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.CtrlAjouterPersonnel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JMenuItem;
import javax.swing.JTextField;
import org.jdesktop.swingx.JXDatePicker;

/**
 *
 * @author Jordan
 */
public class AjouterPersonnel extends javax.swing.JFrame {

    /**
     * Creates new form AjouterPersonnel
     */
    public AjouterPersonnel() {
        initComponents();
        this.setLocationRelativeTo(this);
        CtrlAjouterPersonnel ctrl=new CtrlAjouterPersonnel(this);
        this.setTitle("AGRHM");
        this.valider.addActionListener(ctrl);
        this.ajouterPerso.addActionListener(ctrl);
        this.conge.addActionListener(ctrl);
        this.enregistrerMat.addActionListener(ctrl);
        this.rechercherMat.addActionListener(ctrl);
        this.repartitionMat.addActionListener(ctrl);
        this.fdetenteur.addActionListener(ctrl);
        this.disconnect.addActionListener(ctrl);
        this.RechercheCourrier.addActionListener(ctrl);
        this.enregistrerCourrier.addActionListener(ctrl);
        this.registreEntrant.addActionListener(ctrl);
        this.registreInterne.addActionListener(ctrl);
        this.registreSortant.addActionListener(ctrl);
        this.histoConge.addActionListener(ctrl);
        this.histoPermission.addActionListener(ctrl);
        this.attestation.addActionListener(ctrl);
        this.certificat.addActionListener(ctrl);
        this.ModifierCompte.addActionListener(ctrl);
        this.aPermission.addActionListener(ctrl);
        this.aConge.addActionListener(ctrl);
        this.permission.addActionListener(ctrl);
        

    } 

    public JMenuItem getCertificat() {
        return certificat;
    }

    public void setCertificat(JMenuItem certificat) {
        this.certificat = certificat;
    }

    public JMenuItem getRechercheCourrier() {
        return RechercheCourrier;
    }

    public void setRechercheCourrier(JMenuItem RechercheCourrier) {
        this.RechercheCourrier = RechercheCourrier;
    }

    public JMenuItem getModifierCompte() {
        return ModifierCompte;
    }

    public void setModifierCompte(JMenuItem ModifierCompte) {
        this.ModifierCompte = ModifierCompte;
    }

    public JMenuItem getAttestation() {
        return attestation;
    }

    public void setAttestation(JMenuItem attestation) {
        this.attestation = attestation;
    }

    public JMenuItem getRegistreEntrant() {
        return registreEntrant;
    }

    public void setRegistreEntrant(JMenuItem registreEntrant) {
        this.registreEntrant = registreEntrant;
    }

    public JMenuItem getRegistreInterne() {
        return registreInterne;
    }

    public void setRegistreInterne(JMenuItem registreInterne) {
        this.registreInterne = registreInterne;
    }

    public JMenuItem getRegistreSortant() {
        return registreSortant;
    }

    public void setRegistreSortant(JMenuItem registreSortant) {
        this.registreSortant = registreSortant;
    }

    public JMenuItem getDisconnect() {
        return disconnect;
    }

    public void setDisconnect(JMenuItem disconnect) {
        this.disconnect = disconnect;
    }

    public JMenuItem getEnregistrerCourrier() {
        return enregistrerCourrier;
    }

    public void setEnregistrerCourrier(JMenuItem enregistrerCourrier) {
        this.enregistrerCourrier = enregistrerCourrier;
    }

    public JMenuItem getEnregistrerMat() {
        return enregistrerMat;
    }

    public void setEnregistrerMat(JMenuItem enregistrerMat) {
        this.enregistrerMat = enregistrerMat;
    }

    public JMenuItem getFdetenteur() {
        return fdetenteur;
    }

    public void setFdetenteur(JMenuItem fdetenteur) {
        this.fdetenteur = fdetenteur;
    }

    public JMenuItem getRechercherMat() {
        return rechercherMat;
    }

    public void setRechercherMat(JMenuItem rechercherMat) {
        this.rechercherMat = rechercherMat;
    }

    public JMenuItem getReformerMat() {
        return reformerMat;
    }

    public void setReformerMat(JMenuItem reformerMat) {
        this.reformerMat = reformerMat;
    }

    public JMenuItem getRepartitionMat() {
        return repartitionMat;
    }

    public void setRepartitionMat(JMenuItem repartitionMat) {
        this.repartitionMat = repartitionMat;
    }
    

    public JMenuItem getaConge() {
        return aConge;
    }

    public void setaConge(JMenuItem aConge) {
        this.aConge = aConge;
    }

    public JMenuItem getaPermission() {
        return aPermission;
    }

    public void setaPermission(JMenuItem aPermission) {
        this.aPermission = aPermission;
    }

    public JMenuItem getAccorderDroit() {
        return accorderDroit;
    }

    public void setAccorderDroit(JMenuItem accorderDroit) {
        this.accorderDroit = accorderDroit;
    }

    public JTextField getAdresse() {
        return adresse;
    }

    public void setAdresse(JTextField adresse) {
        this.adresse = adresse;
    }

    public JMenuItem getAjouterPerso() {
        return ajouterPerso;
    }

    public void setAjouterPerso(JMenuItem ajouterPerso) {
        this.ajouterPerso = ajouterPerso;
    }

    public JMenuItem getConge() {
        return conge;
    }

    public void setConge(JMenuItem conge) {
        this.conge = conge;
    }

    public JXDatePicker getDate() {
        return date;
    }

    public void setDate(JXDatePicker date) {
        this.date = date;
    }

    public JMenuItem getHistoConge() {
        return histoConge;
    }

    public void setHistoConge(JMenuItem histoConge) {
        this.histoConge = histoConge;
    }

    public JMenuItem getHistoPermission() {
        return histoPermission;
    }

    public void setHistoPermission(JMenuItem histoPermission) {
        this.histoPermission = histoPermission;
    }

    public JTextField getMatricule() {
        return matricule;
    }

    public void setMatricule(JTextField matricule) {
        this.matricule = matricule;
    }

    public JTextField getNom() {
        return nom;
    }

    public void setNom(JTextField nom) {
        this.nom = nom;
    }

    public JMenuItem getPermission() {
        return permission;
    }

    public void setPermission(JMenuItem permission) {
        this.permission = permission;
    }

    public JTextField getPrenom() {
        return prenom;
    }

    public void setPrenom(JTextField prenom) {
        this.prenom = prenom;
    }

    public JComboBox getStatut() {
        return statut;
    }

    public void setStatut(JComboBox statut) {
        this.statut = statut;
    }

    public JTextField getTelephone() {
        return telephone;
    }

    public void setTelephone(JTextField telephone) {
        this.telephone = telephone;
    }

    public JButton getAnnuler() {
        return annuler;
    }

    public void setAnnuler(JButton annuler) {
        this.annuler = annuler;
    }

    public JButton getValider() {
        return valider;
    }

    public void setValider(JButton valider) {
        this.valider = valider;
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        footer1 = new view.Footer();
        jLabel1 = new javax.swing.JLabel();
        matricule = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        nom = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        prenom = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        statut = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        date = new org.jdesktop.swingx.JXDatePicker();
        jLabel6 = new javax.swing.JLabel();
        adresse = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        telephone = new javax.swing.JTextField();
        annuler = new javax.swing.JButton();
        valider = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        grade = new javax.swing.JComboBox();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        ajouterPerso = new javax.swing.JMenuItem();
        accorderDroit = new javax.swing.JMenuItem();
        jMenuItem11 = new javax.swing.JMenuItem();
        attestation = new javax.swing.JMenuItem();
        certificat = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        permission = new javax.swing.JMenuItem();
        conge = new javax.swing.JMenuItem();
        aPermission = new javax.swing.JMenuItem();
        aConge = new javax.swing.JMenuItem();
        histoConge = new javax.swing.JMenuItem();
        histoPermission = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        enregistrerCourrier = new javax.swing.JMenuItem();
        registreEntrant = new javax.swing.JMenuItem();
        registreSortant = new javax.swing.JMenuItem();
        registreInterne = new javax.swing.JMenuItem();
        RechercheCourrier = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();
        enregistrerMat = new javax.swing.JMenuItem();
        repartitionMat = new javax.swing.JMenuItem();
        rechercherMat = new javax.swing.JMenuItem();
        jMenuItem19 = new javax.swing.JMenuItem();
        reformerMat = new javax.swing.JMenuItem();
        fdetenteur = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        jMenu8 = new javax.swing.JMenu();
        disconnect = new javax.swing.JMenuItem();
        jMenuItem24 = new javax.swing.JMenuItem();
        ModifierCompte = new javax.swing.JMenuItem();

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel1.setText("Matricule");

        matricule.setText(" ");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setText("Nom");

        nom.setText(" ");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setText("Prenom");

        prenom.setText(" ");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setText("Statut");

        statut.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "cadre", "Chef de Bureau administratif et financier", "Chef de centre", "Chef de centre adjoint", "ingenieur de projet", "responsable salle serveur/faconnage", "secretaire", " " }));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setText("naissance");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel6.setText("adresse");

        adresse.setText(" ");

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel7.setText("Telephone");

        telephone.setText(" ");
        telephone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                telephoneActionPerformed(evt);
            }
        });

        annuler.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Delete24.gif"))); // NOI18N
        annuler.setText("Annuler");

        valider.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        valider.setText("Valider");

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel8.setText("Grade");

        grade.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "INGENIEUR INFORMATICIEN", "ANALYSTE", "CADRE D'ADMINISTRATION", "INGENIEUR DE TRAVAUX", "DEVELOPPEUR" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(footer1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(valider)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(annuler))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6))
                                .addGap(18, 18, 18))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(14, 14, 14)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(telephone)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel8)
                                .addGap(18, 18, 18)
                                .addComponent(grade, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(matricule)
                            .addComponent(nom)
                            .addComponent(prenom)
                            .addComponent(statut, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(adresse))))
                .addContainerGap(63, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(matricule, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(nom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(prenom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(statut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addComponent(grade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(adresse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(telephone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(annuler)
                    .addComponent(valider))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addComponent(footer1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jMenuBar1.setForeground(new java.awt.Color(102, 255, 51));

        jMenu1.setText("Personnel");

        ajouterPerso.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        ajouterPerso.setText("Ajouter un personnel");
        jMenu1.add(ajouterPerso);

        accorderDroit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Properties24.gif"))); // NOI18N
        accorderDroit.setText("Accorder des droits");
        jMenu1.add(accorderDroit);

        jMenuItem11.setText("Liste de presence");
        jMenu1.add(jMenuItem11);

        attestation.setText("Attestation de Presence");
        jMenu1.add(attestation);

        certificat.setText("Certificate de Reprise de Service");
        jMenu1.add(certificat);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Permissions et conges");

        permission.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        permission.setText("demander une permission");
        permission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                permissionActionPerformed(evt);
            }
        });
        jMenu2.add(permission);

        conge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        conge.setText("demander un conge");
        jMenu2.add(conge);

        aPermission.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        aPermission.setText("accorde une permission");
        aPermission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aPermissionActionPerformed(evt);
            }
        });
        jMenu2.add(aPermission);

        aConge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        aConge.setText("accorde un conge");
        aConge.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aCongeActionPerformed(evt);
            }
        });
        jMenu2.add(aConge);

        histoConge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        histoConge.setText("historique des congés");
        jMenu2.add(histoConge);

        histoPermission.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        histoPermission.setText("historique des permissions");
        jMenu2.add(histoPermission);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("Courrier");

        enregistrerCourrier.setText("enregistrer un courrier");
        jMenu3.add(enregistrerCourrier);

        registreEntrant.setText("registre courrier entrant");
        jMenu3.add(registreEntrant);

        registreSortant.setText("registre courrier sortant");
        jMenu3.add(registreSortant);

        registreInterne.setText("registre courrier interne");
        jMenu3.add(registreInterne);

        RechercheCourrier.setText("Rechercher un Courrier");
        jMenu3.add(RechercheCourrier);

        jMenuBar1.add(jMenu3);

        jMenu4.setText("Archives");
        jMenuBar1.add(jMenu4);

        jMenu6.setText("Materiel");

        enregistrerMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        enregistrerMat.setText("enregistrer un materiel");
        jMenu6.add(enregistrerMat);

        repartitionMat.setText("repartition du materiel");
        jMenu6.add(repartitionMat);

        rechercherMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Search24.gif"))); // NOI18N
        rechercherMat.setText("rechercher materiel");
        jMenu6.add(rechercherMat);

        jMenuItem19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/TipOfTheDay24.gif"))); // NOI18N
        jMenuItem19.setText("reformer un materiel");
        jMenu6.add(jMenuItem19);

        reformerMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        reformerMat.setText("lister le materiel");
        jMenu6.add(reformerMat);

        fdetenteur.setText("Fiche detenteur");
        jMenu6.add(fdetenteur);

        jMenuBar1.add(jMenu6);

        jMenu7.setText("Planification");
        jMenuBar1.add(jMenu7);

        jMenu8.setText("Mon compte");

        disconnect.setText("deconnection");
        jMenu8.add(disconnect);

        jMenuItem24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/PageSetup24.gif"))); // NOI18N
        jMenuItem24.setText("parametre");
        jMenu8.add(jMenuItem24);

        ModifierCompte.setText("Modifier mon Compte");
        jMenu8.add(ModifierCompte);

        jMenuBar1.add(jMenu8);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void permissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_permissionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_permissionActionPerformed

    private void aPermissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aPermissionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_aPermissionActionPerformed

    private void aCongeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aCongeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_aCongeActionPerformed

    private void telephoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_telephoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_telephoneActionPerformed

    /**
     * @param args the command line arguments
     */
     

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem ModifierCompte;
    private javax.swing.JMenuItem RechercheCourrier;
    private javax.swing.JMenuItem aConge;
    private javax.swing.JMenuItem aPermission;
    private javax.swing.JMenuItem accorderDroit;
    private javax.swing.JTextField adresse;
    private javax.swing.JMenuItem ajouterPerso;
    private javax.swing.JButton annuler;
    private javax.swing.JMenuItem attestation;
    private javax.swing.JMenuItem certificat;
    private javax.swing.JMenuItem conge;
    private org.jdesktop.swingx.JXDatePicker date;
    private javax.swing.JMenuItem disconnect;
    private javax.swing.JMenuItem enregistrerCourrier;
    private javax.swing.JMenuItem enregistrerMat;
    private javax.swing.JMenuItem fdetenteur;
    private view.Footer footer1;
    private javax.swing.JComboBox grade;
    private javax.swing.JMenuItem histoConge;
    private javax.swing.JMenuItem histoPermission;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem19;
    private javax.swing.JMenuItem jMenuItem24;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField matricule;
    private javax.swing.JTextField nom;
    private javax.swing.JMenuItem permission;
    private javax.swing.JTextField prenom;
    private javax.swing.JMenuItem rechercherMat;
    private javax.swing.JMenuItem reformerMat;
    private javax.swing.JMenuItem registreEntrant;
    private javax.swing.JMenuItem registreInterne;
    private javax.swing.JMenuItem registreSortant;
    private javax.swing.JMenuItem repartitionMat;
    private javax.swing.JComboBox statut;
    private javax.swing.JTextField telephone;
    private javax.swing.JButton valider;
    // End of variables declaration//GEN-END:variables

}
