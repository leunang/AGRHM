/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.CtrlAttestation;
import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.JTextField;
import org.jdesktop.swingx.JXDatePicker;

/**
 *
 * @author Jordan
 */
public class AttestationPresencePoste extends javax.swing.JFrame {

    /**
     * Creates new form AttestationPresencePoste
     */
    public AttestationPresencePoste() {
        initComponents();
        this.setLocationRelativeTo(this);
        CtrlAttestation conn=new CtrlAttestation(this);
        this.valider.addActionListener(conn);
        this.ajouterPerso.addActionListener(conn);
        this.demanderConge.addActionListener(conn);
        this.enregistrerMateriel.addActionListener(conn);
        this.rechercherMateriel.addActionListener(conn);
        this.repartirMateriel.addActionListener(conn);
        this.ficheDetenteur.addActionListener(conn);
        this.disconnect.addActionListener(conn);
        this.rechercherCourrier.addActionListener(conn);
        this.enregistrercourrier.addActionListener(conn);
        this.registreEntrant.addActionListener(conn);
        this.registreInterne.addActionListener(conn);
        this.registreSortant.addActionListener(conn);
        this.histoConge.addActionListener(conn);
        this.histoPermission.addActionListener(conn);
        this.Attestation.addActionListener(conn);
        this.Certificat.addActionListener(conn);
        this.modifierCompte.addActionListener(conn);
        this.accorderPermission.addActionListener(conn);
        this.accordeConge.addActionListener(conn);
        this.demanderPermission.addActionListener(conn);
    }

    public JMenuItem getAccordeConge() {
        return accordeConge;
    }

    public void setAccordeConge(JMenuItem accordeConge) {
        this.accordeConge = accordeConge;
    }

    public JMenuItem getAccorderDroit() {
        return accorderDroit;
    }

    public void setAccorderDroit(JMenuItem accorderDroit) {
        this.accorderDroit = accorderDroit;
    }

    public JMenuItem getAccorderPermission() {
        return accorderPermission;
    }

    public void setAccorderPermission(JMenuItem accorderPermission) {
        this.accorderPermission = accorderPermission;
    }

    public JMenuItem getAddArchive() {
        return addArchive;
    }

    public void setAddArchive(JMenuItem addArchive) {
        this.addArchive = addArchive;
    }

    public JMenuItem getAttestation() {
        return Attestation;
    }

    public void setAttestation(JMenuItem Attestation) {
        this.Attestation = Attestation;
    }

    public JMenuItem getCertificat() {
        return Certificat;
    }

    public void setCertificat(JMenuItem Certificat) {
        this.Certificat = Certificat;
    }

    public JMenuItem getModifierCompte() {
        return modifierCompte;
    }

    public void setModifierCompte(JMenuItem modifierCompte) {
        this.modifierCompte = modifierCompte;
    }

    public JMenuItem getAjouterPerso() {
        return ajouterPerso;
    }

    public void setAjouterPerso(JMenuItem ajouterPerso) {
        this.ajouterPerso = ajouterPerso;
    }

    public JButton getAnnuler() {
        return annuler;
    }

    public void setAnnuler(JButton annuler) {
        this.annuler = annuler;
    }

    public JTextField getArrete() {
        return arrete;
    }

    public void setArrete(JTextField arrete) {
        this.arrete = arrete;
    }

    public JXDatePicker getDate() {
        return date;
    }

    public void setDate(JXDatePicker date) {
        this.date = date;
    }

    public JMenuItem getDemanderConge() {
        return demanderConge;
    }

    public void setDemanderConge(JMenuItem demanderConge) {
        this.demanderConge = demanderConge;
    }

    public JMenuItem getDemanderPermission() {
        return demanderPermission;
    }

    public void setDemanderPermission(JMenuItem demanderPermission) {
        this.demanderPermission = demanderPermission;
    }

    public JMenuItem getDisconnect() {
        return disconnect;
    }

    public void setDisconnect(JMenuItem disconnect) {
        this.disconnect = disconnect;
    }

    public JMenuItem getEnregistrerMateriel() {
        return enregistrerMateriel;
    }

    public void setEnregistrerMateriel(JMenuItem enregistrerMateriel) {
        this.enregistrerMateriel = enregistrerMateriel;
    }

    public JMenuItem getEnregistrercourrier() {
        return enregistrercourrier;
    }

    public void setEnregistrercourrier(JMenuItem enregistrercourrier) {
        this.enregistrercourrier = enregistrercourrier;
    }

    public JMenuItem getFicheDetenteur() {
        return ficheDetenteur;
    }

    public void setFicheDetenteur(JMenuItem ficheDetenteur) {
        this.ficheDetenteur = ficheDetenteur;
    }

    public JMenuItem getHistoConge() {
        return histoConge;
    }

    public void setHistoConge(JMenuItem histoConge) {
        this.histoConge = histoConge;
    }

    public JMenuItem getHistoPermission() {
        return histoPermission;
    }

    public void setHistoPermission(JMenuItem histoPermission) {
        this.histoPermission = histoPermission;
    }

    public JMenuItem getListePresence() {
        return listePresence;
    }

    public void setListePresence(JMenuItem listePresence) {
        this.listePresence = listePresence;
    }

    public JMenuItem getListerMateriel() {
        return listerMateriel;
    }

    public void setListerMateriel(JMenuItem listerMateriel) {
        this.listerMateriel = listerMateriel;
    }

    public JTextField getMatricule() {
        return matricule;
    }

    public void setMatricule(JTextField matricule) {
        this.matricule = matricule;
    }

    public JMenuItem getParametre() {
        return parametre;
    }

    public void setParametre(JMenuItem parametre) {
        this.parametre = parametre;
    }

    public JMenuItem getRechercherArchive() {
        return rechercherArchive;
    }

    public void setRechercherArchive(JMenuItem rechercherArchive) {
        this.rechercherArchive = rechercherArchive;
    }

    public JMenuItem getRechercherCourrier() {
        return rechercherCourrier;
    }

    public void setRechercherCourrier(JMenuItem rechercherCourrier) {
        this.rechercherCourrier = rechercherCourrier;
    }

    public JMenuItem getRechercherMateriel() {
        return rechercherMateriel;
    }

    public void setRechercherMateriel(JMenuItem rechercherMateriel) {
        this.rechercherMateriel = rechercherMateriel;
    }

    public JMenuItem getReformerMateriel() {
        return reformerMateriel;
    }

    public void setReformerMateriel(JMenuItem reformerMateriel) {
        this.reformerMateriel = reformerMateriel;
    }

    public JMenuItem getRegistreEntrant() {
        return registreEntrant;
    }

    public void setRegistreEntrant(JMenuItem registreEntrant) {
        this.registreEntrant = registreEntrant;
    }

    public JMenuItem getRegistreInterne() {
        return registreInterne;
    }

    public void setRegistreInterne(JMenuItem registreInterne) {
        this.registreInterne = registreInterne;
    }

    public JMenuItem getRegistreSortant() {
        return registreSortant;
    }

    public void setRegistreSortant(JMenuItem registreSortant) {
        this.registreSortant = registreSortant;
    }

    public JMenuItem getRepartirMateriel() {
        return repartirMateriel;
    }

    public void setRepartirMateriel(JMenuItem repartirMateriel) {
        this.repartirMateriel = repartirMateriel;
    }

    public JButton getValider() {
        return valider;
    }

    public void setValider(JButton valider) {
        this.valider = valider;
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        footer1 = new view.Footer();
        jLabel1 = new javax.swing.JLabel();
        matricule = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        arrete = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        date = new org.jdesktop.swingx.JXDatePicker();
        valider = new javax.swing.JButton();
        annuler = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        ajouterPerso = new javax.swing.JMenuItem();
        accorderDroit = new javax.swing.JMenuItem();
        listePresence = new javax.swing.JMenuItem();
        Attestation = new javax.swing.JMenuItem();
        Certificat = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        demanderPermission = new javax.swing.JMenuItem();
        demanderConge = new javax.swing.JMenuItem();
        accorderPermission = new javax.swing.JMenuItem();
        accordeConge = new javax.swing.JMenuItem();
        histoConge = new javax.swing.JMenuItem();
        histoPermission = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        enregistrercourrier = new javax.swing.JMenuItem();
        registreEntrant = new javax.swing.JMenuItem();
        registreSortant = new javax.swing.JMenuItem();
        registreInterne = new javax.swing.JMenuItem();
        rechercherCourrier = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        addArchive = new javax.swing.JMenuItem();
        rechercherArchive = new javax.swing.JMenuItem();
        jMenu6 = new javax.swing.JMenu();
        enregistrerMateriel = new javax.swing.JMenuItem();
        repartirMateriel = new javax.swing.JMenuItem();
        rechercherMateriel = new javax.swing.JMenuItem();
        reformerMateriel = new javax.swing.JMenuItem();
        listerMateriel = new javax.swing.JMenuItem();
        ficheDetenteur = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        jMenu8 = new javax.swing.JMenu();
        disconnect = new javax.swing.JMenuItem();
        parametre = new javax.swing.JMenuItem();
        modifierCompte = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));

        jLabel1.setText("Matricule");

        matricule.setText(" ");

        jLabel2.setText("Arrete");

        arrete.setText(" ");

        jLabel3.setText("Date");

        valider.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Save24.gif"))); // NOI18N
        valider.setText("Valider");

        annuler.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Delete24.gif"))); // NOI18N
        annuler.setText("Annuler");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 28, Short.MAX_VALUE)
                .addComponent(footer1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(valider)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 99, Short.MAX_VALUE)
                            .addComponent(annuler))
                        .addComponent(matricule, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(arrete, javax.swing.GroupLayout.Alignment.LEADING)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(matricule, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(arrete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(valider)
                    .addComponent(annuler))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
                .addComponent(footer1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jMenuBar1.setForeground(new java.awt.Color(102, 255, 51));

        jMenu1.setText("Personnel");

        ajouterPerso.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        ajouterPerso.setText("Ajouter un personnel");
        jMenu1.add(ajouterPerso);

        accorderDroit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Properties24.gif"))); // NOI18N
        accorderDroit.setText("Accorder des droits");
        jMenu1.add(accorderDroit);

        listePresence.setText("Liste de presence");
        jMenu1.add(listePresence);

        Attestation.setText("Attestation de presence effective");
        jMenu1.add(Attestation);

        Certificat.setText("Certificate deReprise de service");
        jMenu1.add(Certificat);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Permissions et conges");

        demanderPermission.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        demanderPermission.setText("demander une permission");
        demanderPermission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                demanderPermissionActionPerformed(evt);
            }
        });
        jMenu2.add(demanderPermission);

        demanderConge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        demanderConge.setText("demander un conge");
        jMenu2.add(demanderConge);

        accorderPermission.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        accorderPermission.setText("accorde une permission");
        accorderPermission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                accorderPermissionActionPerformed(evt);
            }
        });
        jMenu2.add(accorderPermission);

        accordeConge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        accordeConge.setText("accorde un conge");
        accordeConge.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                accordeCongeActionPerformed(evt);
            }
        });
        jMenu2.add(accordeConge);

        histoConge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        histoConge.setText("historique des congés");
        jMenu2.add(histoConge);

        histoPermission.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        histoPermission.setText("historique des permissions");
        jMenu2.add(histoPermission);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("Courrier");

        enregistrercourrier.setText("enregistrer un courrier");
        jMenu3.add(enregistrercourrier);

        registreEntrant.setText("registre courrier entrant");
        jMenu3.add(registreEntrant);

        registreSortant.setText("registre courrier sortant");
        jMenu3.add(registreSortant);

        registreInterne.setText("registre courrier interne");
        jMenu3.add(registreInterne);

        rechercherCourrier.setText("rechercher un courrier");
        jMenu3.add(rechercherCourrier);

        jMenuBar1.add(jMenu3);

        jMenu4.setText("Archives");

        addArchive.setText("ajouter archive");
        jMenu4.add(addArchive);

        rechercherArchive.setText("rechercher archive");
        jMenu4.add(rechercherArchive);

        jMenuBar1.add(jMenu4);

        jMenu6.setText("Materiel");

        enregistrerMateriel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        enregistrerMateriel.setText("enregistrer un materiel");
        jMenu6.add(enregistrerMateriel);

        repartirMateriel.setText("repartition du materiel");
        jMenu6.add(repartirMateriel);

        rechercherMateriel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Search24.gif"))); // NOI18N
        rechercherMateriel.setText("rechercher materiel");
        jMenu6.add(rechercherMateriel);

        reformerMateriel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/TipOfTheDay24.gif"))); // NOI18N
        reformerMateriel.setText("reformer un materiel");
        jMenu6.add(reformerMateriel);

        listerMateriel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        listerMateriel.setText("lister le materiel");
        jMenu6.add(listerMateriel);

        ficheDetenteur.setText("creer fiche detenteur");
        jMenu6.add(ficheDetenteur);

        jMenuBar1.add(jMenu6);

        jMenu7.setText("Planification");
        jMenuBar1.add(jMenu7);

        jMenu8.setText("Mon compte");

        disconnect.setText("deconnection");
        jMenu8.add(disconnect);

        parametre.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/PageSetup24.gif"))); // NOI18N
        parametre.setText("parametre");
        jMenu8.add(parametre);

        modifierCompte.setText("Modifier mon Compte");
        jMenu8.add(modifierCompte);

        jMenuBar1.add(jMenu8);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void demanderPermissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_demanderPermissionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_demanderPermissionActionPerformed

    private void accorderPermissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_accorderPermissionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_accorderPermissionActionPerformed

    private void accordeCongeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_accordeCongeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_accordeCongeActionPerformed

    /**
     * @param args the command line arguments
     */
     

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem Attestation;
    private javax.swing.JMenuItem Certificat;
    private javax.swing.JMenuItem accordeConge;
    private javax.swing.JMenuItem accorderDroit;
    private javax.swing.JMenuItem accorderPermission;
    private javax.swing.JMenuItem addArchive;
    private javax.swing.JMenuItem ajouterPerso;
    private javax.swing.JButton annuler;
    private javax.swing.JTextField arrete;
    private org.jdesktop.swingx.JXDatePicker date;
    private javax.swing.JMenuItem demanderConge;
    private javax.swing.JMenuItem demanderPermission;
    private javax.swing.JMenuItem disconnect;
    private javax.swing.JMenuItem enregistrerMateriel;
    private javax.swing.JMenuItem enregistrercourrier;
    private javax.swing.JMenuItem ficheDetenteur;
    private view.Footer footer1;
    private javax.swing.JMenuItem histoConge;
    private javax.swing.JMenuItem histoPermission;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JMenuItem listePresence;
    private javax.swing.JMenuItem listerMateriel;
    private javax.swing.JTextField matricule;
    private javax.swing.JMenuItem modifierCompte;
    private javax.swing.JMenuItem parametre;
    private javax.swing.JMenuItem rechercherArchive;
    private javax.swing.JMenuItem rechercherCourrier;
    private javax.swing.JMenuItem rechercherMateriel;
    private javax.swing.JMenuItem reformerMateriel;
    private javax.swing.JMenuItem registreEntrant;
    private javax.swing.JMenuItem registreInterne;
    private javax.swing.JMenuItem registreSortant;
    private javax.swing.JMenuItem repartirMateriel;
    private javax.swing.JButton valider;
    // End of variables declaration//GEN-END:variables
}
