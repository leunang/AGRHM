/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.CtrlRegistreCourrierEntrant;
import controller.CtrlRegistreCourrierSortant;
import javax.swing.JMenuItem;
import javax.swing.JTable;

/**
 *
 * @author EMME
 */
public class Registre_Courrier_sortant extends javax.swing.JFrame {

    public JMenuItem getAccordConge() {
        return AccordConge;
    }

    public void setAccordConge(JMenuItem AccordConge) {
        this.AccordConge = AccordConge;
    }

    public JMenuItem getAccordDroits() {
        return AccordDroits;
    }

    public void setAccordDroits(JMenuItem AccordDroits) {
        this.AccordDroits = AccordDroits;
    }

    public JMenuItem getAccordPermission() {
        return AccordPermission;
    }

    public void setAccordPermission(JMenuItem AccordPermission) {
        this.AccordPermission = AccordPermission;
    }

    public JMenuItem getAjouterPerso() {
        return AjouterPerso;
    }

    public void setAjouterPerso(JMenuItem AjouterPerso) {
        this.AjouterPerso = AjouterPerso;
    }

    public JMenuItem getAttestation() {
        return Attestation;
    }

    public void setAttestation(JMenuItem Attestation) {
        this.Attestation = Attestation;
    }

    public JMenuItem getCertificat() {
        return Certificat;
    }

    public void setCertificat(JMenuItem Certificat) {
        this.Certificat = Certificat;
    }

    public JMenuItem getDemandeConge() {
        return DemandeConge;
    }

    public void setDemandeConge(JMenuItem DemandeConge) {
        this.DemandeConge = DemandeConge;
    }

    public JMenuItem getDemandePermission() {
        return DemandePermission;
    }

    public void setDemandePermission(JMenuItem DemandePermission) {
        this.DemandePermission = DemandePermission;
    }

    public JMenuItem getEnregistreMat() {
        return EnregistreMat;
    }

    public void setEnregistreMat(JMenuItem EnregistreMat) {
        this.EnregistreMat = EnregistreMat;
    }

    public JMenuItem getFicheDetenteur() {
        return FicheDetenteur;
    }

    public void setFicheDetenteur(JMenuItem FicheDetenteur) {
        this.FicheDetenteur = FicheDetenteur;
    }

    public JMenuItem getHistoConge() {
        return HistoConge;
    }

    public void setHistoConge(JMenuItem HistoConge) {
        this.HistoConge = HistoConge;
    }

    public JMenuItem getHistoPermission() {
        return HistoPermission;
    }

    public void setHistoPermission(JMenuItem HistoPermission) {
        this.HistoPermission = HistoPermission;
    }

    public JMenuItem getModifieCompte() {
        return ModifieCompte;
    }

    public void setModifieCompte(JMenuItem ModifieCompte) {
        this.ModifieCompte = ModifieCompte;
    }

    public JMenuItem getRechercheMat() {
        return RechercheMat;
    }

    public void setRechercheMat(JMenuItem RechercheMat) {
        this.RechercheMat = RechercheMat;
    }

    public JMenuItem getRepartitionMat() {
        return RepartitionMat;
    }

    public void setRepartitionMat(JMenuItem RepartitionMat) {
        this.RepartitionMat = RepartitionMat;
    }

    public JMenuItem getDeconnect() {
        return deconnect;
    }

    public void setDeconnect(JMenuItem deconnect) {
        this.deconnect = deconnect;
    }

    public JMenuItem getPara() {
        return para;
    }

    public void setPara(JMenuItem para) {
        this.para = para;
    }
     public JMenuItem getEnregistreCourrier() {
        return EnregistreCourrier;
    }

    public void setEnregistreCourrier(JMenuItem EnregistreCourrier) {
        this.EnregistreCourrier = EnregistreCourrier;
    }

    public JMenuItem getRechercherCourrier() {
        return RechercherCourrier;
    }

    public void setRechercherCourrier(JMenuItem RechercherCourrier) {
        this.RechercherCourrier = RechercherCourrier;
    }

    public JMenuItem getRegistreCourrierEntrant() {
        return RegistreCourrierEntrant;
    }

    public void setRegistreCourrierEntrant(JMenuItem RegistreCourrierEntrant) {
        this.RegistreCourrierEntrant = RegistreCourrierEntrant;
    }

    public JMenuItem getRegistreCourrierInterne() {
        return RegistreCourrierInterne;
    }

    public void setRegistreCourrierInterne(JMenuItem RegistreCourrierInterne) {
        this.RegistreCourrierInterne = RegistreCourrierInterne;
    }

    public JMenuItem getRegistreCourrierSortant() {
        return RegistreCourrierSortant;
    }

    public void setRegistreCourrierSortant(JMenuItem RegistreCourrierSortant) {
        this.RegistreCourrierSortant = RegistreCourrierSortant;
    }

    public JTable getTable() {
        return table;
    }

    /**
     * Creates new form Registre_Courrier_sortant
     */
    public void setTable(JTable table) {
        this.table = table;
    }

    public Registre_Courrier_sortant() {
        initComponents();
        this.setLocationRelativeTo(this);
        CtrlRegistreCourrierSortant conn= new CtrlRegistreCourrierSortant(this);
        this.AjouterPerso.addActionListener(conn);
        this.DemandeConge.addActionListener(conn);
        this.EnregistreMat.addActionListener(conn);
        this.RechercheMat.addActionListener(conn);
        this.RepartitionMat.addActionListener(conn);
        this.FicheDetenteur.addActionListener(conn);
        this.deconnect.addActionListener(conn);
        this.RechercherCourrier.addActionListener(conn);
        this.EnregistreCourrier.addActionListener(conn);
        this.RegistreCourrierEntrant.addActionListener(conn);
        this.RegistreCourrierInterne.addActionListener(conn);
        this.RegistreCourrierSortant.addActionListener(conn);
        this.HistoConge.addActionListener(conn);
        this.HistoPermission.addActionListener(conn);
        this.Attestation.addActionListener(conn);
        this.Certificat.addActionListener(conn);
        this.ModifieCompte.addActionListener(conn);
        this.AccordPermission.addActionListener(conn);
        this.AccordConge.addActionListener(conn);
        this.DemandePermission.addActionListener(conn);  
  
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        AjouterPerso = new javax.swing.JMenuItem();
        AccordDroits = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        Attestation = new javax.swing.JMenuItem();
        Certificat = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        DemandeConge = new javax.swing.JMenuItem();
        DemandePermission = new javax.swing.JMenuItem();
        AccordPermission = new javax.swing.JMenuItem();
        AccordConge = new javax.swing.JMenuItem();
        HistoConge = new javax.swing.JMenuItem();
        HistoPermission = new javax.swing.JMenuItem();
        courrier = new javax.swing.JMenu();
        EnregistreCourrier = new javax.swing.JMenuItem();
        RegistreCourrierEntrant = new javax.swing.JMenuItem();
        RegistreCourrierSortant = new javax.swing.JMenuItem();
        RegistreCourrierInterne = new javax.swing.JMenuItem();
        RechercherCourrier = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();
        EnregistreMat = new javax.swing.JMenuItem();
        RepartitionMat = new javax.swing.JMenuItem();
        RechercheMat = new javax.swing.JMenuItem();
        FicheDetenteur = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        jMenu8 = new javax.swing.JMenu();
        deconnect = new javax.swing.JMenuItem();
        ModifieCompte = new javax.swing.JMenuItem();
        para = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(102, 255, 102));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "NumOrdre", "Type", "Objet", "Recepeteur", "Reference", "Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(table);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 786, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 65, Short.MAX_VALUE))
        );

        jMenuBar1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        jMenu1.setText("Personnel");
        jMenu1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        AjouterPerso.setText("Ajouter un personnel");
        jMenu1.add(AjouterPerso);

        AccordDroits.setText("Accord des Droits");
        jMenu1.add(AccordDroits);

        jMenuItem3.setText("Liste de presence");
        jMenu1.add(jMenuItem3);

        Attestation.setText("Attestation de presence Effective");
        jMenu1.add(Attestation);

        Certificat.setText("Certificat de Reprise de Service");
        jMenu1.add(Certificat);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Permissions et Conges");
        jMenu2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        DemandeConge.setText("Demande de Conge");
        jMenu2.add(DemandeConge);

        DemandePermission.setText("Demande de Permission");
        jMenu2.add(DemandePermission);

        AccordPermission.setText("Accorde une Permission");
        jMenu2.add(AccordPermission);

        AccordConge.setText("Accorde un Conge");
        AccordConge.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AccordCongeActionPerformed(evt);
            }
        });
        jMenu2.add(AccordConge);

        HistoConge.setText("Historique des Conges");
        jMenu2.add(HistoConge);

        HistoPermission.setText("Historique des Permissions");
        jMenu2.add(HistoPermission);

        jMenuBar1.add(jMenu2);

        courrier.setText("Courrier");
        courrier.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        EnregistreCourrier.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        EnregistreCourrier.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        EnregistreCourrier.setText("Enregistre un Courrier");
        EnregistreCourrier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EnregistreCourrierActionPerformed(evt);
            }
        });
        courrier.add(EnregistreCourrier);

        RegistreCourrierEntrant.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        RegistreCourrierEntrant.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        RegistreCourrierEntrant.setText("Registre Courrier Entrant");
        courrier.add(RegistreCourrierEntrant);

        RegistreCourrierSortant.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        RegistreCourrierSortant.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        RegistreCourrierSortant.setText("Registre Courrier Sortant");
        courrier.add(RegistreCourrierSortant);

        RegistreCourrierInterne.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        RegistreCourrierInterne.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        RegistreCourrierInterne.setText("Registre Courrier Interne");
        RegistreCourrierInterne.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegistreCourrierInterneActionPerformed(evt);
            }
        });
        courrier.add(RegistreCourrierInterne);

        RechercherCourrier.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        RechercherCourrier.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Search24.gif"))); // NOI18N
        RechercherCourrier.setText("Rechercher un Courrier");
        courrier.add(RechercherCourrier);

        jMenuBar1.add(courrier);

        jMenu5.setText("Archive");
        jMenu5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuBar1.add(jMenu5);

        jMenu6.setText("Materiels");
        jMenu6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        EnregistreMat.setText("Enregistre un Materiel");
        jMenu6.add(EnregistreMat);

        RepartitionMat.setText("Repartition des Materiel");
        jMenu6.add(RepartitionMat);

        RechercheMat.setText("Rechercher un Materiel");
        jMenu6.add(RechercheMat);

        FicheDetenteur.setText("Creer une Fiche Detenteur");
        jMenu6.add(FicheDetenteur);

        jMenuBar1.add(jMenu6);

        jMenu7.setText("Planification");
        jMenu7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuBar1.add(jMenu7);

        jMenu8.setText("Mon Compte");
        jMenu8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        deconnect.setText("Deconnection");
        jMenu8.add(deconnect);

        ModifieCompte.setText("Modifier mon Compte");
        jMenu8.add(ModifieCompte);

        para.setText("Parametre");
        jMenu8.add(para);

        jMenuBar1.add(jMenu8);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AccordCongeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AccordCongeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AccordCongeActionPerformed

    private void EnregistreCourrierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EnregistreCourrierActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EnregistreCourrierActionPerformed

    private void RegistreCourrierInterneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegistreCourrierInterneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RegistreCourrierInterneActionPerformed

    /**
     * @param args the command line arguments
     */
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem AccordConge;
    private javax.swing.JMenuItem AccordDroits;
    private javax.swing.JMenuItem AccordPermission;
    private javax.swing.JMenuItem AjouterPerso;
    private javax.swing.JMenuItem Attestation;
    private javax.swing.JMenuItem Certificat;
    private javax.swing.JMenuItem DemandeConge;
    private javax.swing.JMenuItem DemandePermission;
    private javax.swing.JMenuItem EnregistreCourrier;
    private javax.swing.JMenuItem EnregistreMat;
    private javax.swing.JMenuItem FicheDetenteur;
    private javax.swing.JMenuItem HistoConge;
    private javax.swing.JMenuItem HistoPermission;
    private javax.swing.JMenuItem ModifieCompte;
    private javax.swing.JMenuItem RechercheMat;
    private javax.swing.JMenuItem RechercherCourrier;
    private javax.swing.JMenuItem RegistreCourrierEntrant;
    private javax.swing.JMenuItem RegistreCourrierInterne;
    private javax.swing.JMenuItem RegistreCourrierSortant;
    private javax.swing.JMenuItem RepartitionMat;
    private javax.swing.JMenu courrier;
    private javax.swing.JMenuItem deconnect;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenuItem para;
    private javax.swing.JTable table;
    // End of variables declaration//GEN-END:variables
}
