/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.CtrlAccordeDroit;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JMenuItem;
import javax.swing.JTable;
import javax.swing.JTextField;

/**
 *
 * @author Jordan
 */
public class AccordeDroit extends javax.swing.JFrame {

    /**
     * Creates new form AccordeDroit
     */
    public AccordeDroit() {
        initComponents();
        CtrlAccordeDroit conn=new CtrlAccordeDroit(this);
        this.setLocationRelativeTo(this);
        this.valider.addActionListener(conn);
        this.annuler.addActionListener(conn);
        this.ajouterPerso.addActionListener(conn);
        this.demanderConger.addActionListener(conn);
        this.demanderPermission.addActionListener(conn);
        this.enregistrerMat.addActionListener(conn);
        this.rechercherMat.addActionListener(conn);
        this.repartitionMat.addActionListener(conn);
        this.fdetenteur.addActionListener(conn);
        this.disconnect.addActionListener(conn);
        this.rechercherCourrier.addActionListener(conn);
        this.enregistrerCourrier.addActionListener(conn);
        this.registreEntrant.addActionListener(conn);
        this.registreInterne.addActionListener(conn);
        this.registreSortant.addActionListener(conn);
        this.histoConge.addActionListener(conn);
        this.histoPermission.addActionListener(conn);
        this.attestation.addActionListener(conn);
        this.Certificat.addActionListener(conn);
        this.ModifierCompte.addActionListener(conn);
        this.apermission.addActionListener(conn);
        this.aconge.addActionListener(conn);
        
    } 

    public JMenuItem getCertificat() {
        return Certificat;
    }

    public void setCertificat(JMenuItem Certificat) {
        this.Certificat = Certificat;
    }

    public JMenuItem getModifierCompte() {
        return ModifierCompte;
    }

    public void setModifierCompte(JMenuItem ModifierCompte) {
        this.ModifierCompte = ModifierCompte;
    }

    public JMenuItem getAttestation() {
        return attestation;
    }

    public void setAttestation(JMenuItem attestation) {
        this.attestation = attestation;
    }
    

    public JMenuItem getEnregistrerCourrier() {
        return enregistrerCourrier;
    }

    public void setEnregistrerCourrier(JMenuItem enregistrerCourrier) {
        this.enregistrerCourrier = enregistrerCourrier;
    }

    public JMenuItem getRegistreEntrant() {
        return registreEntrant;
    }

    public void setRegistreEntrant(JMenuItem registreEntrant) {
        this.registreEntrant = registreEntrant;
    }

    public JMenuItem getRegistreInterne() {
        return registreInterne;
    }

    public void setRegistreInterne(JMenuItem registreInterne) {
        this.registreInterne = registreInterne;
    }

    public JMenuItem getRegistreSortant() {
        return registreSortant;
    }

    public void setRegistreSortant(JMenuItem registreSortant) {
        this.registreSortant = registreSortant;
    }

    public JMenuItem getRechercherCourrier() {
        return rechercherCourrier;
    }

    public void setRechercherCourrier(JMenuItem rechercherCourrier) {
        this.rechercherCourrier = rechercherCourrier;
    }
    
    

    public JMenuItem getDisconnect() {
        return disconnect;
    }

    public void setDisconnect(JMenuItem disconnect) {
        this.disconnect = disconnect;
    }

    public JMenuItem getAconge() {
        return aconge;
    }

    public void setAconge(JMenuItem aconge) {
        this.aconge = aconge;
    }

    public JMenuItem getApermission() {
        return apermission;
    }

    public void setApermission(JMenuItem apermission) {
        this.apermission = apermission;
    }

    public JMenuItem getDemanderConger() {
        return demanderConger;
    }

    public void setDemanderConger(JMenuItem demanderConger) {
        this.demanderConger = demanderConger;
    }

    public JMenuItem getDemanderPermission() {
        return demanderPermission;
    }

    public void setDemanderPermission(JMenuItem demanderPermission) {
        this.demanderPermission = demanderPermission;
    }

    public JMenuItem getEnregistrerMat() {
        return enregistrerMat;
    }

    public void setEnregistrerMat(JMenuItem enregistrerMat) {
        this.enregistrerMat = enregistrerMat;
    }

    public JMenuItem getFdetenteur() {
        return fdetenteur;
    }

    public void setFdetenteur(JMenuItem fdetenteur) {
        this.fdetenteur = fdetenteur;
    }

    public JMenuItem getHistoConge() {
        return histoConge;
    }

    public void setHistoConge(JMenuItem histoConge) {
        this.histoConge = histoConge;
    }

    public JMenuItem getHistoPermission() {
        return histoPermission;
    }

    public void setHistoPermission(JMenuItem histoPermission) {
        this.histoPermission = histoPermission;
    }

    public JMenuItem getListerMat() {
        return listerMat;
    }

    public void setListerMat(JMenuItem listerMat) {
        this.listerMat = listerMat;
    }

    public JMenuItem getRechercherMat() {
        return rechercherMat;
    }

    public void setRechercherMat(JMenuItem rechercherMat) {
        this.rechercherMat = rechercherMat;
    }

    public JMenuItem getReformerMat() {
        return reformerMat;
    }

    public void setReformerMat(JMenuItem reformerMat) {
        this.reformerMat = reformerMat;
    }

    public JMenuItem getRepartitionMat() {
        return repartitionMat;
    }

    public void setRepartitionMat(JMenuItem repartitionMat) {
        this.repartitionMat = repartitionMat;
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        footer1 = new view.Footer();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        valider = new javax.swing.JButton();
        annuler = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        matricule = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        connection = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        materiel = new javax.swing.JComboBox();
        jLabel4 = new javax.swing.JLabel();
        courrier = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        admin = new javax.swing.JComboBox();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        ajouterPerso = new javax.swing.JMenuItem();
        accorderDroit = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem10 = new javax.swing.JMenuItem();
        jMenuItem11 = new javax.swing.JMenuItem();
        attestation = new javax.swing.JMenuItem();
        Certificat = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        demanderPermission = new javax.swing.JMenuItem();
        demanderConger = new javax.swing.JMenuItem();
        apermission = new javax.swing.JMenuItem();
        aconge = new javax.swing.JMenuItem();
        histoConge = new javax.swing.JMenuItem();
        histoPermission = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        enregistrerCourrier = new javax.swing.JMenuItem();
        registreEntrant = new javax.swing.JMenuItem();
        registreSortant = new javax.swing.JMenuItem();
        registreInterne = new javax.swing.JMenuItem();
        rechercherCourrier = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();
        enregistrerMat = new javax.swing.JMenuItem();
        repartitionMat = new javax.swing.JMenuItem();
        rechercherMat = new javax.swing.JMenuItem();
        reformerMat = new javax.swing.JMenuItem();
        listerMat = new javax.swing.JMenuItem();
        fdetenteur = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        jMenu8 = new javax.swing.JMenu();
        disconnect = new javax.swing.JMenuItem();
        jMenuItem22 = new javax.swing.JMenuItem();
        jMenuItem23 = new javax.swing.JMenuItem();
        jMenuItem24 = new javax.swing.JMenuItem();
        ModifierCompte = new javax.swing.JMenuItem();

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "matricule", "Nom", "Administrateur", "Connection", "Courrier", "Materiel"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(table);

        valider.setText("Valider");

        annuler.setText("Annuler");

        jLabel1.setText("Matricule");

        matricule.setText(" ");

        jLabel2.setText("Connection");

        connection.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "OUI", "NON" }));

        jLabel3.setText("Materiel");

        materiel.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "OUI", "NON" }));

        jLabel4.setText("Courrier");

        courrier.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "OUI", "NON" }));

        jLabel5.setText("Aministrateur");

        admin.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "OUI", "NON" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(valider)
                .addGap(33, 33, 33)
                .addComponent(annuler)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(footer1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 556, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(matricule)
                    .addComponent(connection, 0, 157, Short.MAX_VALUE))
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(materiel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(admin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(courrier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(matricule, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(materiel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(admin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(connection, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(courrier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(valider)
                    .addComponent(annuler))
                .addGap(17, 17, 17)
                .addComponent(footer1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jMenuBar1.setForeground(new java.awt.Color(102, 255, 51));

        jMenu1.setText("Personnel");

        ajouterPerso.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        ajouterPerso.setText("Ajouter un personnel");
        jMenu1.add(ajouterPerso);

        accorderDroit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Properties24.gif"))); // NOI18N
        accorderDroit.setText("Accorder des droits");
        jMenu1.add(accorderDroit);

        jMenuItem3.setText("Retirer des droits");
        jMenu1.add(jMenuItem3);

        jMenuItem10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Edit24.gif"))); // NOI18N
        jMenuItem10.setText("Modifier un personnel");
        jMenu1.add(jMenuItem10);

        jMenuItem11.setText("Liste de presence");
        jMenu1.add(jMenuItem11);

        attestation.setText("Attestation de Presence Effective");
        jMenu1.add(attestation);

        Certificat.setText("Certificate de Reprise de Service");
        jMenu1.add(Certificat);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Permissions et conges");

        demanderPermission.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        demanderPermission.setText("demander une permission");
        demanderPermission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                demanderPermissionActionPerformed(evt);
            }
        });
        jMenu2.add(demanderPermission);

        demanderConger.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        demanderConger.setText("demander un conge");
        jMenu2.add(demanderConger);

        apermission.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        apermission.setText("accorde une permission");
        apermission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apermissionActionPerformed(evt);
            }
        });
        jMenu2.add(apermission);

        aconge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        aconge.setText("accorde un conge");
        aconge.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acongeActionPerformed(evt);
            }
        });
        jMenu2.add(aconge);

        histoConge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        histoConge.setText("historique des congés");
        jMenu2.add(histoConge);

        histoPermission.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        histoPermission.setText("historique des permissions");
        jMenu2.add(histoPermission);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("Courrier");

        enregistrerCourrier.setText("enregistrer un courrier");
        enregistrerCourrier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enregistrerCourrierActionPerformed(evt);
            }
        });
        jMenu3.add(enregistrerCourrier);

        registreEntrant.setText("registre courrier entrant");
        jMenu3.add(registreEntrant);

        registreSortant.setText("registre courrier sortant");
        jMenu3.add(registreSortant);

        registreInterne.setText("registre courrier interne");
        jMenu3.add(registreInterne);

        rechercherCourrier.setText("rechercher un courrier");
        jMenu3.add(rechercherCourrier);

        jMenuBar1.add(jMenu3);

        jMenu4.setText("Archives");
        jMenuBar1.add(jMenu4);

        jMenu6.setText("Materiel");

        enregistrerMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        enregistrerMat.setText("enregistrer un materiel");
        jMenu6.add(enregistrerMat);

        repartitionMat.setText("repartition du materiel");
        jMenu6.add(repartitionMat);

        rechercherMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Search24.gif"))); // NOI18N
        rechercherMat.setText("rechercher materiel");
        jMenu6.add(rechercherMat);

        reformerMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/TipOfTheDay24.gif"))); // NOI18N
        reformerMat.setText("reformer un materiel");
        jMenu6.add(reformerMat);

        listerMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        listerMat.setText("lister le materiel");
        jMenu6.add(listerMat);

        fdetenteur.setText("Fiche detenteur");
        jMenu6.add(fdetenteur);

        jMenuBar1.add(jMenu6);

        jMenu7.setText("Planification");
        jMenuBar1.add(jMenu7);

        jMenu8.setText("Mon compte");

        disconnect.setText("deconnection");
        jMenu8.add(disconnect);

        jMenuItem22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/ComposeMail24.gif"))); // NOI18N
        jMenuItem22.setText("envoyer un mail");
        jMenu8.add(jMenuItem22);

        jMenuItem23.setText("boite de reception");
        jMenu8.add(jMenuItem23);

        jMenuItem24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/PageSetup24.gif"))); // NOI18N
        jMenuItem24.setText("parametre");
        jMenu8.add(jMenuItem24);

        ModifierCompte.setText("Modifier mon Compte");
        jMenu8.add(ModifierCompte);

        jMenuBar1.add(jMenu8);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void demanderPermissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_demanderPermissionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_demanderPermissionActionPerformed

    private void apermissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apermissionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apermissionActionPerformed

    private void acongeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acongeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_acongeActionPerformed

    private void enregistrerCourrierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enregistrerCourrierActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_enregistrerCourrierActionPerformed

    public JMenuItem getAccorderDroit() {
        return accorderDroit;
    }

    public void setAccorderDroit(JMenuItem accorderDroit) {
        this.accorderDroit = accorderDroit;
    }

    public JMenuItem getAjouterPerso() {
        return ajouterPerso;
    }

    public void setAjouterPerso(JMenuItem ajouterPerso) {
        this.ajouterPerso = ajouterPerso;
    }

    public JButton getAnnuler() {
        return annuler;
    }

    public void setAnnuler(JButton annuler) {
        this.annuler = annuler;
    }

    public JTable getTable() {
        return table;
    }

    public void setTable(JTable table) {
        this.table = table;
    }

    public JButton getValider() {
        return valider;
    }

    public void setValider(JButton valider) {
        this.valider = valider;
    }

    public JComboBox getAdmin() {
        return admin;
    }

    public void setAdmin(JComboBox admin) {
        this.admin = admin;
    }

    public JComboBox getConnection() {
        return connection;
    }

    public void setConnection(JComboBox connection) {
        this.connection = connection;
    }

    public JComboBox getCourrier() {
        return courrier;
    }

    public void setCourrier(JComboBox courrier) {
        this.courrier = courrier;
    }

    public JComboBox getMateriel() {
        return materiel;
    }

    public void setMateriel(JComboBox materiel) {
        this.materiel = materiel;
    }

    public JTextField getMatricule() {
        return matricule;
    }

    public void setMatricule(JTextField matricule) {
        this.matricule = matricule;
    }

    /**
     * @param args the command line arguments
     */
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem Certificat;
    private javax.swing.JMenuItem ModifierCompte;
    private javax.swing.JMenuItem accorderDroit;
    private javax.swing.JMenuItem aconge;
    private javax.swing.JComboBox admin;
    private javax.swing.JMenuItem ajouterPerso;
    private javax.swing.JButton annuler;
    private javax.swing.JMenuItem apermission;
    private javax.swing.JMenuItem attestation;
    private javax.swing.JComboBox connection;
    private javax.swing.JComboBox courrier;
    private javax.swing.JMenuItem demanderConger;
    private javax.swing.JMenuItem demanderPermission;
    private javax.swing.JMenuItem disconnect;
    private javax.swing.JMenuItem enregistrerCourrier;
    private javax.swing.JMenuItem enregistrerMat;
    private javax.swing.JMenuItem fdetenteur;
    private view.Footer footer1;
    private javax.swing.JMenuItem histoConge;
    private javax.swing.JMenuItem histoPermission;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem22;
    private javax.swing.JMenuItem jMenuItem23;
    private javax.swing.JMenuItem jMenuItem24;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenuItem listerMat;
    private javax.swing.JComboBox materiel;
    private javax.swing.JTextField matricule;
    private javax.swing.JMenuItem rechercherCourrier;
    private javax.swing.JMenuItem rechercherMat;
    private javax.swing.JMenuItem reformerMat;
    private javax.swing.JMenuItem registreEntrant;
    private javax.swing.JMenuItem registreInterne;
    private javax.swing.JMenuItem registreSortant;
    private javax.swing.JMenuItem repartitionMat;
    private javax.swing.JTable table;
    private javax.swing.JButton valider;
    // End of variables declaration//GEN-END:variables
}
