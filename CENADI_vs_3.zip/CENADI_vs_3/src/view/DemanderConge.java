/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.CtrlConge;
import controller.CtrlDemandePermission;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JMenuItem;
import org.jdesktop.swingx.JXDatePicker;

/**
 *
 * @author Jordan
 */
public class DemanderConge extends javax.swing.JFrame {

    /**
     * Creates new form DemanderConge
     */
    public DemanderConge() {
        initComponents();
        this.setLocationRelativeTo(this);
        CtrlConge conn=new CtrlConge(this);
        valider.addActionListener(conn);
        annuler.addActionListener(conn);
        this.ajouterPerso.addActionListener(conn);
        this.conger.addActionListener(conn);
        this.enregisterMat.addActionListener(conn);
        this.rechercherMat.addActionListener(conn);
        this.repartitionMat.addActionListener(conn);
        this.fdetenteur.addActionListener(conn);
        this.disconnect.addActionListener(conn);
        this.RechercheCourrier.addActionListener(conn);
        this.enregistreCourrier.addActionListener(conn);
        this.RegistreEntrant.addActionListener(conn);
        this.RegistreInterne.addActionListener(conn);
        this.RegistreSortant.addActionListener(conn);
        this.histoconge.addActionListener(conn);
        this.histopermission.addActionListener(conn);
        this.attestation.addActionListener(conn);
        this.Certificat.addActionListener(conn);
        this.ModifierCompte.addActionListener(conn);
        this.apermission.addActionListener(conn);
        this.aconge.addActionListener(conn);
        this.permission.addActionListener(conn);
       }  

    public JMenuItem getCertificat() {
        return Certificat;
    }

    public void setCertificat(JMenuItem Certificat) {
        this.Certificat = Certificat;
    }

    public JMenuItem getModifierCompte() {
        return ModifierCompte;
    }

    public void setModifierCompte(JMenuItem ModifierCompte) {
        this.ModifierCompte = ModifierCompte;
    }

    public JMenuItem getRechercheCourrier() {
        return RechercheCourrier;
    }

    public void setRechercheCourrier(JMenuItem RechercheCourrier) {
        this.RechercheCourrier = RechercheCourrier;
    }

    public JMenuItem getRegistreEntrant() {
        return RegistreEntrant;
    }

    public void setRegistreEntrant(JMenuItem RegistreEntrant) {
        this.RegistreEntrant = RegistreEntrant;
    }

    public JMenuItem getRegistreInterne() {
        return RegistreInterne;
    }

    public void setRegistreInterne(JMenuItem RegistreInterne) {
        this.RegistreInterne = RegistreInterne;
    }

    public JMenuItem getRegistreSortant() {
        return RegistreSortant;
    }

    public void setRegistreSortant(JMenuItem RegistreSortant) {
        this.RegistreSortant = RegistreSortant;
    }

    public JMenuItem getAttestation() {
        return attestation;
    }

    public void setAttestation(JMenuItem attestation) {
        this.attestation = attestation;
    }

    public JMenuItem getEnregistreCourrier() {
        return enregistreCourrier;
    }

    public void setEnregistreCourrier(JMenuItem enregistreCourrier) {
        this.enregistreCourrier = enregistreCourrier;
    }

    public JMenuItem getAconge() {
        return aconge;
    }

    public void setAconge(JMenuItem aconge) {
        this.aconge = aconge;
    }

    public JMenuItem getApermission() {
        return apermission;
    }

    public void setApermission(JMenuItem apermission) {
        this.apermission = apermission;
    }

    public JMenuItem getHistoconge() {
        return histoconge;
    }

    public void setHistoconge(JMenuItem histoconge) {
        this.histoconge = histoconge;
    }

    public JMenuItem getHistopermission() {
        return histopermission;
    }

    public void setHistopermission(JMenuItem histopermission) {
        this.histopermission = histopermission;
    }
    public JMenuItem getDisconnect() {
        return disconnect;
    }

    public void setDisconnect(JMenuItem disconnect) {
        this.disconnect = disconnect;
    }

    public JMenuItem getEnregisterMat() {
        return enregisterMat;
    }

    public void setEnregisterMat(JMenuItem enregisterMat) {
        this.enregisterMat = enregisterMat;
    }

    public JMenuItem getFdetenteur() {
        return fdetenteur;
    }

    public void setFdetenteur(JMenuItem fdetenteur) {
        this.fdetenteur = fdetenteur;
    }

    public JMenuItem getListerMat() {
        return listerMat;
    }

    public void setListerMat(JMenuItem listerMat) {
        this.listerMat = listerMat;
    }

    public JMenuItem getPermission() {
        return permission;
    }

    public void setPermission(JMenuItem permission) {
        this.permission = permission;
    }

    public JMenuItem getRechercherMat() {
        return rechercherMat;
    }

    public void setRechercherMat(JMenuItem rechercherMat) {
        this.rechercherMat = rechercherMat;
    }

    public JMenuItem getReformerMat() {
        return reformerMat;
    }

    public void setReformerMat(JMenuItem reformerMat) {
        this.reformerMat = reformerMat;
    }

    public JMenuItem getRepartitionMat() {
        return repartitionMat;
    }

    public void setRepartitionMat(JMenuItem repartitionMat) {
        this.repartitionMat = repartitionMat;
    }
    

    public JMenuItem getAccorderDroit() {
        return accorderDroit;
    }

    public void setAccorderDroit(JMenuItem accorderDroit) {
        this.accorderDroit = accorderDroit;
    }

    public JMenuItem getAjouterPerso() {
        return ajouterPerso;
    }

    public void setAjouterPerso(JMenuItem ajouterPerso) {
        this.ajouterPerso = ajouterPerso;
    }

    public JButton getAnnuler() {
        return annuler;
    }

    public void setAnnuler(JButton annuler) {
        this.annuler = annuler;
    }

    public JXDatePicker getDebut() {
        return debut;
    }

    public void setDebut(JXDatePicker debut) {
        this.debut = debut;
    }

    public JComboBox getExercice() {
        return exercice;
    }

    public void setExercice(JComboBox exercice) {
        this.exercice = exercice;
    }

    public JXDatePicker getFin() {
        return fin;
    }

    public void setFin(JXDatePicker fin) {
        this.fin = fin;
    }

    public JButton getValider() {
        return valider;
    }

    public void setValider(JButton valider) {
        this.valider = valider;
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem16 = new javax.swing.JMenuItem();
        jMenuItem18 = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        footer1 = new view.Footer();
        jLabel1 = new javax.swing.JLabel();
        exercice = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        debut = new org.jdesktop.swingx.JXDatePicker();
        jLabel3 = new javax.swing.JLabel();
        fin = new org.jdesktop.swingx.JXDatePicker();
        valider = new javax.swing.JButton();
        annuler = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        ajouterPerso = new javax.swing.JMenuItem();
        accorderDroit = new javax.swing.JMenuItem();
        jMenuItem11 = new javax.swing.JMenuItem();
        attestation = new javax.swing.JMenuItem();
        Certificat = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        permission = new javax.swing.JMenuItem();
        conger = new javax.swing.JMenuItem();
        apermission = new javax.swing.JMenuItem();
        aconge = new javax.swing.JMenuItem();
        histoconge = new javax.swing.JMenuItem();
        histopermission = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        enregistreCourrier = new javax.swing.JMenuItem();
        RegistreEntrant = new javax.swing.JMenuItem();
        RegistreSortant = new javax.swing.JMenuItem();
        RegistreInterne = new javax.swing.JMenuItem();
        RechercheCourrier = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();
        enregisterMat = new javax.swing.JMenuItem();
        repartitionMat = new javax.swing.JMenuItem();
        rechercherMat = new javax.swing.JMenuItem();
        reformerMat = new javax.swing.JMenuItem();
        listerMat = new javax.swing.JMenuItem();
        fdetenteur = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        jMenu8 = new javax.swing.JMenu();
        disconnect = new javax.swing.JMenuItem();
        jMenuItem24 = new javax.swing.JMenuItem();
        ModifierCompte = new javax.swing.JMenuItem();

        jMenuItem16.setText("jMenuItem16");

        jMenuItem18.setText("jMenuItem18");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel1.setText("Exercice");

        exercice.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        exercice.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "2017-2018", "2018-2019", "2019-2020", "2020-2021" }));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setText("Debut");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setText("Fin");

        valider.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/SaveAll24.gif"))); // NOI18N
        valider.setText("Valider");

        annuler.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Delete24.gif"))); // NOI18N
        annuler.setText("Annuler");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 28, Short.MAX_VALUE)
                .addComponent(footer1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(87, 87, 87)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(debut, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(exercice, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(valider)
                            .addComponent(fin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(26, 26, 26)
                .addComponent(annuler)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(exercice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(debut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(fin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(valider)
                    .addComponent(annuler))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addComponent(footer1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jMenuBar1.setForeground(new java.awt.Color(102, 255, 51));

        jMenu1.setText("Personnel");

        ajouterPerso.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        ajouterPerso.setText("Ajouter un personnel");
        jMenu1.add(ajouterPerso);

        accorderDroit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Properties24.gif"))); // NOI18N
        accorderDroit.setText("Accorder des droits");
        jMenu1.add(accorderDroit);

        jMenuItem11.setText("Liste de presence");
        jMenu1.add(jMenuItem11);

        attestation.setText("Attestation de presence");
        jMenu1.add(attestation);

        Certificat.setText("Certificat de Reprise de Service");
        jMenu1.add(Certificat);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Permissions et conges");

        permission.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        permission.setText("demander une permission");
        permission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                permissionActionPerformed(evt);
            }
        });
        jMenu2.add(permission);

        conger.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        conger.setText("demander un conge");
        jMenu2.add(conger);

        apermission.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        apermission.setText("accorde une permission");
        apermission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apermissionActionPerformed(evt);
            }
        });
        jMenu2.add(apermission);

        aconge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        aconge.setText("accorde un conge");
        aconge.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acongeActionPerformed(evt);
            }
        });
        jMenu2.add(aconge);

        histoconge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        histoconge.setText("historique des congés");
        jMenu2.add(histoconge);

        histopermission.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        histopermission.setText("historique des permissions");
        jMenu2.add(histopermission);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("Courrier");

        enregistreCourrier.setText("enregistrer un courrier");
        jMenu3.add(enregistreCourrier);

        RegistreEntrant.setText("registre courrier entrant");
        RegistreEntrant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegistreEntrantActionPerformed(evt);
            }
        });
        jMenu3.add(RegistreEntrant);

        RegistreSortant.setText("registre courrier sortant");
        jMenu3.add(RegistreSortant);

        RegistreInterne.setText("registre courrier interne");
        jMenu3.add(RegistreInterne);

        RechercheCourrier.setText("Rechercher un Courrier");
        jMenu3.add(RechercheCourrier);

        jMenuBar1.add(jMenu3);

        jMenu4.setText("Archives");
        jMenuBar1.add(jMenu4);

        jMenu6.setText("Materiel");

        enregisterMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        enregisterMat.setText("enregistrer un materiel");
        jMenu6.add(enregisterMat);

        repartitionMat.setText("repartition du materiel");
        jMenu6.add(repartitionMat);

        rechercherMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Search24.gif"))); // NOI18N
        rechercherMat.setText("rechercher materiel");
        jMenu6.add(rechercherMat);

        reformerMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/TipOfTheDay24.gif"))); // NOI18N
        reformerMat.setText("reformer un materiel");
        jMenu6.add(reformerMat);

        listerMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        listerMat.setText("lister le materiel");
        jMenu6.add(listerMat);

        fdetenteur.setText("Fiche detenteur");
        jMenu6.add(fdetenteur);

        jMenuBar1.add(jMenu6);

        jMenu7.setText("Planification");
        jMenuBar1.add(jMenu7);

        jMenu8.setText("Mon compte");

        disconnect.setText("deconnection");
        jMenu8.add(disconnect);

        jMenuItem24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/PageSetup24.gif"))); // NOI18N
        jMenuItem24.setText("parametre");
        jMenu8.add(jMenuItem24);

        ModifierCompte.setText("Modifier Mon Compte");
        jMenu8.add(ModifierCompte);

        jMenuBar1.add(jMenu8);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void permissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_permissionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_permissionActionPerformed

    private void apermissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apermissionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apermissionActionPerformed

    private void acongeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acongeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_acongeActionPerformed

    private void RegistreEntrantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegistreEntrantActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RegistreEntrantActionPerformed

    /**
     * @param args the command line arguments
     */
     

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem Certificat;
    private javax.swing.JMenuItem ModifierCompte;
    private javax.swing.JMenuItem RechercheCourrier;
    private javax.swing.JMenuItem RegistreEntrant;
    private javax.swing.JMenuItem RegistreInterne;
    private javax.swing.JMenuItem RegistreSortant;
    private javax.swing.JMenuItem accorderDroit;
    private javax.swing.JMenuItem aconge;
    private javax.swing.JMenuItem ajouterPerso;
    private javax.swing.JButton annuler;
    private javax.swing.JMenuItem apermission;
    private javax.swing.JMenuItem attestation;
    private javax.swing.JMenuItem conger;
    private org.jdesktop.swingx.JXDatePicker debut;
    private javax.swing.JMenuItem disconnect;
    private javax.swing.JMenuItem enregisterMat;
    private javax.swing.JMenuItem enregistreCourrier;
    private javax.swing.JComboBox exercice;
    private javax.swing.JMenuItem fdetenteur;
    private org.jdesktop.swingx.JXDatePicker fin;
    private view.Footer footer1;
    private javax.swing.JMenuItem histoconge;
    private javax.swing.JMenuItem histopermission;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem16;
    private javax.swing.JMenuItem jMenuItem18;
    private javax.swing.JMenuItem jMenuItem24;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JMenuItem listerMat;
    private javax.swing.JMenuItem permission;
    private javax.swing.JMenuItem rechercherMat;
    private javax.swing.JMenuItem reformerMat;
    private javax.swing.JMenuItem repartitionMat;
    private javax.swing.JButton valider;
    // End of variables declaration//GEN-END:variables
}
