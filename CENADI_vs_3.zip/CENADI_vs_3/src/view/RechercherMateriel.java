/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.CtrlRechercherMateriel;
import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Jordan
 */
public class RechercherMateriel extends javax.swing.JFrame {

    /**
     * Creates new form ReceptionnerMateriel
     */
    public RechercherMateriel() {
        initComponents();
        this.setLocationRelativeTo(this);
        this.information.setVisible(false);
        CtrlRechercherMateriel conn=new CtrlRechercherMateriel(this);
        this.rechercher.addActionListener(conn);
    this.ajouterPerso.addActionListener(conn);
        this.conge.addActionListener(conn);
        this.enregistrerMat.addActionListener(conn);
        this.rechercherMat.addActionListener(conn);
        this.repartitionMat.addActionListener(conn);
        this.fdetenteur.addActionListener(conn);
        this.disconnect.addActionListener(conn);
        this.RechercheCourrier.addActionListener(conn);
        this.EnregistreCourrier.addActionListener(conn);
        this.RegistreEntrant.addActionListener(conn);
        this.RegistreInterne.addActionListener(conn);
        this.RegistreSortant.addActionListener(conn);
        this.histoconge.addActionListener(conn);
        this.histopermission.addActionListener(conn);
        this.Attestation.addActionListener(conn);
        this.Certificat.addActionListener(conn);
        this.ModifieCompte.addActionListener(conn);
        this.apermission.addActionListener(conn);
        this.aconge.addActionListener(conn);
        this.permission.addActionListener(conn);    
    }  

    public JMenuItem getAttestation() {
        return Attestation;
    }

    public void setAttestation(JMenuItem Attestation) {
        this.Attestation = Attestation;
    }

    public JMenuItem getCertificat() {
        return Certificat;
    }

    public void setCertificat(JMenuItem Certificat) {
        this.Certificat = Certificat;
    }

    public JMenuItem getEnregistreCourrier() {
        return EnregistreCourrier;
    }

    public void setEnregistreCourrier(JMenuItem EnregistreCourrier) {
        this.EnregistreCourrier = EnregistreCourrier;
    }

    public JMenuItem getModifieCompte() {
        return ModifieCompte;
    }

    public void setModifieCompte(JMenuItem ModifieCompte) {
        this.ModifieCompte = ModifieCompte;
    }

    public JMenuItem getRechercheCourrier() {
        return RechercheCourrier;
    }

    public void setRechercheCourrier(JMenuItem RechercheCourrier) {
        this.RechercheCourrier = RechercheCourrier;
    }

    public JMenuItem getRegistreEntrant() {
        return RegistreEntrant;
    }

    public void setRegistreEntrant(JMenuItem RegistreEntrant) {
        this.RegistreEntrant = RegistreEntrant;
    }

    public JMenuItem getRegistreInterne() {
        return RegistreInterne;
    }

    public void setRegistreInterne(JMenuItem RegistreInterne) {
        this.RegistreInterne = RegistreInterne;
    }

    public JMenuItem getRegistreSortant() {
        return RegistreSortant;
    }

    public void setRegistreSortant(JMenuItem RegistreSortant) {
        this.RegistreSortant = RegistreSortant;
    }

    public JMenuItem getAconge() {
        return aconge;
    }

    public void setAconge(JMenuItem aconge) {
        this.aconge = aconge;
    }

    public JMenuItem getApermission() {
        return apermission;
    }

    public void setApermission(JMenuItem apermission) {
        this.apermission = apermission;
    }

    public JMenuItem getConge() {
        return conge;
    }

    public void setConge(JMenuItem conge) {
        this.conge = conge;
    }

    public JMenuItem getDisconnect() {
        return disconnect;
    }

    public void setDisconnect(JMenuItem disconnect) {
        this.disconnect = disconnect;
    }

    public JMenuItem getEnregistrerMat() {
        return enregistrerMat;
    }

    public void setEnregistrerMat(JMenuItem enregistrerMat) {
        this.enregistrerMat = enregistrerMat;
    }

    public JMenuItem getFdetenteur() {
        return fdetenteur;
    }

    public void setFdetenteur(JMenuItem fdetenteur) {
        this.fdetenteur = fdetenteur;
    }

    public JMenuItem getHistoconge() {
        return histoconge;
    }

    public void setHistoconge(JMenuItem histoconge) {
        this.histoconge = histoconge;
    }

    public JMenuItem getHistopermission() {
        return histopermission;
    }

    public void setHistopermission(JMenuItem histopermission) {
        this.histopermission = histopermission;
    }

    public JMenuItem getListerMat() {
        return listerMat;
    }

    public void setListerMat(JMenuItem listerMat) {
        this.listerMat = listerMat;
    }

    public JMenuItem getPermission() {
        return permission;
    }

    public void setPermission(JMenuItem permission) {
        this.permission = permission;
    }

    public JMenuItem getRechercherMat() {
        return rechercherMat;
    }

    public void setRechercherMat(JMenuItem rechercherMat) {
        this.rechercherMat = rechercherMat;
    }

    public JMenuItem getReformerMat() {
        return reformerMat;
    }

    public void setReformerMat(JMenuItem reformerMat) {
        this.reformerMat = reformerMat;
    }

    public JMenuItem getRepartitionMat() {
        return repartitionMat;
    }

    public void setRepartitionMat(JMenuItem repartitionMat) {
        this.repartitionMat = repartitionMat;
    }
    

    public JButton getRechercher() {
        return rechercher;
    }

    public void setRechercher(JButton rechercher) {
        this.rechercher = rechercher;
    }
    

    public JMenuItem getAccorderDroit() {
        return accorderDroit;
    }

    public void setAccorderDroit(JMenuItem accorderDroit) {
        this.accorderDroit = accorderDroit;
    }

    public JMenuItem getAjouterPerso() {
        return ajouterPerso;
    }

    public void setAjouterPerso(JMenuItem ajouterPerso) {
        this.ajouterPerso = ajouterPerso;
    }

    public JTextField getFond() {
        return fond;
    }

    public void setFond(JTextField fond) {
        this.fond = fond;
    }

    public Footer getFooter1() {
        return footer1;
    }

    public void setFooter1(Footer footer1) {
        this.footer1 = footer1;
    }

    public JPanel getInformation() {
        return information;
    }

    public void setInformation(JPanel information) {
        this.information = information;
    }

    public JTextField getMarque() {
        return marque;
    }

    public void setMarque(JTextField marque) {
        this.marque = marque;
    }

    public JTextField getNoserie() {
        return noserie;
    }

    public void setNoserie(JTextField noserie) {
        this.noserie = noserie;
    }

    public JTextField getPersonnel() {
        return personnel;
    }

    public void setPersonnel(JTextField personnel) {
        this.personnel = personnel;
    }

    public JTextField getReference() {
        return reference;
    }

    public void setReference(JTextField reference) {
        this.reference = reference;
    }

    public JTextField getSituation() {
        return situation;
    }

    public void setSituation(JTextField situation) {
        this.situation = situation;
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu5 = new javax.swing.JMenu();
        jPanel1 = new javax.swing.JPanel();
        footer1 = new view.Footer();
        jLabel1 = new javax.swing.JLabel();
        reference = new javax.swing.JTextField();
        rechercher = new javax.swing.JButton();
        information = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        marque = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        fond = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        noserie = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        situation = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        personnel = new javax.swing.JTextField();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        ajouterPerso = new javax.swing.JMenuItem();
        accorderDroit = new javax.swing.JMenuItem();
        jMenuItem11 = new javax.swing.JMenuItem();
        Attestation = new javax.swing.JMenuItem();
        Certificat = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        permission = new javax.swing.JMenuItem();
        conge = new javax.swing.JMenuItem();
        apermission = new javax.swing.JMenuItem();
        aconge = new javax.swing.JMenuItem();
        histoconge = new javax.swing.JMenuItem();
        histopermission = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        EnregistreCourrier = new javax.swing.JMenuItem();
        RegistreEntrant = new javax.swing.JMenuItem();
        RegistreSortant = new javax.swing.JMenuItem();
        RegistreInterne = new javax.swing.JMenuItem();
        RechercheCourrier = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();
        enregistrerMat = new javax.swing.JMenuItem();
        repartitionMat = new javax.swing.JMenuItem();
        rechercherMat = new javax.swing.JMenuItem();
        reformerMat = new javax.swing.JMenuItem();
        listerMat = new javax.swing.JMenuItem();
        fdetenteur = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        jMenu8 = new javax.swing.JMenu();
        disconnect = new javax.swing.JMenuItem();
        ModifieCompte = new javax.swing.JMenuItem();
        jMenuItem24 = new javax.swing.JMenuItem();

        jMenu5.setText("jMenu5");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("AGRHM");

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel1.setText("Reference");

        reference.setText(" ");

        rechercher.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Search24.gif"))); // NOI18N
        rechercher.setText("Rechercher");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setText("Marque");

        marque.setEditable(false);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setText("Fond");

        fond.setEditable(false);
        fond.setText(" ");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setText("n°serie");

        noserie.setEditable(false);
        noserie.setText(" ");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setText("Situation");

        situation.setEditable(false);
        situation.setText(" ");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel6.setText("Personnel");

        personnel.setEditable(false);
        personnel.setText(" ");

        javax.swing.GroupLayout informationLayout = new javax.swing.GroupLayout(information);
        information.setLayout(informationLayout);
        informationLayout.setHorizontalGroup(
            informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(informationLayout.createSequentialGroup()
                .addGroup(informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addGap(37, 37, 37)
                .addGroup(informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(marque)
                    .addComponent(fond)
                    .addComponent(noserie)
                    .addComponent(situation)
                    .addComponent(personnel)))
        );
        informationLayout.setVerticalGroup(
            informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(informationLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(marque, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(fond, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(noserie, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(situation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(personnel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(48, 48, 48)
                .addComponent(reference, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(rechercher)
                .addGap(23, 23, 23))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(footer1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(information, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(70, 70, 70))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(reference, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rechercher, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(information, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addComponent(footer1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jMenuBar1.setForeground(new java.awt.Color(102, 255, 51));

        jMenu1.setText("Personnel");

        ajouterPerso.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        ajouterPerso.setText("Ajouter un personnel");
        jMenu1.add(ajouterPerso);

        accorderDroit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Properties24.gif"))); // NOI18N
        accorderDroit.setText("Accorder des droits");
        jMenu1.add(accorderDroit);

        jMenuItem11.setText("Liste de presence");
        jMenu1.add(jMenuItem11);

        Attestation.setText("Attestation de Presence Effective");
        jMenu1.add(Attestation);

        Certificat.setText("Certificat de Reprise de Service");
        jMenu1.add(Certificat);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Permissions et conges");

        permission.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        permission.setText("demander une permission");
        permission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                permissionActionPerformed(evt);
            }
        });
        jMenu2.add(permission);

        conge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        conge.setText("demander un conge");
        jMenu2.add(conge);

        apermission.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        apermission.setText("accorde une permission");
        apermission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apermissionActionPerformed(evt);
            }
        });
        jMenu2.add(apermission);

        aconge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Add24.gif"))); // NOI18N
        aconge.setText("accorde un conge");
        aconge.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acongeActionPerformed(evt);
            }
        });
        jMenu2.add(aconge);

        histoconge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        histoconge.setText("historique des congés");
        jMenu2.add(histoconge);

        histopermission.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        histopermission.setText("historique des permissions");
        jMenu2.add(histopermission);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("Courrier");

        EnregistreCourrier.setText("enregistrer un courrier");
        jMenu3.add(EnregistreCourrier);

        RegistreEntrant.setText("registre courrier entrant");
        jMenu3.add(RegistreEntrant);

        RegistreSortant.setText("registre courrier sortant");
        jMenu3.add(RegistreSortant);

        RegistreInterne.setText("registre courrier interne");
        jMenu3.add(RegistreInterne);

        RechercheCourrier.setText("Rechercher un Courrier");
        jMenu3.add(RechercheCourrier);

        jMenuBar1.add(jMenu3);

        jMenu4.setText("Archives");
        jMenuBar1.add(jMenu4);

        jMenu6.setText("Materiel");

        enregistrerMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        enregistrerMat.setText("enregistrer un materiel");
        jMenu6.add(enregistrerMat);

        repartitionMat.setText("repartition du materiel");
        jMenu6.add(repartitionMat);

        rechercherMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Search24.gif"))); // NOI18N
        rechercherMat.setText("rechercher materiel");
        jMenu6.add(rechercherMat);

        reformerMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/TipOfTheDay24.gif"))); // NOI18N
        reformerMat.setText("reformer un materiel");
        jMenu6.add(reformerMat);

        listerMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        listerMat.setText("lister le materiel");
        jMenu6.add(listerMat);

        fdetenteur.setText("Fiche detenteur");
        jMenu6.add(fdetenteur);

        jMenuBar1.add(jMenu6);

        jMenu7.setText("Planification");
        jMenuBar1.add(jMenu7);

        jMenu8.setText("Mon compte");

        disconnect.setText("deconnection");
        jMenu8.add(disconnect);

        ModifieCompte.setText("Modifier mon Compte");
        jMenu8.add(ModifieCompte);

        jMenuItem24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/PageSetup24.gif"))); // NOI18N
        jMenuItem24.setText("parametre");
        jMenu8.add(jMenuItem24);

        jMenuBar1.add(jMenu8);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void permissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_permissionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_permissionActionPerformed

    private void apermissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apermissionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apermissionActionPerformed

    private void acongeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acongeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_acongeActionPerformed

    /**
     * @param args the command line arguments
     */
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem Attestation;
    private javax.swing.JMenuItem Certificat;
    private javax.swing.JMenuItem EnregistreCourrier;
    private javax.swing.JMenuItem ModifieCompte;
    private javax.swing.JMenuItem RechercheCourrier;
    private javax.swing.JMenuItem RegistreEntrant;
    private javax.swing.JMenuItem RegistreInterne;
    private javax.swing.JMenuItem RegistreSortant;
    private javax.swing.JMenuItem accorderDroit;
    private javax.swing.JMenuItem aconge;
    private javax.swing.JMenuItem ajouterPerso;
    private javax.swing.JMenuItem apermission;
    private javax.swing.JMenuItem conge;
    private javax.swing.JMenuItem disconnect;
    private javax.swing.JMenuItem enregistrerMat;
    private javax.swing.JMenuItem fdetenteur;
    private javax.swing.JTextField fond;
    private view.Footer footer1;
    private javax.swing.JMenuItem histoconge;
    private javax.swing.JMenuItem histopermission;
    private javax.swing.JPanel information;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem24;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JMenuItem listerMat;
    private javax.swing.JTextField marque;
    private javax.swing.JTextField noserie;
    private javax.swing.JMenuItem permission;
    private javax.swing.JTextField personnel;
    private javax.swing.JButton rechercher;
    private javax.swing.JMenuItem rechercherMat;
    private javax.swing.JTextField reference;
    private javax.swing.JMenuItem reformerMat;
    private javax.swing.JMenuItem repartitionMat;
    private javax.swing.JTextField situation;
    // End of variables declaration//GEN-END:variables
}
