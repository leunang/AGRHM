/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.CtrlDemandePermission;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JMenuItem;
import javax.swing.JTextField;
import org.jdesktop.swingx.JXDatePicker;

/**
 *
 * @author Jordan
 */
public class DemandePermission extends javax.swing.JFrame {

    /**
     * Creates new form DemandePermission
     */
    public DemandePermission() {
        initComponents();
        this.setLocationRelativeTo(this);
        CtrlDemandePermission conn=new CtrlDemandePermission(this);
        valider.addActionListener(conn);
        annuler.addActionListener(conn);
        this.ajouterPerso.addActionListener(conn);
        this.demanderConge.addActionListener(conn);
        this.EnregistrerMat.addActionListener(conn);
        this.rechercherMat.addActionListener(conn);
        this.repartitionMat.addActionListener(conn);
        this.fdetenteur.addActionListener(conn);
        this.disconnect.addActionListener(conn);
        this.RechercheCourrier.addActionListener(conn);
        this.Enregistrecourrier.addActionListener(conn);
        this.RegistreEntrant.addActionListener(conn);
        this.RegistreInterne.addActionListener(conn);
        this.RegistreSortant.addActionListener(conn);
        this.HistoConge.addActionListener(conn);
        this.HistoPermission.addActionListener(conn);
        this.attestation.addActionListener(conn);
        this.Certificat.addActionListener(conn);
        this.ModifieCompte.addActionListener(conn);
        this.accordePermission.addActionListener(conn);
        this.accordeConge.addActionListener(conn);
        this.demanderPermission.addActionListener(conn);
    } 

    public JMenuItem getCertificat() {
        return Certificat;
    }

    public void setCertificat(JMenuItem Certificat) {
        this.Certificat = Certificat;
    }

    public JMenuItem getEnregistrecourrier() {
        return Enregistrecourrier;
    }

    public void setEnregistrecourrier(JMenuItem Enregistrecourrier) {
        this.Enregistrecourrier = Enregistrecourrier;
    }

    public JMenuItem getHistoConge() {
        return HistoConge;
    }

    public void setHistoConge(JMenuItem HistoConge) {
        this.HistoConge = HistoConge;
    }

    public JMenuItem getHistoPermission() {
        return HistoPermission;
    }

    public void setHistoPermission(JMenuItem HistoPermission) {
        this.HistoPermission = HistoPermission;
    }

    public JMenuItem getModifieCompte() {
        return ModifieCompte;
    }

    public void setModifieCompte(JMenuItem ModifieCompte) {
        this.ModifieCompte = ModifieCompte;
    }

    public JMenuItem getRechercheCourrier() {
        return RechercheCourrier;
    }

    public void setRechercheCourrier(JMenuItem RechercheCourrier) {
        this.RechercheCourrier = RechercheCourrier;
    }

    public JMenuItem getRegistreEntrant() {
        return RegistreEntrant;
    }

    public void setRegistreEntrant(JMenuItem RegistreEntrant) {
        this.RegistreEntrant = RegistreEntrant;
    }

    public JMenuItem getRegistreInterne() {
        return RegistreInterne;
    }

    public void setRegistreInterne(JMenuItem RegistreInterne) {
        this.RegistreInterne = RegistreInterne;
    }

    public JMenuItem getRegistreSortant() {
        return RegistreSortant;
    }

    public void setRegistreSortant(JMenuItem RegistreSortant) {
        this.RegistreSortant = RegistreSortant;
    }

    public JMenuItem getAttestation() {
        return attestation;
    }

    public void setAttestation(JMenuItem attestation) {
        this.attestation = attestation;
    }

    public JMenuItem getDisconnect() {
        return disconnect;
    }

    public void setDisconnect(JMenuItem disconnect) {
        this.disconnect = disconnect;
    }
    

    public JMenuItem getEnregistrerMat() {
        return EnregistrerMat;
    }

    public void setEnregistrerMat(JMenuItem EnregistrerMat) {
        this.EnregistrerMat = EnregistrerMat;
    }

    public JMenuItem getAccordeConge() {
        return accordeConge;
    }

    public void setAccordeConge(JMenuItem accordeConge) {
        this.accordeConge = accordeConge;
    }

    public JMenuItem getAccordeDroit() {
        return accordeDroit;
    }

    public void setAccordeDroit(JMenuItem accordeDroit) {
        this.accordeDroit = accordeDroit;
    }

    public JMenuItem getAccordePermission() {
        return accordePermission;
    }

    public void setAccordePermission(JMenuItem accordePermission) {
        this.accordePermission = accordePermission;
    }

    public JMenuItem getAjouterPerso() {
        return ajouterPerso;
    }

    public void setAjouterPerso(JMenuItem ajouterPerso) {
        this.ajouterPerso = ajouterPerso;
    }

    public JMenuItem getDemanderConge() {
        return demanderConge;
    }

    public void setDemanderConge(JMenuItem demanderConge) {
        this.demanderConge = demanderConge;
    }

    public JMenuItem getDemanderPermission() {
        return demanderPermission;
    }

    public void setDemanderPermission(JMenuItem demanderPermission) {
        this.demanderPermission = demanderPermission;
    }

    public JMenuItem getFdetenteur() {
        return fdetenteur;
    }

    public void setFdetenteur(JMenuItem fdetenteur) {
        this.fdetenteur = fdetenteur;
    }

    public JMenuItem getRechercherMat() {
        return rechercherMat;
    }

    public void setRechercherMat(JMenuItem rechercherMat) {
        this.rechercherMat = rechercherMat;
    }

    public JMenuItem getRepartitionMat() {
        return repartitionMat;
    }

    public void setRepartitionMat(JMenuItem repartitionMat) {
        this.repartitionMat = repartitionMat;
    }
    

    public JButton getAnnuler() {
        return annuler;
    }

    public void setAnnuler(JButton annuler) {
        this.annuler = annuler;
    }

    public JXDatePicker getDebut() {
        return debut;
    }

    public void setDebut(JXDatePicker debut) {
        this.debut = debut;
    }

    public JComboBox getExercice() {
        return exercice;
    }

    public void setExercice(JComboBox exercice) {
        this.exercice = exercice;
    }

    public JXDatePicker getFin() {
        return fin;
    }

    public void setFin(JXDatePicker fin) {
        this.fin = fin;
    }

    public JTextField getObjet() {
        return objet;
    }

    public void setObjet(JTextField objet) {
        this.objet = objet;
    }

    public JButton getValider() {
        return valider;
    }

    public void setValider(JButton valider) {
        this.valider = valider;
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jXDatePicker1 = new org.jdesktop.swingx.JXDatePicker();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem10 = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        footer1 = new view.Footer();
        jLabel1 = new javax.swing.JLabel();
        exercice = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        objet = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        debut = new org.jdesktop.swingx.JXDatePicker();
        jLabel4 = new javax.swing.JLabel();
        fin = new org.jdesktop.swingx.JXDatePicker();
        valider = new javax.swing.JButton();
        annuler = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        ajouterPerso = new javax.swing.JMenuItem();
        accordeDroit = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        attestation = new javax.swing.JMenuItem();
        Certificat = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        demanderPermission = new javax.swing.JMenuItem();
        demanderConge = new javax.swing.JMenuItem();
        accordePermission = new javax.swing.JMenuItem();
        accordeConge = new javax.swing.JMenuItem();
        HistoConge = new javax.swing.JMenuItem();
        HistoPermission = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        Enregistrecourrier = new javax.swing.JMenuItem();
        RegistreEntrant = new javax.swing.JMenuItem();
        RegistreSortant = new javax.swing.JMenuItem();
        RegistreInterne = new javax.swing.JMenuItem();
        RechercheCourrier = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();
        EnregistrerMat = new javax.swing.JMenuItem();
        repartitionMat = new javax.swing.JMenuItem();
        rechercherMat = new javax.swing.JMenuItem();
        fdetenteur = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        jMenu8 = new javax.swing.JMenu();
        disconnect = new javax.swing.JMenuItem();
        ModifieCompte = new javax.swing.JMenuItem();

        jXDatePicker1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jXDatePicker1ActionPerformed(evt);
            }
        });

        jMenuItem5.setText("jMenuItem5");

        jMenuItem10.setText("jMenuItem10");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("AGRHM");
        setBackground(new java.awt.Color(102, 255, 102));
        setBounds(new java.awt.Rectangle(0, 0, 0, 0));

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel1.setText("Exercice");

        exercice.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        exercice.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "2019-2020", "2020-2021", "2021-2022" }));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setText("Objet");

        objet.setText("objet de la permission");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setText("Debut");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setText("Fin");

        valider.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/SaveAll24.gif"))); // NOI18N
        valider.setText("Valider");

        annuler.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Remove24.gif"))); // NOI18N
        annuler.setText("Annuler");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 53, Short.MAX_VALUE)
                .addComponent(footer1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel3)
                        .addComponent(jLabel2)))
                .addGap(102, 102, 102)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(objet)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(exercice, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(valider)
                                    .addComponent(debut, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(fin, javax.swing.GroupLayout.DEFAULT_SIZE, 167, Short.MAX_VALUE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(annuler)
                                        .addGap(0, 0, Short.MAX_VALUE)))))
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(exercice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(objet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(debut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(fin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(valider)
                    .addComponent(annuler))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addComponent(footer1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jMenuBar1.setForeground(new java.awt.Color(102, 255, 51));

        jMenu1.setText("Personnel");

        ajouterPerso.setText("ajouter personnel");
        jMenu1.add(ajouterPerso);

        accordeDroit.setText("accorde des droits");
        jMenu1.add(accordeDroit);

        jMenuItem2.setText("liste de presence");
        jMenu1.add(jMenuItem2);

        attestation.setText("Attestation de presence");
        jMenu1.add(attestation);

        Certificat.setText("Certificat de Reprise de Service");
        jMenu1.add(Certificat);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Permissions et conges");

        demanderPermission.setText("demander une permission");
        demanderPermission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                demanderPermissionActionPerformed(evt);
            }
        });
        jMenu2.add(demanderPermission);

        demanderConge.setText("demander un conge");
        jMenu2.add(demanderConge);

        accordePermission.setText("accorde une permission");
        accordePermission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                accordePermissionActionPerformed(evt);
            }
        });
        jMenu2.add(accordePermission);

        accordeConge.setText("accorde un conge");
        accordeConge.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                accordeCongeActionPerformed(evt);
            }
        });
        jMenu2.add(accordeConge);

        HistoConge.setText("Historique Conge");
        jMenu2.add(HistoConge);

        HistoPermission.setText("Historique Permission");
        jMenu2.add(HistoPermission);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("Courrier");

        Enregistrecourrier.setText("enregistrer un courrier");
        jMenu3.add(Enregistrecourrier);

        RegistreEntrant.setText("registre courrier entrant");
        jMenu3.add(RegistreEntrant);

        RegistreSortant.setText("registre courrier sortant");
        jMenu3.add(RegistreSortant);

        RegistreInterne.setText("registre courrier interne");
        RegistreInterne.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegistreInterneActionPerformed(evt);
            }
        });
        jMenu3.add(RegistreInterne);

        RechercheCourrier.setText("Rechercher Courrier");
        jMenu3.add(RechercheCourrier);

        jMenuBar1.add(jMenu3);

        jMenu4.setText("Archives");
        jMenuBar1.add(jMenu4);

        jMenu6.setText("Materiel");

        EnregistrerMat.setText("Enregistrer Materiel");
        jMenu6.add(EnregistrerMat);

        repartitionMat.setText("Repartition du Materiel");
        jMenu6.add(repartitionMat);

        rechercherMat.setText("Rechercher Materiel");
        jMenu6.add(rechercherMat);

        fdetenteur.setText("Fiche detenteur");
        jMenu6.add(fdetenteur);

        jMenuBar1.add(jMenu6);

        jMenu7.setText("Planification");
        jMenuBar1.add(jMenu7);

        jMenu8.setText("Mon compte");

        disconnect.setText("deconnection");
        jMenu8.add(disconnect);

        ModifieCompte.setText("Modifier Mon Compte");
        jMenu8.add(ModifieCompte);

        jMenuBar1.add(jMenu8);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jXDatePicker1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jXDatePicker1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jXDatePicker1ActionPerformed

    private void accordeCongeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_accordeCongeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_accordeCongeActionPerformed

    private void accordePermissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_accordePermissionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_accordePermissionActionPerformed

    private void demanderPermissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_demanderPermissionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_demanderPermissionActionPerformed

    private void RegistreInterneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegistreInterneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RegistreInterneActionPerformed

    /**
     * @param args the command line arguments
     */
     

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem Certificat;
    private javax.swing.JMenuItem Enregistrecourrier;
    private javax.swing.JMenuItem EnregistrerMat;
    private javax.swing.JMenuItem HistoConge;
    private javax.swing.JMenuItem HistoPermission;
    private javax.swing.JMenuItem ModifieCompte;
    private javax.swing.JMenuItem RechercheCourrier;
    private javax.swing.JMenuItem RegistreEntrant;
    private javax.swing.JMenuItem RegistreInterne;
    private javax.swing.JMenuItem RegistreSortant;
    private javax.swing.JMenuItem accordeConge;
    private javax.swing.JMenuItem accordeDroit;
    private javax.swing.JMenuItem accordePermission;
    private javax.swing.JMenuItem ajouterPerso;
    private javax.swing.JButton annuler;
    private javax.swing.JMenuItem attestation;
    private org.jdesktop.swingx.JXDatePicker debut;
    private javax.swing.JMenuItem demanderConge;
    private javax.swing.JMenuItem demanderPermission;
    private javax.swing.JMenuItem disconnect;
    private javax.swing.JComboBox exercice;
    private javax.swing.JMenuItem fdetenteur;
    private org.jdesktop.swingx.JXDatePicker fin;
    private view.Footer footer1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JPanel jPanel1;
    private org.jdesktop.swingx.JXDatePicker jXDatePicker1;
    private javax.swing.JTextField objet;
    private javax.swing.JMenuItem rechercherMat;
    private javax.swing.JMenuItem repartitionMat;
    private javax.swing.JButton valider;
    // End of variables declaration//GEN-END:variables
}
