/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.CtrlEnregistreCourrier;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import org.jdesktop.swingx.JXDatePicker;

/**
 *
 * @author EMME
 */
public class EnregistreCourrier extends javax.swing.JFrame {

    /**
     * Creates new form EnregistreCourrier
     */
    public EnregistreCourrier() {
        initComponents();
        this.setLocationRelativeTo(this);
        CtrlEnregistreCourrier conn= new CtrlEnregistreCourrier(this);
        this.valide.addActionListener(conn);
        this.annuler.addActionListener(conn);
        this.ajouterPerso.addActionListener(conn);
        this.demanderConge.addActionListener(conn);
        this.enregisterMat.addActionListener(conn);
        this.rechercherMat.addActionListener(conn);
        this.repartitionMat.addActionListener(conn);
        this.fdetenteur.addActionListener(conn);
        this.disconnect.addActionListener(conn);
        this.RechercherCourrier.addActionListener(conn);
        this.EnregistreCourrier.addActionListener(conn);
        this.RegistreCourrierEntrant.addActionListener(conn);
        this.RegistreCourrierInterne.addActionListener(conn);
        this.RegistreCourrierSortant.addActionListener(conn);
        this.histoConge.addActionListener(conn);
        this.histoPermission.addActionListener(conn);
        this.attestation.addActionListener(conn);
        this.Certificat.addActionListener(conn);
        this.ModifieCompte.addActionListener(conn);
        this.accordePermission.addActionListener(conn);
        this.accordeConge.addActionListener(conn);
        this.demanderPermission.addActionListener(conn);    
    } 

    public JMenuItem getCertificat() {
        return Certificat;
    }

    public void setCertificat(JMenuItem Certificat) {
        this.Certificat = Certificat;
    }
    public JMenuItem getModifieCompte() {
        return ModifieCompte;
    }

    public void setModifieCompte(JMenuItem ModifieCompte) {
        this.ModifieCompte = ModifieCompte;
    }

    public JMenuItem getAjouterPerso() {
        return ajouterPerso;
    }

    public void setAjouterPerso(JMenuItem ajouterPerso) {
        this.ajouterPerso = ajouterPerso;
    }

    public JMenuItem getDisconnect() {
        return disconnect;
    }

    public void setDisconnect(JMenuItem disconnect) {
        this.disconnect = disconnect;
    }

    public JMenuItem getEnregisterMat() {
        return enregisterMat;
    }

    public void setEnregisterMat(JMenuItem enregisterMat) {
        this.enregisterMat = enregisterMat;
    }

    public JMenuItem getFdetenteur() {
        return fdetenteur;
    }

    public void setFdetenteur(JMenuItem fdetenteur) {
        this.fdetenteur = fdetenteur;
    }

    public JMenuItem getRechercherMat() {
        return rechercherMat;
    }

    public void setRechercherMat(JMenuItem rechercherMat) {
        this.rechercherMat = rechercherMat;
    }

    public JMenuItem getRepartitionMat() {
        return repartitionMat;
    }

    public void setRepartitionMat(JMenuItem repartitionMat) {
        this.repartitionMat = repartitionMat;
    }

    public JMenuItem getAccordeConge() {
        return accordeConge;
    }

    public void setAccordeConge(JMenuItem accordeConge) {
        this.accordeConge = accordeConge;
    }

    public JMenuItem getAccordePermission() {
        return accordePermission;
    }

    public void setAccordePermission(JMenuItem accordePermission) {
        this.accordePermission = accordePermission;
    }

    public JMenuItem getAccorderDroit() {
        return accorderDroit;
    }

    public void setAccorderDroit(JMenuItem accorderDroit) {
        this.accorderDroit = accorderDroit;
    }

    public JMenuItem getAttestation() {
        return attestation;
    }

    public void setAttestation(JMenuItem attestation) {
        this.attestation = attestation;
    }

    public JMenu getCourrier() {
        return courrier;
    }

    public void setCourrier(JMenu courrier) {
        this.courrier = courrier;
    }

    public JMenuItem getDemanderConge() {
        return demanderConge;
    }

    public void setDemanderConge(JMenuItem demanderConge) {
        this.demanderConge = demanderConge;
    }

    public JMenuItem getDemanderPermission() {
        return demanderPermission;
    }

    public void setDemanderPermission(JMenuItem demanderPermission) {
        this.demanderPermission = demanderPermission;
    }

    public JMenuItem getHistoConge() {
        return histoConge;
    }

    public void setHistoConge(JMenuItem histoConge) {
        this.histoConge = histoConge;
    }

    public JMenuItem getHistoPermission() {
        return histoPermission;
    }

    public void setHistoPermission(JMenuItem histoPermission) {
        this.histoPermission = histoPermission;
    }
    public JTextField getOther() {
        return other;
    }

    public void setOther(JTextField other) {
        this.other = other;
    }
    

    public JMenuItem getEnregistreCourrier() {
        return EnregistreCourrier;
    }

    public void setEnregistreCourrier(JMenuItem EnregistreCourrier) {
        this.EnregistreCourrier = EnregistreCourrier;
    }

    public JMenuItem getRegistreCourrierEntrant() {
        return RegistreCourrierEntrant;
    }

    public void setRegistreCourrierEntrant(JMenuItem RegistreCourrierEntrant) {
        this.RegistreCourrierEntrant = RegistreCourrierEntrant;
    }

    public JMenuItem getRegistreCourrierInterne() {
        return RegistreCourrierInterne;
    }

    public void setRegistreCourrierInterne(JMenuItem RegistreCourrierInterne) {
        this.RegistreCourrierInterne = RegistreCourrierInterne;
    }

    public JMenuItem getRegistreCourrierSortant() {
        return RegistreCourrierSortant;
    }

    public void setRegistreCourrierSortant(JMenuItem RegistreCourrierSortant) {
        this.RegistreCourrierSortant = RegistreCourrierSortant;
    }

    public JButton getAnnuler() {
        return annuler;
    }

    public void setAnnuler(JButton annuler) {
        this.annuler = annuler;
    }

    public JXDatePicker getDate() {
        return date;
    }

    public void setDate(JXDatePicker date) {
        this.date = date;
    }

    public JTextField getExperditeur() {
        return experditeur;
    }

    public void setExperditeur(JTextField experditeur) {
        this.experditeur = experditeur;
    }

    public JComboBox<String> getNature() {
        return nature;
    }

    public void setNature(JComboBox<String> nature) {
        this.nature = nature;
    }

    public JSpinner getNum() {
        return num;
    }

    public void setNum(JSpinner num) {
        this.num = num;
    }

    public JTextField getObjet() {
        return objet;
    }

    public void setObjet(JTextField objet) {
        this.objet = objet;
    }

    public JTextField getRef() {
        return ref;
    }

    public void setRef(JTextField ref) {
        this.ref = ref;
    }

    public JComboBox<String> getRef1() {
        return ref1;
    }

    public void setRef1(JComboBox<String> ref1) {
        this.ref1 = ref1;
    }

    public JComboBox<String> getRef2() {
        return ref2;
    }

    public void setRef2(JComboBox<String> ref2) {
        this.ref2 = ref2;
    }

    public JComboBox<String> getRef3() {
        return ref3;
    }

    public void setRef3(JComboBox<String> ref3) {
        this.ref3 = ref3;
    }

    public JComboBox<String> getRef4() {
        return ref4;
    }

    public void setRef4(JComboBox<String> ref4) {
        this.ref4 = ref4;
    }

    public JTextField getTypeC() {
        return typeC;
    }

    public void setTypeC(JTextField typeC) {
        this.typeC = typeC;
    }

  

    public JButton getValide() {
        return valide;
    }

    public void setValide(JButton valide) {
        this.valide = valide;
    }
    
   
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu3 = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        num = new javax.swing.JSpinner();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        experditeur = new javax.swing.JTextField();
        date = new org.jdesktop.swingx.JXDatePicker();
        objet = new javax.swing.JTextField();
        nature = new javax.swing.JComboBox<>();
        ref = new javax.swing.JTextField();
        ref1 = new javax.swing.JComboBox<>();
        ref2 = new javax.swing.JComboBox<>();
        ref3 = new javax.swing.JComboBox<>();
        ref4 = new javax.swing.JComboBox<>();
        typeC = new javax.swing.JTextField();
        valide = new javax.swing.JButton();
        annuler = new javax.swing.JButton();
        other = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        ajouterPerso = new javax.swing.JMenuItem();
        accorderDroit = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        attestation = new javax.swing.JMenuItem();
        Certificat = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        demanderPermission = new javax.swing.JMenuItem();
        demanderConge = new javax.swing.JMenuItem();
        accordeConge = new javax.swing.JMenuItem();
        accordePermission = new javax.swing.JMenuItem();
        histoConge = new javax.swing.JMenuItem();
        histoPermission = new javax.swing.JMenuItem();
        courrier = new javax.swing.JMenu();
        EnregistreCourrier = new javax.swing.JMenuItem();
        RegistreCourrierEntrant = new javax.swing.JMenuItem();
        RegistreCourrierSortant = new javax.swing.JMenuItem();
        RegistreCourrierInterne = new javax.swing.JMenuItem();
        RechercherCourrier = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();
        enregisterMat = new javax.swing.JMenuItem();
        repartitionMat = new javax.swing.JMenuItem();
        rechercherMat = new javax.swing.JMenuItem();
        reformerMat = new javax.swing.JMenuItem();
        listerMat = new javax.swing.JMenuItem();
        fdetenteur = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        jMenu8 = new javax.swing.JMenu();
        disconnect = new javax.swing.JMenuItem();
        ModifieCompte = new javax.swing.JMenuItem();

        jMenu3.setText("jMenu3");

        jMenuItem3.setText("jMenuItem3");

        jMenuItem4.setText("jMenuItem4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("AGRHM");

        jPanel1.setBackground(new java.awt.Color(153, 255, 153));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel1.setText("NumOrdre");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setText("Type");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setText("Expediteur/Recepteur");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setText("Date");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setText("Objet");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel6.setText("Nature");

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel7.setText("Reference");

        nature.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " ", "Courrier_entrant", "Courrier_interne", "Courrier_Sortant" }));

        ref1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " ", "CAMWATER", "CAMPOST", "CAMTEL", "UBA", "UB", "UD", "UDS", "UNG", "UYI", "UYII", "IAI", "IUC", "MINESEC", "MINEDUB", "MINFI", "MINAT", "SG", "MINFOPRA", "MINPOSTEL", "MINTP", "MINSANTE", "MINESUP", "MINRESI", "MINREX", "MINEPAT", "AUCUN", " ", " ", " " }));

        ref2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " ", "SG", "DAAJ", "DAAF", "DGI", "DGB", "DGT", "CENADI", "OBC", "GCE-BOARD", "IUT-FV", "FASA", "ENSPD", "ENSPB", "ENSPY", "ENSPM", "3IAC", "AUCUN" }));

        ref3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " ", "DAAF", "DEL", "DEP", "DTB", "DIRE", "CIB", "CID", "CIG", "DR", "AUCUN" }));

        ref4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " ", "AD", "CE", "EN", "ES", "OU", "LT", "NO", "NW", "SU", "SW", "AUCUN", " ", " " }));

        valide.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        valide.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/SaveAll24.gif"))); // NOI18N
        valide.setText("VALIDER");

        annuler.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        annuler.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Delete24.gif"))); // NOI18N
        annuler.setText("ANNULER");

        other.setText(" ");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("Ou");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(experditeur))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(19, 19, 19)
                                        .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(num))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addGap(19, 19, 19)
                                        .addComponent(typeC)))))
                        .addGap(157, 157, 157)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(objet, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nature, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(ref, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(50, 50, 50)
                                .addComponent(ref1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(34, 34, 34)
                                .addComponent(ref2, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(33, 33, 33)
                                .addComponent(ref3, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(ref4, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(other)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(244, 244, 244)
                        .addComponent(valide)
                        .addGap(139, 139, 139)
                        .addComponent(annuler)))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(num, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(objet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(56, 56, 56)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(typeC, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(nature, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(experditeur, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ref, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ref1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ref3, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ref4, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ref2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(other, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(74, 74, 74)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(annuler, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(valide, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(130, Short.MAX_VALUE))
        );

        jMenuBar1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        jMenu1.setText("Personnel");
        jMenu1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        ajouterPerso.setText("Ajouter Personnel");
        jMenu1.add(ajouterPerso);

        accorderDroit.setText("Accorder droit");
        jMenu1.add(accorderDroit);

        jMenuItem2.setText("Liste presence");
        jMenu1.add(jMenuItem2);

        attestation.setText("Attestation de presence");
        jMenu1.add(attestation);

        Certificat.setText("Certificate de Reprise de Service");
        jMenu1.add(Certificat);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Permissions et Conges");
        jMenu2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        demanderPermission.setText("Demander une permission");
        jMenu2.add(demanderPermission);

        demanderConge.setText("Demander un conge");
        jMenu2.add(demanderConge);

        accordeConge.setText("Accorde un conge");
        jMenu2.add(accordeConge);

        accordePermission.setText("Accorde une permission");
        jMenu2.add(accordePermission);

        histoConge.setText("Historique conges");
        jMenu2.add(histoConge);

        histoPermission.setText("Historiques des permissions");
        jMenu2.add(histoPermission);

        jMenuBar1.add(jMenu2);

        courrier.setText("Courrier");
        courrier.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        EnregistreCourrier.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        EnregistreCourrier.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        EnregistreCourrier.setText("Enregistre un Courrier");
        EnregistreCourrier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EnregistreCourrierActionPerformed(evt);
            }
        });
        courrier.add(EnregistreCourrier);

        RegistreCourrierEntrant.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        RegistreCourrierEntrant.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        RegistreCourrierEntrant.setText("Registre Courrier Entrant");
        courrier.add(RegistreCourrierEntrant);

        RegistreCourrierSortant.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        RegistreCourrierSortant.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        RegistreCourrierSortant.setText("Registre Courrier Sortant");
        courrier.add(RegistreCourrierSortant);

        RegistreCourrierInterne.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        RegistreCourrierInterne.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        RegistreCourrierInterne.setText("Registre Courrier Interne");
        RegistreCourrierInterne.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegistreCourrierInterneActionPerformed(evt);
            }
        });
        courrier.add(RegistreCourrierInterne);

        RechercherCourrier.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        RechercherCourrier.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Search24.gif"))); // NOI18N
        RechercherCourrier.setText("Rechercher un Courrier");
        courrier.add(RechercherCourrier);

        jMenuBar1.add(courrier);

        jMenu5.setText("Archive");
        jMenu5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuBar1.add(jMenu5);

        jMenu6.setText("Materiel");
        jMenu6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        enregisterMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif"))); // NOI18N
        enregisterMat.setText("enregistrer un materiel");
        jMenu6.add(enregisterMat);

        repartitionMat.setText("repartition du materiel");
        jMenu6.add(repartitionMat);

        rechercherMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Search24.gif"))); // NOI18N
        rechercherMat.setText("rechercher materiel");
        jMenu6.add(rechercherMat);

        reformerMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/TipOfTheDay24.gif"))); // NOI18N
        reformerMat.setText("reformer un materiel");
        jMenu6.add(reformerMat);

        listerMat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Open24.gif"))); // NOI18N
        listerMat.setText("lister le materiel");
        jMenu6.add(listerMat);

        fdetenteur.setText("Fiche detenteur");
        jMenu6.add(fdetenteur);

        jMenuBar1.add(jMenu6);

        jMenu7.setText("Planification");
        jMenu7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jMenuBar1.add(jMenu7);

        jMenu8.setText("Mon compte");
        jMenu8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        disconnect.setText("deconnection");
        jMenu8.add(disconnect);

        ModifieCompte.setText("Modifier Mon Compte");
        jMenu8.add(ModifieCompte);

        jMenuBar1.add(jMenu8);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 2, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void EnregistreCourrierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EnregistreCourrierActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EnregistreCourrierActionPerformed

    private void RegistreCourrierInterneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegistreCourrierInterneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RegistreCourrierInterneActionPerformed

    /**
     * @param args the command line arguments
     */

    public JMenuItem getRechercherCourrier() {
        return RechercherCourrier;
    }

    /**
     * @param args the command line arguments
     */
    public void setRechercherCourrier(JMenuItem rechercherCourrier) {
        this.RechercherCourrier = rechercherCourrier;
    }
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem Certificat;
    private javax.swing.JMenuItem EnregistreCourrier;
    private javax.swing.JMenuItem ModifieCompte;
    private javax.swing.JMenuItem RechercherCourrier;
    private javax.swing.JMenuItem RegistreCourrierEntrant;
    private javax.swing.JMenuItem RegistreCourrierInterne;
    private javax.swing.JMenuItem RegistreCourrierSortant;
    private javax.swing.JMenuItem accordeConge;
    private javax.swing.JMenuItem accordePermission;
    private javax.swing.JMenuItem accorderDroit;
    private javax.swing.JMenuItem ajouterPerso;
    private javax.swing.JButton annuler;
    private javax.swing.JMenuItem attestation;
    private javax.swing.JMenu courrier;
    private org.jdesktop.swingx.JXDatePicker date;
    private javax.swing.JMenuItem demanderConge;
    private javax.swing.JMenuItem demanderPermission;
    private javax.swing.JMenuItem disconnect;
    private javax.swing.JMenuItem enregisterMat;
    private javax.swing.JTextField experditeur;
    private javax.swing.JMenuItem fdetenteur;
    private javax.swing.JMenuItem histoConge;
    private javax.swing.JMenuItem histoPermission;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JMenuItem listerMat;
    private javax.swing.JComboBox<String> nature;
    private javax.swing.JSpinner num;
    private javax.swing.JTextField objet;
    private javax.swing.JTextField other;
    private javax.swing.JMenuItem rechercherMat;
    private javax.swing.JTextField ref;
    private javax.swing.JComboBox<String> ref1;
    private javax.swing.JComboBox<String> ref2;
    private javax.swing.JComboBox<String> ref3;
    private javax.swing.JComboBox<String> ref4;
    private javax.swing.JMenuItem reformerMat;
    private javax.swing.JMenuItem repartitionMat;
    private javax.swing.JTextField typeC;
    private javax.swing.JButton valide;
    // End of variables declaration//GEN-END:variables
}
